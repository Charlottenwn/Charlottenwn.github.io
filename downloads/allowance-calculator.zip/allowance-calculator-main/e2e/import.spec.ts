import { test, expect } from '@playwright/test';
import type { Page } from '@playwright/test';

const FIXTURE = 'src/tests/fixtures/timesheet-2026-09.xlsx';
const TOTAL = /^808,00\s€$/;
const RATES: [string, string][] = [
  ['LT', '28'],
  ['LV', '44'],
  ['EE', '40'],
  ['SE', '50'],
  ['DE', '62'],
];

/* ---------- helpers: each moves the app one stage forward ---------- */

/** enter rates and answer all four pack questions (browser store is in-memory, nothing persists) */
async function seed(page: Page) {
  const nav = page.getByRole('navigation', { name: 'Sritys' });

  await nav.getByRole('button', { name: 'Tarifai' }).click();
  for (const [i, [place, eur]] of RATES.entries()) {
    await page.getByRole('button', { name: 'Pridėti eilutę' }).click();
    await page.getByLabel('Valstybė', { exact: true }).nth(i).fill(place);
    await page.getByLabel('EUR per dieną', { exact: true }).nth(i).fill(eur);
    await page.getByLabel('Galioja nuo', { exact: true }).nth(i).fill('2000-01-01');
  }
  await page.getByLabel('Tarifų lentelės nuoroda').fill('https://example.test/rates');
  await page.getByRole('button', { name: 'Tikrinti ir išsaugoti' }).click();

  await nav.getByRole('button', { name: 'Taisyklių paketai' }).click();
  await page.getByRole('button', { name: 'Redaguoti' }).first().click();
  for (const q of await page.getByLabel(/^Klausimas \d+$/).all()) await q.selectOption('1');
  await page.getByRole('button', { name: 'Tikrinti ir išsaugoti' }).click();

  await nav.getByRole('button', { name: 'Skaičiuoti' }).click();
}

/** pack screen -> import the fixture -> trips screen */
async function importSheet(page: Page) {
  await page.getByRole('button', { name: 'Toliau' }).click();
  const chooser = page.waitForEvent('filechooser');
  await page.getByRole('button', { name: 'Pasirinkti žiniaraštį' }).click();
  (await chooser).setFiles(FIXTURE);
  await page.getByRole('button', { name: 'Toliau' }).click();
  await expect(page.getByRole('heading', { name: 'Komandiruotės' })).toBeVisible();
}

const missingRows = (page: Page) => page.getByRole('button', { name: /trūksta duomenų/ });

/** trips without data (blocked in this fixture) are marked unfinished, one by one */
async function markUnfinished(page: Page) {
  while ((await missingRows(page).count()) > 0) {
    await missingRows(page).first().click();
    await page.getByRole('button', { name: 'Pažymėti nebaigta' }).click();
    await expect(page.getByRole('heading', { name: 'Komandiruotės' })).toBeVisible();
  }
}

/** trips screen -> check screen -> result screen */
async function calculate(page: Page) {
  await page.getByRole('button', { name: 'Toliau' }).click();
  await expect(page.getByRole('heading', { name: 'Patikra prieš skaičiavimą' })).toBeVisible();
  await expect(page.getByText('Viskas nustatyta.')).toBeVisible();
  await page.getByRole('main').getByRole('button', { name: 'Skaičiuoti' }).click();
  await expect(page.getByLabel('Bendra suma')).toBeVisible();
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
});

/* ---------- tests ---------- */

test.describe('import', () => {
  test('real-layout timesheet is parsed into trips', async ({ page }) => {
    await importSheet(page);
    await expect(page.getByText('Komandiruočių šį mėnesį nėra.')).toHaveCount(0);
    await expect(
      page.getByRole('button', { name: /^\w+.*\d{4}-\d{2}-\d{2} – \d{4}-\d{2}-\d{2}/ }).first(),
    ).toBeVisible();
  });

  test('trips without data stay flagged until marked unfinished', async ({ page }) => {
    await importSheet(page);
    await expect(missingRows(page)).not.toHaveCount(0);
    await markUnfinished(page);
    await expect(missingRows(page)).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'Toliau' })).toBeEnabled();
  });
});

test.describe('calculation', () => {
  test.beforeEach(async ({ page }) => {
    await seed(page);
    await importSheet(page);
    await markUnfinished(page);
  });

  test('result total matches the engine (808,00 €)', async ({ page }) => {
    await calculate(page);
    await expect(page.getByLabel('Bendra suma')).toHaveText(TOTAL);
    await page.getByRole('button', { name: 'Dienų detalės' }).first().click();
  });
});

test.describe('export and session', () => {
  test.beforeEach(async ({ page }) => {
    await seed(page);
    await importSheet(page);
    await markUnfinished(page);
    await calculate(page);
  });

  test('CSV export downloads a .csv file', async ({ page }) => {
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: 'CSV', exact: true }).click();
    expect((await download).suggestedFilename()).toMatch(/\.csv$/);
  });

  test('session saved to file reopens with the same result', async ({ page }, testInfo) => {
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: 'Išsaugoti sesiją' }).first().click();
    const saved = await download;
    expect(saved.suggestedFilename()).toMatch(/^\d{4}-\d{2}-\d{2} \d{2}-\d{2} \(2026-09 xlsx\)\.dpsesija$/);
    const file = testInfo.outputPath('session.dpsesija');
    await saved.saveAs(file);

    await page.reload(); // fresh in-memory store: the state can only come from the file
    const chooser = page.waitForEvent('filechooser');
    await page.getByRole('button', { name: 'Atidaryti sesiją' }).click();
    (await chooser).setFiles(file);
    await expect(page.getByRole('dialog')).toContainText('Atidaryta sesija');
    await page.getByRole('button', { name: 'Ne, palikti išsaugotą' }).click();
    await expect(page.getByLabel('Bendra suma')).toHaveText(TOTAL);
  });
});
