/*global describe, it, $, $$, browser, expect*/
const rowsOf = (label) => $$(`input[aria-label="${label}"]`);
const last = async (label) => {
  const els = await rowsOf(label);
  return els[els.length - 1];
};
const values = async (label) => {
  const out = [];
  for (const e of await rowsOf(label)) out.push(await e.getValue());
  return out;
};
const isoDay = (n) => new Date(Date.UTC(2020, 0, 1 + n)).toISOString().slice(0, 10);
const nav = () => $('aria/Sritys');

describe('exe smoke', () => {
  it('renders app shell', async () => {
    await expect(nav()).toBeDisplayed({ wait: 15000 });
  });

  it('opens Calculate step 1', async () => {
    await $('button=Skaičiuoti').click();
    await expect($('button=Toliau')).toBeDisplayed({ wait: 5000 });
  });

  it('stays alive', async () => {
    await browser.pause(5000);
    await expect(nav()).toBeDisplayed();
  });

  it('creates AppData and persists tariff rates', async () => {
    await $('button=Tarifai').click();
    await expect($('aria/Valstybė ar miestas')).toBeDisplayed();

    // first date not used by any existing row, so reruns never create a duplicate rate
    const taken = new Set(await values('Galioja nuo'));
    let n = 0;
    while (taken.has(isoDay(n))) n++;
    const day = isoDay(n);

    await $('button=Pridėti eilutę').click();
    await (await last('Valstybė')).setValue('LT');
    await (await last('EUR per dieną')).setValue('28');
    await (await last('Galioja nuo')).setValue(day);
    await $('input[aria-label="Tarifų lentelės nuoroda"]').setValue('https://example.test/rates');

    await $('button=Tikrinti ir išsaugoti').click();
    await expect($('aria/Tarifų sąrašas išsaugotas kaip nauja versija, ankstesnė palikta')).toBeDisplayed({
      wait: 10000,
    });

    await browser.refresh();
    await $('button=Tarifai').click();
    await expect($('aria/Valstybė ar miestas')).toBeDisplayed();

    const dates = await values('Galioja nuo');
    const i = dates.indexOf(day);
    expect(i).toBeGreaterThan(-1);
    expect((await values('Valstybė'))[i]).toMatch(/^(LT|Lietuva)$/);
    expect(Number((await values('EUR per dieną'))[i])).toBe(28);
  });
});
