import { spawn } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
let driver;
export const config = {
  runner: 'local',
  specs: ['e2e/smoke/app.smoke.mjs'],
  maxInstances: 1,
  hostname: '127.0.0.1',
  port: 4444,
  capabilities: [
    {
      browserName: 'wry',
      'tauri:options': { application: path.resolve('src-tauri/target/release/app.exe') },
    },
  ],
  framework: 'mocha',
  reporters: ['spec'],
  mochaOpts: { timeout: 60000 },
  connectionRetryCount: 0,
  connectionRetryTimeout: 120000,
  beforeSession: () => {
    driver = spawn(
      path.join(os.homedir(), '.cargo', 'bin', 'tauri-driver.exe'),
      ['--native-driver', path.resolve('msedgedriver.exe')],
      { stdio: [null, process.stdout, process.stderr] },
    );
  },
  afterSession: () => driver?.kill(),
};
