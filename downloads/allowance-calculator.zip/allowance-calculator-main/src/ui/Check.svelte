<script lang="ts">
  import { acc, btn, pri } from './cls';
  import Head from './Head.svelte';
  import { ui } from './state.svelte';
</script>

<Head
  t="Patikra prieš skaičiavimą"
  s="Skaičiavimas prasideda, kai visi klausimai pasirinkti ir kiekvienai dienai yra tarifas."
/>
<div class="mt-8">
  {#each ui.checks as c, n (n)}
    <div
      class="flex justify-between items-center gap-4 border-l-2 border-slate-900 dark:border-white pl-4 py-2 my-3 text-sm"
    >
      <span>{c.t}</span>
      <button class={btn} onclick={() => ui.jump(c)}>Taisyti nustatymus</button>
    </div>
  {:else}
    <p class="text-sm leading-7 {acc}">Viskas nustatyta.</p>
  {/each}
</div>
<div class="mt-10">
  <button class={pri} disabled={ui.checks.length > 0} onclick={() => ui.go(4)}>Skaičiuoti</button>
</div>
