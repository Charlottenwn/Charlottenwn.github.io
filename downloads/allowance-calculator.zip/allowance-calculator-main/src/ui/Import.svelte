<script lang="ts">
  import { acc, btn, card, inp, lab, mut, pri } from './cls';
  import Head from './Head.svelte';
  import Msg from './Msg.svelte';
  import { ui } from './state.svelte';
  import { monthLabel, msgs } from './strings';

  const errs = $derived(msgs(ui.issues.filter((i) => i.level === 'error')));
  const noPeriod = $derived(ui.issues.some((i) => i.code === 'PERIOD_NOT_FOUND'));
  const inMonth = (p: string) => ui.trips.filter((t) => t.trip.days[0]!.d.startsWith(p));
</script>

<Head
  t="Žiniaraštis ir profilis"
  s="Įkelkite mėnesio darbo laiko apskaitos žiniaraštį. K žymos tampa komandiruotėmis, S ir P praleidžiami."
/>
{#if ui.load}
  <div class="{card} mt-10 animate-pulse text-sm {mut}">Skaitomas žiniaraštis, tikrinami kodai…</div>
{:else}
  {#if !ui.months.length && !ui.pend}
    <div class="{card} mt-10 text-center py-16">
      <p class="text-xl font-semibold tracking-tight">Žiniaraštis dar neįkeltas</p>
      <p class="text-sm leading-7 mt-2 {mut}">Pasirinkite profilį ir Excel failą.</p>
      <div class="flex justify-center gap-3 mt-8">
        <select
          class="{inp} !w-auto"
          aria-label="Importo profilis"
          value={ui.session!.profileId}
          onchange={(e) => ui.setProfile(e.currentTarget.value)}
        >
          {#each ui.profs as p (p.id)}<option value={p.id}>{p.label}</option>{/each}
        </select>
        <button class={pri} onclick={() => ui.addMonth()}>Pasirinkti žiniaraštį</button>
      </div>
    </div>
  {/if}
  <div class="mt-10 space-y-6">
    {#each ui.months as x (x.period)}
      <div class={card}>
        <div class="flex justify-between items-baseline">
          <h3 class="text-xl font-semibold tracking-tight">{monthLabel(x.period)}</h3>
          <span class="font-mono text-xs {mut}">{x.file ?? ''}</span>
        </div>
        <p class="text-sm leading-7 mt-3 {acc}">
          {ui.skip ? 'Blogos eilutės praleistos. ' : 'Visos eilutės tinkamos. '}Rasta komandiruočių: {inMonth(x.period)
            .length}, apskaičiuota automatiškai pagal K žymas ir valstybių kodus: {inMonth(x.period).filter(
            (t) => !ui.needs(t),
          ).length}.
        </p>
      </div>
    {/each}
    {#if ui.pend}
      <div class={card}>
        <div class="flex justify-between items-baseline">
          <h3 class="text-xl font-semibold tracking-tight">{monthLabel(ui.pend.sheet.period)}</h3>
          <span class="font-mono text-xs {mut}">{ui.pend.file}</span>
        </div>
        {#each errs as e, n (n)}<Msg kind="error" text={e.text} />{/each}
        <div class="flex flex-wrap gap-2">
          <button class={btn} onclick={() => ui.retry()}>Taisyti failą ir įkelti iš naujo</button>
          <button class={btn} onclick={() => ui.acceptPending()}>Praleisti blogas eilutes</button>
        </div>
      </div>
    {:else if errs.length}
      <div class={card}>
        {#each errs as e, n (n)}<Msg kind="error" text={e.text} />{/each}
        {#if noPeriod}
          <label class="block max-w-xs">
            <span class={lab}>Mėnuo</span>
            <input class={inp} type="month" bind:value={ui.period} />
          </label>
        {/if}
        <div class="flex flex-wrap gap-2 mt-4">
          <button class={btn} onclick={() => (noPeriod && ui.last ? ui.retry() : ui.addMonth())}>
            {noPeriod ? 'Bandyti iš naujo' : 'Pasirinkti kitą failą'}
          </button>
        </div>
      </div>
    {/if}
  </div>
  {#if ui.months.length || ui.pend}
    <div class="mt-10"><button class={pri} disabled={!ui.mOk} onclick={() => ui.go(2)}>Toliau</button></div>
  {/if}
{/if}
