import {
  addHist,
  allTrips,
  APP,
  calcSync,
  calculate,
  ensureInputs,
  newSession,
  previewTrip,
  setInput,
  setRates,
  setSheet,
  syncSnapshot,
  undoHist,
} from '../core/api';
import { toCsv, toRows, toXlsx, ratesToXlsx } from '../core/export';
import { parseSheet, periodOf, readAoa, readSheet } from '../core/import';
import { openBytes, openExternal, saveBytes } from '../core/io';
import { checkRates, parseRates } from '../core/rates';
import { Repo } from '../core/repo';
import { ImportProfile, RulePack, Session, migrate } from '../core/schema';
import type { HistEntry, Issue, ParsedSheet, RateList, TripInput, Undo } from '../core/schema';
import { makeStore } from '../core/storage';
import type { Store } from '../core/storage';
import { dayPlaces } from '../core/engine';
import { sha, stable } from '../core/util';
import { PRESETS } from '../rules/defaults';
import { placeCode, placeName } from './places';
import { eur, monthLabel, msg, msgs, num, SWITCH_KEYS, fromAnswer, toAnswer } from './strings';

export const MAX_MONTHS = 2;
const SRC = { none: 'nemažinama', ca: 'kolektyvinė sutartis', local: 'vietinis aktas' } as const;
type Src = keyof typeof SRC;

export type TripDraft = {
  h: (number | null)[]; // hours per day (decimal), null = none
  c: string[]; // country code per day, '' = none
  src: Src;
  pct: number;
  note: boolean;
};
export type PackDraft = { n: string; sw: number[]; adv: { ca: number; act: number; h: number; pc: number } };
export type ProfDraft = {
  n: string;
  codes: string;
  kmark: string;
  sheet: string;
  hdr: string;
  nameCol: string;
  idxCol: string;
  dayCol: string;
  step: string;
  row1: string;
  per: string;
  placeOff: string;
  kOff: string;
  yearCell: string;
  monthCell: string;
};
export type Edit =
  { k: 'p'; id: string; o: PackDraft; err: string } | { k: 'f'; id: string; o: ProfDraft; err: string };
export type RateDraft = { r: { c: string; e: number; f: string }[]; u: string; err: string };

const col = (s: string) => [...s.trim().toUpperCase()].reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0) - 1;
const colName = (i: number) => {
  let s = '';
  for (let n = i + 1; n > 0; n = Math.floor((n - 1) / 26)) s = String.fromCharCode(65 + ((n - 1) % 26)) + s;
  return s;
};
const cell = (s: string): [number, number] | null => {
  const m = s
    .trim()
    .toUpperCase()
    .match(/^([A-Z]{1,3})(\d{1,5})$/);
  return m ? [Number(m[2]) - 1, col(m[1]!)] : null;
};
const cellName = (c: [number, number] | null) => (c ? `${colName(c[1])}${c[0] + 1}` : '');
const isCol = (s: string) => /^[A-Za-z]{1,3}$/.test(s.trim());
/** read a reactive value so a $derived block re-runs when it changes */
const track = (...a: unknown[]) => a.length;
const newest = <T extends { effectiveFrom: string; version: number }>(l: T[]) =>
  [...l].sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom) || b.version - a.version)[0]!;

class Ui {
  dark = $state(typeof document !== 'undefined' && document.documentElement.classList.contains('dark'));
  tab = $state(0);
  step = $state(0);
  sel = $state<string | null>(null);
  draft = $state<TripDraft | null>(null);
  skip = $state(false);
  det = $state(false);
  load = $state(false);
  modal = $state<'' | 'open' | 'rates'>('');
  note = $state('');
  busy = $state('');
  err = $state('');
  sess = $state('Nauja sesija, neišsaugota');
  ready = $state(false);
  fatal = $state<string | null>(null);
  hf = $state('all');
  ed = $state<Edit | null>(null);
  rd = $state<RateDraft | null>(null);
  period = $state(''); // typed month when the sheet's title cells cannot be read
  repo!: Repo;
  session = $state.raw<Session | null>(null);
  profiles = $state.raw<ImportProfile[]>([]);
  rev = $state(0);
  stamp = $state(''); // short hash of the rates list
  pend = $state.raw<{ sheet: ParsedSheet; file: string } | null>(null);
  issues = $state.raw<Issue[]>([]);
  opened = $state.raw<{ session: Session; name: string } | null>(null);
  last = $state.raw<{ bytes: Uint8Array; file: string } | null>(null);
  private t: ReturnType<typeof setTimeout> | undefined;

  months = $derived.by(() => {
    track(this.rev);
    return this.session ? Object.values(this.session.sheets).sort((a, b) => a.period.localeCompare(b.period)) : [];
  });
  calc = $derived.by(() => {
    track(this.rev);
    return this.session ? calcSync(this.session) : [];
  });
  trips = $derived.by(() => {
    track(this.rev);
    return this.session ? allTrips(this.session) : [];
  });
  total = $derived(this.calc.reduce((a, m) => a + m.cents, 0));
  packs = $derived.by(() => {
    track(this.rev);
    const g: Record<string, RulePack[]> = {};
    for (const p of this.session?.packs ?? []) (g[p.id] ??= []).push(p);
    return Object.values(g).map(newest);
  });
  pack = $derived(this.packs.find((p) => p.id === this.session?.activePack) ?? this.packs[0]!);
  profs = $derived.by(() => {
    const g: Record<string, ImportProfile[]> = {};
    for (const p of this.profiles) (g[p.id] ??= []).push(p);
    return Object.values(g).map((l) => [...l].sort((a, b) => b.version - a.version)[0]!);
  });
  profile = $derived(this.profs.find((p) => p.id === this.session?.profileId) ?? this.profs[0]!);
  places = $derived([...new Set((this.session?.rates.rows ?? []).map((r) => r.place))]);
  curTrip = $derived(this.sel ? this.trips.find((x) => x.trip.id === this.sel) : undefined);
  tOk = $derived(
    this.trips.length > 0 &&
      this.trips.every((x) => x.result.status === 'excluded' || !x.result.issues.some((i) => DATA.has(i.code))),
  );
  mOk = $derived(this.months.length > 0 && !this.pend);

  /** live calculation of the trip being edited */
  preview = $derived.by(() => {
    const t = this.curTrip,
      d = this.draft;
    return t && d && this.session ? previewTrip(this.session, t.trip, this.toInput(t.trip.id, d)) : undefined;
  });
  checks = $derived.by(() => {
    track(this.rev);
    const e: { t: string; tab?: number; step?: number }[] = [];
    SWITCH_KEYS.forEach((k, i) => {
      if (this.pack.switches[k] === null) e.push({ t: `Neišspręstas klausimas ${i + 1}: nepasirinkta`, tab: 1 });
    });
    for (const { trip, result } of this.trips) {
      if (result.status === 'excluded') continue;
      for (const m of msgs(result.issues.filter((i) => i.level === 'error' && i.code !== 'SWITCH_UNRESOLVED'))) {
        const rate = m.text.startsWith('Nėra tarifo');
        e.push(rate ? { t: m.text, tab: 3 } : { t: `${trip.employee}, ${trip.days[0]!.d}: ${m.text}`, step: 2 });
      }
    }
    return e;
  });
  lastD = $derived.by(() => {
    track(this.rev);
    return this.session?.history.find((h) => h.a !== undefined && h.b !== undefined && h.a !== h.b);
  });

  /* ---------- plumbing ---------- */
  async init(store?: Store) {
    try {
      this.repo = new Repo(store ?? (await makeStore()));
      this.profiles = await this.repo.profiles();
      this.session = await newSession(this.repo, 'sesija');
      await this.after();
      this.ready = true;
    } catch (e) {
      this.fatal = e instanceof Error ? e.message : String(e);
    }
  }
  async after() {
    this.rev++;
    if (this.session) this.stamp = (await sha(stable(this.session.rates))).slice(0, 8);
  }
  toast(x: string) {
    this.note = x;
    clearTimeout(this.t);
    this.t = setTimeout(() => (this.note = ''), 2600);
  }
  async run<T>(label: string, fn: () => Promise<T>): Promise<T | undefined> {
    if (this.busy) return;
    this.busy = label;
    this.err = '';
    try {
      return await fn();
    } catch (e) {
      this.err = `${label}: ${e instanceof Error ? e.message : String(e)}`;
    } finally {
      this.busy = '';
    }
  }
  log(k: string, x: string, a?: number, b?: number, undo?: Undo) {
    addHist(this.session!, k, x, a, b, undo);
    this.rev++;
  }
  setTheme(d: boolean) {
    this.dark = d;
    document.documentElement.classList.toggle('dark', d);
    document.documentElement.style.colorScheme = d ? 'dark' : 'light';
    try {
      localStorage.setItem('theme', d ? 'dark' : 'light');
    } catch {
      /* private mode */
    }
  }
  link(url: string) {
    void openExternal(url);
  }
  go(s: number) {
    if (s === 4 && this.step !== 4)
      this.log(
        'calc',
        `Skaičiavimas: ${this.pack.label} v${this.pack.version}, tarifų hash ${this.stamp}, komandiruočių: ${this.trips.length}`,
        undefined,
        this.total,
      );
    this.step = s;
    this.sel = null;
    this.draft = null;
  }
  jump(c: { tab?: number; step?: number }) {
    if (c.tab !== undefined) this.tab = c.tab;
    if (c.step !== undefined) {
      this.tab = 0;
      this.go(c.step);
    }
  }

  /* ---------- step 0: pack and policy ---------- */
  setActivePack(id: string) {
    const s = this.session!,
      a = this.total,
      before = s.activePack,
      old = this.pack;
    s.activePack = id;
    this.rev++;
    this.log(
      'rules',
      `Aktyvus paketas: ${old.label} v${old.version} → ${this.pack.label} v${this.pack.version}`,
      a,
      this.total,
      { type: 'activePack', before },
    );
  }
  setPreset(i: number) {
    const s = this.session!,
      before = s.preset;
    s.preset = i;
    this.log('rules', `Politika: ${PRESETS[i]!.n} (taikoma naujoms komandiruotėms)`, undefined, undefined, {
      type: 'preset',
      before,
    });
  }

  /* ---------- step 1: timesheet ---------- */
  async addMonth() {
    return this.run('Žiniaraščio įkėlimas', async () => {
      const f = await openBytes(['xlsx', 'xls']);
      if (f) await this.loadFile(f.bytes, f.name);
    });
  }
  async loadFile(bytes: Uint8Array, file: string) {
    this.load = true;
    this.issues = [];
    this.pend = null;
    this.last = { bytes, file };
    await new Promise((r) => setTimeout(r, 0));
    try {
      const pf = this.profile;
      let aoa: unknown[][];
      try {
        aoa = readAoa(bytes, pf);
      } catch (e) {
        const code = e instanceof Error && e.message === 'SHEET_NOT_FOUND' ? 'SHEET_NOT_FOUND' : 'FILE_UNREADABLE';
        this.issues = [{ level: 'error', code, params: {} }];
        return;
      }
      const per = periodOf(aoa, pf) ?? this.period;
      if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(per)) {
        this.issues = [{ level: 'error', code: 'PERIOD_NOT_FOUND', params: {} }];
        return;
      }
      const sh: ParsedSheet = { ...parseSheet(aoa, pf, per), file };
      this.issues = sh.issues;
      if (sh.issues.some((i) => i.level === 'error')) {
        if (sh.employees.length) this.pend = { sheet: sh, file };
        return;
      }
      await this.commit(sh);
    } finally {
      this.load = false;
    }
  }
  async retry() {
    return this.run('Žiniaraščio įkėlimas', async () => {
      if (this.last) await this.loadFile(this.last.bytes, this.last.file);
    });
  }
  private async commit(sh: ParsedSheet) {
    const s = this.session!,
      a = this.total;
    setSheet(s, sh);
    ensureInputs(s);
    await this.after();
    const n = this.trips.filter((x) => x.trip.days[0]!.d.startsWith(sh.period)).length;
    this.log(
      'import',
      `Įkeltas ${sh.file ?? sh.period}: ${n} komandiruotė(s) apskaičiuota automatiškai`,
      a,
      this.total,
    );
  }
  async acceptPending() {
    return this.run('Eilučių praleidimas', async () => {
      if (!this.pend) return;
      const sh = this.pend.sheet;
      this.pend = null;
      this.issues = [];
      this.skip = true;
      await this.commit(sh);
      this.log('import', 'Blogos eilutės praleistos');
    });
  }
  setProfile(id: string) {
    this.session!.profileId = id;
    this.rev++;
  }

  /* ---------- step 2: trips ---------- */
  private effective(i: number) {
    const x = this.curTrip!,
      d = x.trip.days[i]!,
      o = x.input?.days?.[d.d];
    const legs = [...(x.input?.legs ?? [])].sort((a, b) => a.from.localeCompare(b.from));
    const min = o?.min ?? d.min;
    return {
      h: min === null ? null : Math.round((min / 60) * 100) / 100,
      c: o?.place ?? (legs.length ? dayPlaces(legs, d.d)[0]! : (d.place ?? '')),
    };
  }
  openTrip(id: string) {
    this.sel = id;
    const x = this.trips.find((t) => t.trip.id === id)!;
    const r = x.input?.reduction;
    const e = x.trip.days.map((_, i) => this.effective(i));
    this.draft = {
      h: e.map((v) => v.h),
      c: e.map((v) => v.c),
      src: r?.source ?? 'none',
      pct: r && r.source !== 'none' ? r.bp / 100 : 100,
      note: x.input?.notified ?? true,
    };
  }
  /** TripInput from the draft; hand edits are kept only where they differ from the timesheet */
  private toInput(id: string, d: TripDraft): TripInput {
    const x = this.trips.find((t) => t.trip.id === id)!;
    const days: NonNullable<TripInput['days']> = {};
    const prev = x.input;
    x.trip.days.forEach((day, i) => {
      const o = { ...(prev?.days?.[day.d] ?? {}) } as { place?: string; min?: number };
      const base = prev?.legs.length ? undefined : day.place;
      if (d.c[i] && d.c[i] !== (base ?? '')) o.place = d.c[i];
      else if (o.place && d.c[i] === (base ?? '')) delete o.place;
      const m = d.h[i];
      if (m !== null && m !== undefined && Math.round(m * 60) !== day.min) o.min = Math.round(m * 60);
      else if (o.min !== undefined && (m === null || m === undefined || Math.round(m * 60) === day.min)) delete o.min;
      if (o.place !== undefined || o.min !== undefined) days[day.d] = o;
    });
    const bp = Math.round(d.pct * 100);
    return {
      employee: x.trip.employee,
      start: x.trip.days[0]!.d,
      legs: prev?.legs ?? [],
      reduction:
        d.src === 'none'
          ? { source: 'none', bp: 10000 }
          : { source: d.src, bp: Math.min(10000, Math.max(0, Number.isFinite(bp) ? bp : 0)) },
      notified: d.note,
      dailyReturn: prev?.dailyReturn ?? false,
      ...(Object.keys(days).length ? { days } : {}),
      ...(prev?.manual ? { manual: true } : {}),
    };
  }
  get canSave() {
    const p = this.preview,
      d = this.draft;
    return !!p && !!d && !p.issues.some((i) => DATA.has(i.code)) && d.pct >= 0 && d.pct <= 100;
  }
  private diffText(): string[] {
    const x = this.curTrip!,
      d = this.draft!,
      out: string[] = [];
    x.trip.days.forEach((day, i) => {
      const o = this.effective(i);
      if (o.h !== d.h[i])
        out.push(`${day.d.slice(5)} val. ${o.h === null ? '–' : num(o.h)} → ${d.h[i] === null ? '–' : num(d.h[i]!)}`);
      if (o.c !== d.c[i])
        out.push(`${day.d.slice(5)} valstybė ${o.c ? placeName(o.c) : '–'} → ${d.c[i] ? placeName(d.c[i]!) : '–'}`);
    });
    const r = x.input?.reduction;
    const was = `${SRC[r?.source ?? 'none']}${r && r.source !== 'none' ? ` ${r.bp / 100} %` : ''}`;
    const now = `${SRC[d.src]}${d.src !== 'none' ? ` ${d.pct} %` : ''}`;
    if (was !== now) out.push(`mažinimas ${was} → ${now}`);
    if (d.src !== 'none' && (x.input?.notified ?? true) !== d.note)
      out.push(`supažindinimas ${d.note ? 'yra' : 'nėra'}`);
    return out;
  }
  saveTrip(incomplete: boolean) {
    const s = this.session!,
      x = this.curTrip!;
    const diff = this.diffText(),
      a = this.total;
    const before = x.input ? (JSON.parse(JSON.stringify(x.input)) as TripInput) : null;
    const was = !!x.input?.incomplete;
    const inp: TripInput = {
      ...this.toInput(x.trip.id, this.draft!),
      ...(diff.length || x.input?.manual ? { manual: true } : {}),
      ...(incomplete ? { incomplete: true } : {}),
    };
    setInput(s, inp);
    if (incomplete !== was) diff.push(incomplete ? 'pažymėta nebaigta' : 'nebe nebaigta');
    this.sel = null;
    this.draft = null;
    this.rev++;
    if (diff.length)
      this.log(
        'trip',
        `${x.trip.employee}, ${x.trip.days[0]!.d.slice(5)} – ${x.trip.days[x.trip.days.length - 1]!.d.slice(5)}: ${diff.join('; ')}`,
        a,
        this.total,
        { type: 'trip', id: x.trip.id, before },
      );
    this.toast(incomplete ? 'Pažymėta nebaigta' : 'Komandiruotė išsaugota');
  }
  closeTrip() {
    this.sel = null;
    this.draft = null;
  }
  needs(t: (typeof this.trips)[number]) {
    return t.result.status !== 'excluded' && t.result.issues.some((i) => DATA.has(i.code));
  }
  statusOf(t: (typeof this.trips)[number]) {
    if (t.result.status === 'excluded') return 'pažymėta nebaigta';
    if (t.result.issues.some((i) => DATA.has(i.code))) return 'trūksta duomenų';
    return t.input?.manual ? 'patikrinta ranka' : 'automatiškai iš žiniaraščio';
  }

  /* ---------- rule packs and profiles ---------- */
  private packDraft(p: RulePack): PackDraft {
    return {
      n: p.label,
      sw: SWITCH_KEYS.map((k) => toAnswer(p.switches[k])),
      adv: {
        ca: p.params.caMinBp / 100,
        act: p.params.localMinBp / 100,
        h: (p.params.shortDayMin ?? 0) / 60,
        pc: p.params.shortDayBp / 100,
      },
    };
  }
  private profDraft(p: ImportProfile): ProfDraft {
    return {
      n: p.label,
      codes: p.ignore.join(', '),
      kmark: p.kMark,
      sheet: typeof p.sheet === 'number' ? String(p.sheet + 1) : p.sheet,
      hdr: String(p.dayHeaderRow + 1),
      nameCol: colName(p.nameCol),
      idxCol: p.indexCol === null ? '' : colName(p.indexCol),
      dayCol: colName(p.firstDayCol),
      step: String(p.dayColStep),
      row1: String(p.firstEmployeeRow + 1),
      per: String(p.rowsPerEmployee),
      placeOff: p.placeRowOffset === null ? '' : String(p.placeRowOffset),
      kOff: String(p.kRowOffset),
      yearCell: cellName(p.yearCell),
      monthCell: cellName(p.monthCell),
    };
  }
  editPack(id: string) {
    this.ed = { k: 'p', id, o: this.packDraft(this.packs.find((p) => p.id === id)!), err: '' };
  }
  editProf(id: string) {
    this.ed = { k: 'f', id, o: this.profDraft(this.profs.find((p) => p.id === id)!), err: '' };
  }
  private checkPack(o: PackDraft) {
    const a = o.adv;
    if (!o.n.trim()) return 'Įrašykite paketo pavadinimą.';
    if (![a.ca, a.act, a.pc].every((v) => v >= 0 && v <= 100) || !(a.h >= 0 && a.h <= 24))
      return 'Teisinės ribos už leistino intervalo: procentai 0–100, valandos 0–24.';
    return '';
  }
  private toProfile(o: ProfDraft, base: ImportProfile): ImportProfile | string {
    const n = (s: string) => (/^\d+$/.test(s.trim()) ? Number(s.trim()) : NaN);
    const yc = o.yearCell.trim() ? cell(o.yearCell) : null,
      mc = o.monthCell.trim() ? cell(o.monthCell) : null;
    if (!o.n.trim()) return 'Įrašykite profilio pavadinimą.';
    if (!o.kmark.trim()) return 'Nurodykite komandiruotės žymę (pvz. K).';
    if (![o.nameCol, o.dayCol].every(isCol) || (o.idxCol.trim() && !isCol(o.idxCol)))
      return 'Stulpelius nurodykite raidėmis (pvz. F, AC).';
    if ([o.hdr, o.step, o.row1, o.per].some((v) => !(n(v) >= 1)) || !(n(o.kOff) >= 0))
      return 'Eilučių ir žingsnio laukai turi būti sveiki skaičiai.';
    if (o.placeOff.trim() && !(n(o.placeOff) >= 0)) return 'Šalių eilutės poslinkis turi būti skaičius arba tuščias.';
    if ((o.yearCell.trim() && !yc) || (o.monthCell.trim() && !mc))
      return 'Metų ir mėnesio langelius nurodykite kaip T11, AI11 arba palikite tuščius.';
    return {
      ...base,
      label: o.n.trim(),
      sheet: /^\d+$/.test(o.sheet.trim()) ? Number(o.sheet.trim()) - 1 : o.sheet.trim() || 0,
      dayHeaderRow: n(o.hdr) - 1,
      firstDayCol: col(o.dayCol),
      dayColStep: n(o.step),
      nameCol: col(o.nameCol),
      indexCol: o.idxCol.trim() ? col(o.idxCol) : null,
      firstEmployeeRow: n(o.row1) - 1,
      rowsPerEmployee: n(o.per),
      placeRowOffset: o.placeOff.trim() ? n(o.placeOff) : null,
      kRowOffset: n(o.kOff),
      yearCell: yc && mc ? yc : null,
      monthCell: yc && mc ? mc : null,
      kMark: o.kmark.trim().toUpperCase(),
      ignore: o.codes
        .split(/[\s,;]+/)
        .filter(Boolean)
        .map((x) => x.toUpperCase()),
    };
  }
  async commitEdit() {
    const ed = this.ed;
    if (!ed) return;
    const s = this.session!,
      a = this.total;
    try {
      if (ed.k === 'p') {
        const err = this.checkPack(ed.o);
        if (err) return void (ed.err = err);
        const cur = this.packs.find((p) => p.id === ed.id)!,
          v = await this.repo.nextVersion('packs', ed.id);
        const o = ed.o,
          ca = Math.round(o.adv.ca * 100),
          act = Math.round(o.adv.act * 100);
        await this.repo.savePack({
          ...cur,
          version: v,
          label: o.n.trim(),
          switches: Object.fromEntries(SWITCH_KEYS.map((k, i) => [k, fromAnswer(o.sw[i]!)])) as RulePack['switches'],
          params: {
            ...cur.params,
            caMinBp: ca,
            localMinBp: act,
            shortDayMin: Math.round(o.adv.h * 60),
            shortDayBp: Math.round(o.adv.pc * 100),
          },
        });
        s.packs = await this.repo.packs();
        this.rev++;
        this.log('rules', `Paketas „${o.n.trim()}“ v${cur.version} → v${v}`, a, this.total, {
          type: 'pack',
          before: cur,
        });
        this.toast(`Išsaugota kaip v${v}, ankstesnė versija palikta`);
      } else {
        const cur = this.profs.find((p) => p.id === ed.id)!,
          p = this.toProfile(ed.o, cur);
        if (typeof p === 'string') return void (ed.err = p);
        const v = await this.repo.nextVersion('profiles', ed.id);
        const parsed = ImportProfile.safeParse({ ...p, version: v });
        if (!parsed.success) return void (ed.err = 'Profilio laukai neteisingi.');
        await this.repo.saveProfile(parsed.data);
        this.profiles = await this.repo.profiles();
        this.log('rules', `Profilis „${p.label}“ v${cur.version} → v${v}`, undefined, undefined, {
          type: 'profile',
          before: cur,
        });
        this.toast(`Išsaugota kaip v${v}, ankstesnė versija palikta`);
      }
      this.ed = null;
    } catch (e) {
      ed.err = e instanceof Error ? e.message : String(e);
    }
  }
  async copyPack(label: string, from: string) {
    const id = `pk-${Date.now().toString(36)}`;
    const series = this.session!.packs.filter((p) => p.id === from);
    await this.repo.saveMany(
      'packs',
      series.map((p) => ({ ...p, id, label })),
    );
    this.session!.packs = await this.repo.packs();
    this.rev++;
    this.log('rules', `Sukurtas paketas „${label}“`);
    this.editPack(id);
  }
  async newPack() {
    return this.run('Naujo paketo kūrimas', () => this.copyPack('Naujas paketas', 'LT-526'));
  }
  async dupPack() {
    return this.run('Paketo dubliavimas', async () => {
      const id = this.ed?.k === 'p' ? this.ed.id : this.session!.activePack;
      await this.copyPack(`${this.packs.find((p) => p.id === id)!.label} (kopija)`, id);
    });
  }
  async copyProf(label: string, from: ImportProfile) {
    const id = `pf-${Date.now().toString(36)}`;
    await this.repo.saveProfile({ ...from, id, version: 1, label });
    this.profiles = await this.repo.profiles();
    this.log('rules', `Sukurtas profilis „${label}“`);
    this.editProf(id);
  }
  async newProf() {
    return this.run('Naujo profilio kūrimas', () =>
      this.copyProf(
        'Naujas profilis',
        this.profiles.find((p) => p.id === 'default')!,
      ),
    );
  }
  async dupProf() {
    return this.run('Profilio dubliavimas', async () => {
      const id = this.ed?.k === 'f' ? this.ed.id : this.profile.id;
      const p = this.profs.find((x) => x.id === id)!;
      await this.copyProf(`${p.label} (kopija)`, p);
    });
  }
  exportEdit(kind: 'p' | 'f') {
    const id = this.ed?.k === kind ? this.ed.id : kind === 'p' ? this.pack.id : this.profile.id;
    const data =
      kind === 'p' ? this.session!.packs.filter((p) => p.id === id) : this.profiles.filter((p) => p.id === id);
    return saveBytes(`${kind === 'p' ? 'paketas' : 'profilis'}-${id}.json`, JSON.stringify(data, null, 2));
  }
  async importEdit(kind: 'p' | 'f') {
    return this.run('Importas', async () => {
      const f = await openBytes(['json']);
      if (!f) return;
      try {
        const raw = JSON.parse(new TextDecoder().decode(f.bytes)) as unknown;
        const list = (Array.isArray(raw) ? raw : [raw]).map((x) => migrate(x));
        const id = `${kind === 'p' ? 'pk' : 'pf'}-${Date.now().toString(36)}`;
        if (kind === 'p') {
          await this.repo.saveMany(
            'packs',
            list.map((x) => ({ ...RulePack.parse(x), id })),
          );
          this.session!.packs = await this.repo.packs();
          this.rev++;
          this.editPack(id);
        } else {
          await this.repo.saveMany(
            'profiles',
            list.map((x) => ({ ...ImportProfile.parse(x), id })),
          );
          this.profiles = await this.repo.profiles();
          this.editProf(id);
        }
        this.log('rules', `Importuota: ${f.name}`);
      } catch (e) {
        this.err = `Nepavyko importuoti: ${e instanceof Error ? e.message : String(e)}`;
      }
    });
  }

  /* ---------- rates ---------- */
  openRates() {
    const l = this.session!.rates;
    this.rd = {
      r: l.rows.map((r) => ({ c: placeName(r.place), e: r.cents / 100, f: r.validFrom })),
      u: l.sourceUrl,
      err: '',
    };
  }
  addRateRow() {
    this.rd?.r.push({ c: '', e: 0, f: '' });
  }
  private toList(): RateList | string {
    const rd = this.rd!,
      rows: RateList['rows'] = [];
    for (const [i, r] of rd.r.entries()) {
      const code = placeCode(r.c);
      if (!code) return `${i + 1} eilutė: nežinoma valstybė „${r.c}“.`;
      if (!(r.e > 0)) return `${i + 1} eilutė: tarifas turi būti didesnis už 0.`;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(r.f)) return `${i + 1} eilutė: nurodykite galiojimo datą.`;
      rows.push({ place: code, cents: Math.round(r.e * 100), validFrom: r.f });
    }
    if (!/^https?:\/\//.test(rd.u.trim())) return 'Tarifų lentelės nuoroda turi prasidėti http:// arba https://';
    const list: RateList = {
      schema: 1,
      sourceUrl: rd.u.trim(),
      rows: rows.sort((a, b) => a.place.localeCompare(b.place) || a.validFrom.localeCompare(b.validFrom)),
    };
    const dup = checkRates(list)[0];
    return dup ? msg(dup) : list;
  }
  async commitRates() {
    return this.run('Tarifų išsaugojimas', async () => {
      const rd = this.rd!,
        l = this.toList();
      if (typeof l === 'string') return void (rd.err = l);
      const s = this.session!,
        a = this.total,
        before = s.rates,
        h0 = this.stamp;
      try {
        await this.repo.saveRates(l);
      } catch (e) {
        return void (rd.err = e instanceof Error ? e.message : String(e));
      }
      setRates(s, l);
      await this.after();
      rd.err = '';
      this.log('rates', `Tarifai atnaujinti: hash ${h0} → ${this.stamp}`, a, this.total, { type: 'rates', before });
      this.toast('Tarifų sąrašas išsaugotas kaip nauja versija, ankstesnė palikta');
      this.openRates();
    });
  }
  async importRateRows() {
    return this.run('Tarifų importas', async () => {
      const f = await openBytes(['xlsx', 'xls', 'csv']);
      if (!f || !this.rd) return;
      const { rows, issues } = parseRates(readSheet(f.bytes, 0));
      if (issues.some((i) => i.level === 'error'))
        return void (this.rd.err = msgs(issues.filter((i) => i.level === 'error'))[0]!.text);
      for (const r of rows) {
        const row = { c: placeName(r.place), e: r.cents / 100, f: r.validFrom };
        const at = this.rd.r.findIndex((x) => placeCode(x.c) === r.place && x.f === r.validFrom);
        if (at >= 0) this.rd.r[at] = row;
        else this.rd.r.push(row);
      }
      this.rd.err = '';
    });
  }
  exportRates() {
    return saveBytes('tarifai.xlsx', ratesToXlsx(this.session!.rates));
  }

  /* ---------- results, sessions, history ---------- */
  private async writeOut(kind: string, name: string, data: Uint8Array | string) {
    if ((await saveBytes(name, data)) === false) return this.toast('Eksportas atšauktas');
    this.log('export', `${kind} eksportuotas, tarifų hash ${this.stamp}`);
  }
  exportCsv() {
    return this.writeOut(
      'CSV',
      `dienpinigiai-${this.months.map((m) => m.period).join('+')}.csv`,
      toCsv(toRows(this.res())),
    );
  }
  exportXlsx() {
    return this.writeOut('XLSX', `dienpinigiai-${this.months.map((m) => m.period).join('+')}.xlsx`, toXlsx(this.res()));
  }
  private res() {
    return { months: this.calc, cents: this.total, stamp: { app: APP, ratesSha: this.stamp, rulesSha: '' } };
  }
  async stampFull() {
    return calculate(this.session!);
  }
  async saveSession() {
    return this.run('Sesijos išsaugojimas', async () => {
      const s = this.session!;
      const p2 = (n: number) => String(n).padStart(2, '0');
      /** local time, "2026-10-28 17-27"; ':' is illegal in Windows file names */
      const stampName = (d: Date) =>
        `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}-${p2(d.getMinutes())}`;
      /** " xlsx" / " xlsx csv": distinct source extensions of the loaded sheets, "" if none */
      const srcKind = (ms: { file?: string }[]) => {
        const e = [...new Set(ms.map((m) => m.file?.match(/\.(\w+)$/)?.[1]?.toLowerCase()).filter(Boolean))];
        return e.length ? ' ' + e.join(' ') : '';
      };
      if (!this.months.length) return this.toast('Nėra ką saugoti');
      const savedAt = new Date().toISOString();
      const name = `${stampName(new Date())} (${this.months.map((m) => m.period).join(' + ')}${srcKind(this.months)}).dpsesija`;
      if ((await saveBytes(name, JSON.stringify({ ...s, name, savedAt }))) === false)
        return this.toast('Saugojimas atšauktas');
      s.savedAt = savedAt;
      s.name = name;
      this.sess = `Sesija „${s.name}“ · išsaugota, tarifų hash ${this.stamp}`;
      this.log('session', `Sesija išsaugota (${s.history.length} įrašai istorijoje, tarifų hash ${this.stamp})`);
      this.toast('Sesija išsaugota');
    });
  }
  async pickSession() {
    return this.run('Sesijos atidarymas', async () => {
      const f = await openBytes(['dpsesija', 'json']);
      if (!f) return;
      try {
        this.opened = { session: Session.parse(migrate(JSON.parse(new TextDecoder().decode(f.bytes)))), name: f.name };
      } catch (e) {
        throw new Error(`netinkamas sesijos failas (${e instanceof Error ? e.message.slice(0, 80) : ''})`, {
          cause: e,
        });
      }
      this.modal = 'open';
    });
  }
  async loadSaved(recalc: boolean) {
    return this.run('Sesijos atidarymas', async () => {
      const o = this.opened!;
      this.session = o.session;
      if (recalc) {
        await syncSnapshot(this.session, this.repo);
        if (!this.session.packs.some((p) => p.id === this.session!.activePack)) this.session.activePack = 'LT-526';
      }
      await this.after();
      this.sess = `Sesija „${o.name}“ · atidaryta${recalc ? ', perskaičiuota' : ', palikta išsaugota'}`;
      this.modal = '';
      this.opened = null;
      this.tab = 0;
      this.step = 4;
      this.toast(recalc ? 'Perskaičiuota su dabartinėmis taisyklėmis ir tarifais' : 'Palikti išsaugoti rezultatai');
    });
  }
  async undo(e: HistEntry) {
    return this.run('Pakeitimo atšaukimas', async () => {
      await undoHist(this.session!, this.repo, e.id);
      this.profiles = await this.repo.profiles();
      await this.after();
      this.toast('Pakeitimas atšauktas');
    });
  }
}
const DATA = new Set(['NO_PLACE', 'NO_HOURS', 'REDUCTION_BELOW_MIN']);
export const ui = new Ui();
export { eur, monthLabel };
