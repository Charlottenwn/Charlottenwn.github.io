<script lang="ts">
  import { ink } from './cls';
  let { kind, text }: { kind: 'error' | 'warn'; text: string } = $props();
</script>

<div
  class="border-l-2 {kind === 'error'
    ? 'border-slate-900 dark:border-white'
    : 'border-slate-300 dark:border-slate-600'} pl-4 py-1 my-4 text-sm leading-7 {ink}"
>
  <span class="font-semibold">{kind === 'error' ? 'Klaida. ' : 'Pastaba. '}</span>{text}
</div>
