<script lang="ts">
  import { acc, btn, inp, lab, line, mut, pri } from './cls';
  import Head from './Head.svelte';
  import Msg from './Msg.svelte';
  import { ui } from './state.svelte';
</script>

{#if ui.rd}
  {@const rd = ui.rd}
  <Head
    t="Tarifai"
    s="Atnaujinami ranka arba importuojami iš Excel lentelės (valstybė, EUR, galioja nuo). Kiekvienas išsaugojimas sukuria naują versiją, ankstesnė paliekama."
  />
  <div class="flex flex-wrap gap-2 mt-8">
    <button class={btn} onclick={() => ui.addRateRow()}>Pridėti eilutę</button>
    <button class={btn} onclick={() => ui.importRateRows()}>Importuoti</button>
    <button class={btn} onclick={() => ui.run('Tarifų eksportas', async () => ui.exportRates())}>Eksportuoti</button>
  </div>
  {#if rd.err}<Msg kind="error" text={rd.err} />{/if}
  <div class="overflow-x-auto mt-6">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left {mut}">
          <th class="font-normal pb-2">Valstybė ar miestas</th><th class="font-normal pb-2">EUR per dieną</th>
          <th class="font-normal pb-2">Galioja nuo</th><th></th>
        </tr>
      </thead>
      <tbody>
        {#each rd.r as r, i (i)}
          <tr class="border-t {line}">
            <td class="py-2 pr-3"><input class={inp} aria-label="Valstybė" bind:value={r.c} /></td>
            <td class="pr-3">
              <input type="number" step="0.01" class="{inp} !w-28" aria-label="EUR per dieną" bind:value={r.e} />
            </td>
            <td class="pr-3"><input type="date" class={inp} aria-label="Galioja nuo" bind:value={r.f} /></td>
            <td><button class={btn} onclick={() => rd.r.splice(i, 1)}>Šalinti</button></td>
          </tr>
        {:else}
          <tr><td colspan="4" class="py-6 {mut}">Tarifų nėra. Pridėkite eilutę arba importuokite Excel lentelę.</td></tr
          >
        {/each}
      </tbody>
    </table>
  </div>
  <label class="block mt-8"
    ><span class={lab}>Tarifų lentelės nuoroda</span><input
      class={inp}
      aria-label="Tarifų lentelės nuoroda"
      bind:value={rd.u}
    /></label
  >
  <div class="mt-8 flex items-center gap-4">
    <button class={pri} onclick={() => ui.commitRates()}>Tikrinti ir išsaugoti</button>
    <button class="text-sm underline {acc}" onclick={() => ui.link(rd.u)}>Atidaryti nuorodą</button>
  </div>
{/if}
