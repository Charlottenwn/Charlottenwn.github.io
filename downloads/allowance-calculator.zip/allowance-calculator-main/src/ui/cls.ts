export const card = 'border border-slate-200/70 dark:border-white/10 bg-white dark:bg-slate-900/40 p-8';
export const btn =
  'inline-flex items-center rounded-md border border-slate-200 dark:border-white/10 px-3.5 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-white/5 disabled:opacity-40 disabled:cursor-not-allowed focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700';
export const pri =
  'inline-flex items-center rounded-md bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700';
export const inp =
  'w-full rounded-md border border-slate-200 dark:border-white/10 bg-transparent px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-emerald-700';
export const lab = 'block text-xs text-slate-500 dark:text-slate-400 mb-1.5';
export const ink = 'text-slate-900 dark:text-slate-100';
export const mut = 'text-slate-500 dark:text-slate-400';
export const acc = 'text-emerald-700 dark:text-emerald-400';
export const line = 'border-slate-200/70 dark:border-white/10';
