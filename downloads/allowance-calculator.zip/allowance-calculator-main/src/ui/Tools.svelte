<script lang="ts">
  import { btn } from './cls';
  import { ui } from './state.svelte';

  let { kind }: { kind: 'p' | 'f' } = $props();
</script>

<div class="flex flex-wrap gap-2 mt-8">
  <button class={btn} onclick={() => (kind === 'p' ? ui.newPack() : ui.newProf())}>Naujas</button>
  <button class={btn} onclick={() => ui.importEdit(kind)}>Importuoti failą</button>
  <button class={btn} onclick={() => ui.run('Eksportas', async () => ui.exportEdit(kind))}>Eksportuoti failą</button>
  <button class={btn} onclick={() => (kind === 'p' ? ui.dupPack() : ui.dupProf())}>Dubliuoti</button>
</div>
