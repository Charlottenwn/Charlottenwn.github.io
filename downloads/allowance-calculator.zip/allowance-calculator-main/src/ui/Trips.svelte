<script lang="ts">
  import { acc, btn, line, mut, pri } from './cls';
  import Head from './Head.svelte';
  import { MAX_MONTHS, ui } from './state.svelte';
  import { eur, monthLabel } from './strings';
  import TripDetail from './TripDetail.svelte';

  const sum = (r: { lines: { cents: number }[] }) => r.lines.reduce((a, l) => a + l.cents, 0);
</script>

{#if ui.sel === null}
  <Head
    t="Komandiruotės"
    s="Aptiktos ir apskaičiuotos automatiškai iš žiniaraščio: K žymos nustato dienas, K dienų valandos nustato pirmos ir paskutinės dienos dalį (mažiau nei 4 val. = 20 %), valstybių kodai nustato tarifus."
  />
  <div class="mt-10 space-y-10">
    {#each ui.months as x (x.period)}
      <section>
        <h3 class="text-xs font-semibold tracking-tight {mut}">{monthLabel(x.period)}</h3>
        <div class="mt-3 border-t {line}">
          {#each ui.trips.filter((t) => t.trip.days[0]!.d.startsWith(x.period)) as t (t.trip.id)}
            <button
              class="w-full flex justify-between items-center py-5 border-b {line} text-left hover:bg-slate-50 dark:hover:bg-white/5 px-2"
              onclick={() => ui.openTrip(t.trip.id)}
            >
              <span>
                <span class="font-medium">{t.trip.employee}</span>
                <span class="font-mono text-xs ml-4 {mut}"
                  >{t.trip.days[0]!.d} – {t.trip.days[t.trip.days.length - 1]!.d}</span
                >
              </span>
              <span class="flex items-center gap-6">
                <span class="font-mono text-sm">{eur(sum(t.result))}</span>
                <span class="text-sm w-52 text-right {ui.needs(t) || t.result.status === 'excluded' ? mut : acc}">
                  {ui.statusOf(t)}
                </span>
              </span>
            </button>
          {:else}
            <p class="py-5 text-sm {mut}">Komandiruočių šį mėnesį nėra.</p>
          {/each}
        </div>
      </section>
    {/each}
  </div>
  <div class="mt-10 flex gap-3">
    <button class={btn} disabled={ui.months.length >= MAX_MONTHS} onclick={() => ui.addMonth()}>Pridėti mėnesį</button>
    <button class={pri} disabled={!ui.tOk} onclick={() => ui.go(3)}>Toliau</button>
  </div>
{:else}
  <TripDetail />
{/if}
