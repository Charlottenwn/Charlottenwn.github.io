const RAW = `AL:Albanija|AD:Andora|AM:Armėnija|AT:Austrija|AZ:Azerbaidžanas|BY:Baltarusija|BE:Belgija|BA:Bosnija ir Hercegovina|BG:Bulgarija|HR:Kroatija|CY:Kipras|CZ:Čekija|DK:Danija|EE:Estija|FI:Suomija|FR:Prancūzija|GE:Gruzija|DE:Vokietija|GR:Graikija|HU:Vengrija|IS:Islandija|IE:Airija|IT:Italija|XK:Kosovas|LV:Latvija|LI:Lichtenšteinas|LT:Lietuva|LU:Liuksemburgas|MT:Malta|MD:Moldova|MC:Monakas|ME:Juodkalnija|NL:Nyderlandai|MK:Šiaurės Makedonija|NO:Norvegija|PL:Lenkija|PT:Portugalija|RO:Rumunija|RU:Rusija|SM:San Marinas|RS:Serbija|SK:Slovakija|SI:Slovėnija|ES:Ispanija|SE:Švedija|CH:Šveicarija|TR:Turkija|UA:Ukraina|GB:Jungtinė Karalystė|VA:Vatikanas|US:Jungtinės Amerikos Valstijos|CA:Kanada|MX:Meksika|BR:Brazilija|AR:Argentina|CL:Čilė|CO:Kolumbija|PE:Peru|UY:Urugvajus|PA:Panama|CR:Kosta Rika|DO:Dominikos Respublika|CU:Kuba|JM:Jamaika|CN:Kinija|JP:Japonija|KR:Pietų Korėja|IN:Indija|SG:Singapūras|HK:Honkongas|TW:Taivanas|TH:Tailandas|VN:Vietnamas|ID:Indonezija|MY:Malaizija|PH:Filipinai|PK:Pakistanas|BD:Bangladešas|LK:Šri Lanka|KZ:Kazachstanas|UZ:Uzbekistanas|KG:Kirgizija|TJ:Tadžikistanas|TM:Turkmėnistanas|IR:Iranas|IQ:Irakas|IL:Izraelis|JO:Jordanija|LB:Libanas|AE:Jungtiniai Arabų Emyratai|SA:Saudo Arabija|QA:Kataras|KW:Kuveitas|OM:Omanas|BH:Bahreinas|AU:Australija|NZ:Naujoji Zelandija|ZA:Pietų Afrikos Respublika|EG:Egiptas|MA:Marokas|DZ:Alžyras|TN:Tunisas|NG:Nigerija|KE:Kenija|ET:Etiopija|GH:Gana|SN:Senegalas`;
export const NAMES: Record<string, string> = Object.fromEntries(
  RAW.split('|').map((x) => x.split(':') as [string, string]),
);
const BY_NAME = new Map(Object.entries(NAMES).map(([c, n]) => [n.toLowerCase(), c]));

/** "DE" -> "Vokietija", "DE/Berlin" -> "Vokietija / Berlin", unknown codes stay as they are */
export function placeName(code: string): string {
  const [c, ...city] = code.split('/');
  return (NAMES[c!] ?? c!) + (city.length ? ` / ${city.join('/')}` : '');
}
/** "Vokietija", "vokietija / Berlin", "DE", "de/Berlin" -> "DE" / "DE/Berlin"; null when unknown */
export function placeCode(text: string): string | null {
  const [a, ...city] = text.split('/').map((x) => x.trim());
  const c =
    BY_NAME.get((a ?? '').toLowerCase()) ?? ((a ?? '').toUpperCase().match(/^[A-Z]{2}$/) ? a!.toUpperCase() : null);
  return c ? c + (city.filter(Boolean).length ? `/${city.filter(Boolean).join('/')}` : '') : null;
}
