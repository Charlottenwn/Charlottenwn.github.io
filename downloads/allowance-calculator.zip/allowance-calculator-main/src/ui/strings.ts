import type { Issue, Switches } from '../core/schema';
import { placeName } from './places';

export const NAV = ['Skaičiuoti', 'Taisyklių paketai', 'Profiliai', 'Tarifai', 'Istorija'];
export const STEPS = ['Paketas ir politika', 'Žiniaraštis ir profilis', 'Komandiruotės', 'Patikra', 'Rezultatas'];

/** the four questions the regulation leaves open, in the order of the pack screen */
export const SWITCH_KEYS: (keyof Switches)[] = [
  'dailyReturnIsOneTrip',
  'shortRuleOnOneDayAbroad',
  'ltLongerThanWorkdayIsMultiDay',
  'shortRuleOnReducedRate',
];
export const SW: Record<keyof Switches, string> = {
  dailyReturnIsOneTrip:
    'Ar kelių dienų komandiruotė Lietuvoje, iš kurios darbuotojas kasdien grįžta, laikoma viena komandiruote?',
  shortRuleOnOneDayAbroad:
    'Ar 20 % taisyklė taikoma vienos dienos komandiruotei į užsienį, jei ji trunka trumpiau nei 4 val.?',
  ltLongerThanWorkdayIsMultiDay:
    'Ar Lietuvoje komandiruotė, trunkanti ilgiau nei darbo diena, laikoma trunkančia ilgiau nei 1 dieną?',
  shortRuleOnReducedRate: 'Ar 20 % taisyklė skaičiuojama nuo sumažinto tarifo, o ne nuo maksimalaus?',
};
/** one example per question, from the Atmintinė; "taip" / "ne" explained in terms of the result */
export const HINT: Record<keyof Switches, string> = {
  dailyReturnIsOneTrip:
    'Pvz., komandiruotės įsakyme nurodyta, kad komandiruotė Lietuvoje trunka kelias dienas, bet darbuotojas kasdien grįžta. „Taip“ – viena kelių dienų komandiruotė, dienpinigiai mokami. „Ne“ – kelios atskiros vienos dienos komandiruotės, dienpinigiai nemokami.',
  shortRuleOnOneDayAbroad:
    'Pvz., darbuotojas vienai dienai vyksta į užsienį ir visa komandiruotė trunka trumpiau nei 4 val. „Taip“ – mokama 20 % dienpinigių. „Ne“ – mokama 100 %.',
  ltLongerThanWorkdayIsMultiDay:
    'Pvz., vienos dienos komandiruotė Lietuvoje trunka ilgiau nei darbuotojo įprasta darbo diena (pvz., daugiau nei 8 val.). „Taip“ – dienpinigiai mokami. „Ne“ – nemokami.',
  shortRuleOnReducedRate:
    'Pvz., įmonėje taikoma 50 % dienpinigių norma, o pirma ar paskutinė komandiruotės diena trunka trumpiau nei 4 val. „Taip“ – 20 % skaičiuojama nuo sumažintos normos (faktiškai 10 % maksimalios). „Ne“ – 20 % nuo maksimalios normos.',
};
export const ANSWER = ['nepasirinkta', 'taip', 'ne'];
export const toAnswer = (v: boolean | null) => (v === null ? 0 : v ? 1 : 2);
export const fromAnswer = (n: number): boolean | null => (n === 0 ? null : n === 1);

const M: Record<string, string> = {
  BAD_SESSION: 'Nepavyko atidaryti sesijos failo: {value}',
  SHEET_NOT_FOUND: 'Faile nerastas reikiamas lapas.',
  FILE_UNREADABLE: 'Failo nepavyko perskaityti. Patikrinkite, ar tai .xlsx failas.',
  PERIOD_NOT_FOUND: 'Nepavyko nustatyti mėnesio iš žiniaraščio antraštės. Įveskite jį žemiau.',
  HEADER_DAY_MISMATCH:
    'Netinka dienų antraštė (stulpelis {col}): tikėtasi {expected}, rasta {got}. Patikrinkite profilį ir mėnesį.',
  BAD_CELL: '{name}, {date}: kodas „{value}“ neatpažintas',
  BAD_K_CELL: '{name}, {date}: nesuprantamas komandiruotės žymėjimas „{value}“',
  BAD_PLACE: 'Neteisingas šalies kodas „{value}“ (tikėtasi pvz. LT arba DE/Berlin).',
  DUP_EMPLOYEE: 'Darbuotojas „{name}“ pasikartoja žiniaraštyje.',
  NO_POLICY: 'Nėra galiojančios darbdavio politikos {date}.',
  NO_PACK: 'Nėra galiojančio taisyklių paketo {date}.',
  NO_PLACE: '{date}: nenurodyta valstybė.',
  NO_RATE: 'Nėra tarifo: {place}, {date}',
  NO_HOURS: '{date}: nenurodytos valandos.',
  SWITCH_UNRESOLVED: 'Neišspręstas klausimas: {label}',
  LOCAL_ACT_TRIP_TOO_SHORT: 'Vietiniu aktu mažinti galima nuo {min} dienų komandiruotės. Taikoma 100 %.',
  NOT_NOTIFIED: 'Nėra rašytinio supažindinimo iki išvykimo. Taikoma 100 %.',
  MARKED_INCOMPLETE: 'Pažymėta nebaigta, į sumą neįtraukta.',
  MONTH_EDGE_TRIP: 'Komandiruotė {edge} mėnesio riba ({date}), o gretimas mėnuo neįkeltas. Įkelkite jį.',
  DUP_RATE: 'Pasikartojanti norma: {place} {from}.',
  BAD_RATE: '{row} eilutė: neteisinga norma „{value}“.',
  BAD_DATE: '{row} eilutė: neteisinga data „{value}“.',
  RATE_ROUNDED: '{row} eilutė: norma suapvalinta iki centų ({value}).',
  MISSING_COLUMNS: 'Trūksta stulpelių: {columns}.',
  BAD_EMPLOYEE: '{row} eilutė: nenurodytas darbuotojas.',
  BAD_FLAG: '{row} eilutė: laukas {field} turi būti taip arba ne.',
  BAD_REDUCTION: '{row} eilutė: mažinimas turi būti none, ca arba local („{value}“).',
  BAD_PCT: '{row} eilutė: neteisingi procentai „{value}“ (rašykite pvz. 50 arba 50 %).',
  DUP_LEG: '{row} eilutė: pasikartojantis atkarpos įrašas {place} {from}.',
  INCONSISTENT_TRIP: '{row} eilutė: lauko {field} reikšmė nesutampa su pirmąja komandiruotės eilute.',
  FIRST_LEG_AFTER_START: '{employee}, {start}: pirma atkarpa prasideda vėliau nei komandiruotė.',
  LEG_BEFORE_START: '{employee}, {start}: yra atkarpa, prasidedanti prieš komandiruotę.',
};

export function msg(i: Issue): string {
  const p: Record<string, string | number> = { ...i.params };
  if (typeof p.place === 'string' && i.code !== 'DUP_LEG' && i.code !== 'DUP_RATE') p.place = placeName(p.place);
  if (i.code === 'SWITCH_UNRESOLVED') p.label = SW[p.key as keyof Switches] ?? p.key ?? '';
  if (i.code === 'MONTH_EDGE_TRIP')
    p.edge = p.edge === 'start' ? 'prasideda ties ankstesnio mėnesio riba' : 'baigiasi ties kito mėnesio riba';
  if (i.code === 'REDUCTION_BELOW_MIN')
    return `${p.source === 'ca' ? 'Kolektyvinėje sutartyje' : 'Vietiniu aktu'} negalima mažinti žemiau ${Number(p.min) / 100} %. Atmesta.`;
  return (M[i.code] ?? i.code).replace(/\{(\w+)\}/g, (_, k: string) => String(p[k] ?? ''));
}

/** the same message for several dates ("2026-09-07 … 2026-09-11 (5 d.)") becomes one line */
export function msgs(list: Issue[]): { level: Issue['level']; text: string }[] {
  const out: { level: Issue['level']; text: string }[] = [];
  const groups = new Map<string, { first: Issue; dates: string[]; at: number }>();
  for (const i of list) {
    if (typeof i.params.date !== 'string') {
      out.push({ level: i.level, text: msg(i) });
      continue;
    }
    const { date, ...rest } = i.params;
    const k = i.code + JSON.stringify(rest);
    const g = groups.get(k);
    if (g) g.dates.push(String(date));
    else {
      groups.set(k, { first: i, dates: [String(date)], at: out.length });
      out.push({ level: i.level, text: '' });
    }
  }
  for (const g of groups.values()) {
    const d = g.dates;
    const label = d.length > 3 ? `${d[0]} … ${d[d.length - 1]} (${d.length} d.)` : d.join(', ');
    out[g.at] = { level: g.first.level, text: msg({ ...g.first, params: { ...g.first.params, date: label } }) };
  }
  return out;
}

export const eur = (c: number) => (c / 100).toFixed(2).replace('.', ',') + ' €';
export const num = (x: number) => String(Math.round(x * 100) / 100).replace('.', ',');
const MONTHS = [
  'sausis',
  'vasaris',
  'kovas',
  'balandis',
  'gegužė',
  'birželis',
  'liepa',
  'rugpjūtis',
  'rugsėjis',
  'spalis',
  'lapkritis',
  'gruodis',
];
export const monthLabel = (ym: string) => `${ym.slice(0, 4)} ${MONTHS[Number(ym.slice(5)) - 1]}`;

/** Lithuanian plural: 1 mėnuo, 2 mėnesiai, 10 mėnesių */
export const plural = (n: number, one: string, few: string, many: string) =>
  n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && (n % 100 < 10 || n % 100 >= 20) ? few : many;
