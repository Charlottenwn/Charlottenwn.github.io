<script lang="ts">
  import { btn, inp, lab, line, mut, pri } from './cls';
  import Head from './Head.svelte';
  import Msg from './Msg.svelte';
  import { placeName } from './places';
  import { ui } from './state.svelte';
  import { eur, msgs } from './strings';

  const t = $derived(ui.curTrip!);
  const d = $derived(ui.draft!);
  const p = $derived(ui.preview);
  const shown = $derived(msgs((p?.issues ?? []).filter((i) => i.code !== 'NO_RATE' && i.code !== 'SWITCH_UNRESOLVED')));
  const options = $derived([...new Set([...ui.places, ...d.c.filter(Boolean)])]);
</script>

{#if t && d && p}
  <Head
    t={t.trip.employee}
    s="{t.trip.days[0]!.d} – {t.trip.days[t.trip.days.length - 1]!
      .d}. Dienos, valandos ir valstybės paimtos iš žiniaraščio. Pataisykite tik jei reikia."
  />
  <table class="w-full text-sm mt-10">
    <thead>
      <tr class="text-left {mut}">
        <th class="font-normal pb-2">Diena</th><th class="font-normal pb-2">Valandos</th>
        <th class="font-normal pb-2">Valstybė</th>
      </tr>
    </thead>
    <tbody>
      {#each t.trip.days as day, i (day.d)}
        <tr class="border-t {line}">
          <td class="py-2 font-mono text-xs">{day.d}</td>
          <td class="py-2 pr-4">
            <input
              type="number"
              step="0.5"
              min="0"
              max="24"
              aria-label="Valandos {day.d}"
              class="{inp} !w-24"
              bind:value={d.h[i]}
            />
          </td>
          <td class="py-2">
            <select class="{inp} !w-56" aria-label="Valstybė {day.d}" bind:value={d.c[i]}>
              <option value="">–</option>
              {#each options as o (o)}<option value={o}>{placeName(o)}</option>{/each}
            </select>
          </td>
        </tr>
      {/each}
    </tbody>
  </table>
  <h3 class="text-lg font-semibold tracking-tight mt-12">Mažinimas ir supažindinimas</h3>
  <div class="grid sm:grid-cols-2 gap-6 mt-4">
    <label>
      <span class={lab}>Šaltinis</span>
      <select class={inp} bind:value={d.src}>
        <option value="none">Nemažinama</option>
        <option value="ca">Kolektyvinė sutartis</option>
        <option value="local">Vietinis aktas</option>
      </select>
    </label>
    {#if d.src !== 'none'}
      <label>
        <span class={lab}>Sutarta dalis, proc.</span>
        <input type="number" class={inp} bind:value={d.pct} />
      </label>
      <label class="flex items-center gap-3 text-sm">
        <input type="checkbox" bind:checked={d.note} />Raštu supažindintas iki išvykimo
      </label>
    {/if}
  </div>
  {#each shown as m, n (n)}<Msg kind={m.level} text={m.text} />{/each}
  <div class="mt-10 flex flex-wrap items-center gap-3">
    <button class={pri} disabled={!ui.canSave} onclick={() => ui.saveTrip(false)}>Išsaugoti</button>
    <button class={btn} onclick={() => ui.saveTrip(true)}>Pažymėti nebaigta</button>
    <button class={btn} onclick={() => ui.closeTrip()}>Atgal</button>
    <span class="font-mono text-sm ml-auto">{eur(p.lines.reduce((a, l) => a + l.cents, 0))}</span>
  </div>
{/if}
