<script lang="ts">
  import { ink, mut } from './cls';
  let { t, s }: { t: string; s: string } = $props();
</script>

<h2 class="text-3xl font-semibold tracking-tight {ink}">{t}</h2>
<p class="mt-3 text-sm leading-7 max-w-prose {mut}">{s}</p>
