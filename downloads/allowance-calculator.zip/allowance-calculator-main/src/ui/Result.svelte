<script lang="ts">
  import type { DayLine, TripResult } from '../core/engine';
  import { acc, btn, ink, line, mut } from './cls';
  import Msg from './Msg.svelte';
  import { placeName } from './places';
  import { MAX_MONTHS, ui } from './state.svelte';
  import { eur, monthLabel, num } from './strings';
  import { SvelteSet } from 'svelte/reactivity';
  const exp = new SvelteSet<string>();
  const flip = (k: string) => (exp.has(k) ? exp.delete(k) : exp.add(k));

  const excluded = $derived(ui.trips.filter((t) => t.result.status === 'excluded').length);
  /** why the day got this share */
  function why(l: DayLine, t: TripResult) {
    const pk = ui.session!.packs.find((p) => `${p.id}@${p.version}` === l.pack);
    let s = 'visa diena';
    if (l.notes.includes('SHORT_DAY') && pk)
      s = `${l.d === t.start ? 'pirma' : 'paskutinė'} diena trumpesnė nei ${num((pk.params.shortDayMin ?? 0) / 60)} val. (${pk.params.shortDayBp / 100} %)`;
    else if (l.notes.includes('DOMESTIC_ONE_DAY_UNPAID')) s = 'vienos dienos komandiruotė Lietuvoje, nemokama';
    return s + (l.redBp < 10000 ? `, sumažinta ${l.redBp / 100} %` : '');
  }
  const share = (l: DayLine) => (l.rate ? num((l.cents / l.rate) * 100) : '0');
</script>

<p class="text-sm {mut}">{ui.months.map((x) => monthLabel(x.period)).join(' + ')} · visi darbuotojai</p>
<div class="mt-3 font-mono text-6xl lg:text-7xl tracking-tighter {ink}" aria-label="Bendra suma">{eur(ui.total)}</div>
{#if ui.lastD}
  <p class="mt-3 text-sm {mut}">
    Po paskutinio pakeitimo perskaičiuota:
    <span class="font-mono">{eur(ui.lastD.a!)} → {eur(ui.lastD.b!)}</span>.
    <button class="underline {acc}" onclick={() => (ui.tab = 4)}>Žiūrėti istoriją</button>
  </p>
{/if}
{#if excluded}<Msg kind="warn" text="{excluded} komandiruotė(s) pažymėta nebaigta ir į sumą neįtraukta." />{/if}
{#if !ui.calc.some((m) => m.employees.some((e) => e.trips.some((t) => t.status === 'ok')))}
  <Msg kind="warn" text="Nėra apskaičiuotų komandiruočių. Patikrinkite K žymes ir šalių eilutę žiniaraštyje." />
{/if}
<div class="flex flex-wrap gap-2 mt-8 print:hidden">
  <button class={btn} onclick={() => (ui.det = !ui.det)}>Dienų detalės</button>
  <button class={btn} onclick={() => ui.run('CSV eksportas', async () => ui.exportCsv())}>CSV</button>
  <button class={btn} onclick={() => ui.run('XLSX eksportas', async () => ui.exportXlsx())}>XLSX</button>
  <button
    class={btn}
    onclick={() => {
      ui.log('export', 'Išspausdinta su žyma');
      window.print();
    }}>Spausdinti</button
  >
  <button class={btn} onclick={() => ui.saveSession()}>Išsaugoti sesiją</button>
  <button class={btn} onclick={() => ui.go(2)}>Redaguoti komandiruotę</button>
  <button
    class={btn}
    disabled={ui.months.length >= MAX_MONTHS}
    onclick={() => {
      ui.skip = false;
      ui.go(1);
      void ui.addMonth();
    }}>Pridėti mėnesį</button
  >
  <button class={btn} onclick={() => ui.go(0)}>Keisti paketą</button>
  <button class={btn} onclick={() => (ui.modal = 'rates')}>Išsaugoti tarifai</button>
</div>
{#each ui.calc as m (m.period)}
  <h3 class="text-xs font-semibold tracking-tight mt-12 {mut}">{monthLabel(m.period)}</h3>
  {#snippet trip(name: string, t: TripResult, small: boolean)}
    <div class="border-t {line} mt-3 pt-5">
      <div class="flex justify-between items-baseline">
        <span class="{small ? 'text-sm font-medium' : 'text-lg font-semibold'} tracking-tight">{name}</span>
        <span class="font-mono {small ? 'text-sm' : ''} {acc}">{eur(t.cents)}</span>
      </div>
      <details open={ui.det} class="mt-3">
        <summary class="text-sm cursor-pointer {mut}">Dienų skaičiavimas</summary>
        <div class="overflow-x-auto">
          <table class="w-full {small ? 'text-xs' : 'text-sm'} mt-3">
            <thead>
              <tr class="text-left {mut}">
                <th class="font-normal py-1">Diena</th><th class="font-normal text-right">Val.</th>
                <th class="font-normal pl-6">Valstybė</th><th class="font-normal text-right">Tarifas</th>
                <th class="font-normal text-right">Dalis</th><th class="font-normal pl-6">Priežastis</th>
                <th class="font-normal text-right">Suma</th>
              </tr>
            </thead>
            <tbody class="font-mono text-xs">
              {#each t.lines as l (l.d)}
                <tr class="border-t {line}">
                  <td class="py-2">{l.d}</td>
                  <td class="text-right">{l.min === null ? '–' : num(l.min / 60)}</td>
                  <td class="pl-6 font-sans {small ? 'text-xs' : 'text-sm'}">{l.places.map(placeName).join(' + ')}</td>
                  <td class="text-right">{eur(l.rate)}</td>
                  <td class="text-right">{share(l)} %</td>
                  <td class="pl-6 font-sans {small ? 'text-xs' : 'text-sm'} leading-6 {mut}">{why(l, t)}</td>
                  <td class="text-right">{eur(l.cents)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
      </details>
    </div>
  {/snippet}
  {#each m.employees as e (e.employee)}
    {@const ok = e.trips.filter((t) => t.status === 'ok')}
    {#if ok.length === 1}
      {@render trip(e.employee, ok[0]!, false)}
    {:else if ok.length > 1}
      {@const k = `${m.period}|${e.employee}`}
      {@const shown = ui.det || exp.has(k)}
      <div class="border-t {line} mt-3 pt-5">
        <div class="flex justify-between items-baseline gap-4">
          <span class="text-lg font-semibold tracking-tight">
            {e.employee} <span class="text-sm font-normal {mut}">({ok.length})</span>
          </span>
          <span class="flex items-baseline gap-4 print:hidden">
            <button class="text-sm underline {acc}" aria-expanded={shown} disabled={ui.det} onclick={() => flip(k)}
              >{shown ? 'Suskleisti' : 'Išplėsti'}</button
            >
          </span>
          <span class="font-mono {acc}">{eur(ok.reduce((s, t) => s + t.cents, 0))}</span>
        </div>
        {#if shown}
          <div class="mt-2 pl-4 border-l {line}">
            {#each ok as t (t.id)}{@render trip(e.employee, t, true)}{/each}
          </div>
        {/if}
      </div>
    {/if}
  {/each}
{/each}
