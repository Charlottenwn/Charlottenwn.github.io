<script lang="ts">
  import { acc, btn, card, ink, inp, line, mut } from './cls';
  import Head from './Head.svelte';
  import { ui } from './state.svelte';
  import { eur } from './strings';

  const track = (...a: unknown[]) => a.length;

  const shown = $derived.by(() => {
    track(ui.rev);
    // copies, so that a changed entry (undone) re-renders in the keyed list
    return ui
      .session!.history.map((e) => ({ ...e }))
      .filter(
        (e) =>
          ui.hf === 'all' || (ui.hf === 'calc' ? e.k === 'calc' : ['trip', 'rules', 'rates', 'import'].includes(e.k)),
      );
  });
</script>

<Head
  t="Istorija"
  s="Kiekvienas importas, pakeitimas ir skaičiavimas. Atšaukus pakeitimą rezultatai perskaičiuojami iš karto, o atšaukimas įrašomas kaip naujas veiksmas."
/>
<div class="flex items-center gap-3 mt-8">
  <select class="{inp} !w-56" aria-label="Filtras" bind:value={ui.hf}>
    <option value="all">Visi veiksmai</option>
    <option value="chg">Tik pakeitimai</option>
    <option value="calc">Tik skaičiavimai</option>
  </select>
  <span class="text-sm {mut}">{shown.length} įrašai</span>
</div>
{#if !shown.length}
  <div class="{card} mt-8 text-sm leading-7 {mut}">
    Veiksmų dar nėra. Čia matysite kiekvieną importą, pakeitimą ir skaičiavimą.
  </div>
{:else}
  <ol class="mt-8 border-t {line}">
    {#each shown as e (e.id)}
      <li class="py-5 border-b {line} grid sm:grid-cols-[88px_1fr_auto] gap-x-6 gap-y-2">
        <span class="font-mono text-xs {mut}">{new Date(e.t).toLocaleTimeString('lt-LT')}</span>
        <div>
          <div class="text-sm leading-7 {e.undone ? mut + ' line-through' : ink}">{e.x}</div>
          {#if e.a !== undefined && e.b !== undefined}
            <div class="font-mono text-xs mt-1 {mut}">
              {eur(e.a)} → <span class={e.b !== e.a ? acc : ''}>{eur(e.b)}</span>{e.b !== e.a
                ? ` (${e.b > e.a ? '+' : '−'}${eur(Math.abs(e.b - e.a))})`
                : ' (be pokyčio)'}
            </div>
          {:else if e.b !== undefined}
            <div class="font-mono text-xs mt-1 {mut}">suma {eur(e.b)}</div>
          {/if}
        </div>
        {#if e.undo && !e.undone}
          <button class={btn} onclick={() => ui.undo(e)}>Atšaukti pakeitimą</button>
        {:else if e.undone}
          <span class="text-xs {mut}">atšaukta</span>
        {/if}
      </li>
    {/each}
  </ol>
{/if}
