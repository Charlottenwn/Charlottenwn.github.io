<script lang="ts">
  import { acc, btn, card, inp, lab, line, mut, pri } from './cls';
  import Head from './Head.svelte';
  import Msg from './Msg.svelte';
  import { ui } from './state.svelte';
  import { SW, HINT, SWITCH_KEYS } from './strings';
  import Tools from './Tools.svelte';

  const adv: ['ca' | 'act' | 'h' | 'pc', string][] = [
    ['ca', 'Žemiausia dalis pagal kolektyvinę sutartį, proc.'],
    ['act', 'Žemiausia dalis pagal vietinį aktą, proc.'],
    ['h', 'Trumpos dienos riba, val.'],
    ['pc', 'Trumpos dienos dalis, proc.'],
  ];
  const ed = $derived(ui.ed?.k === 'p' ? ui.ed : null);
</script>

<Head
  t="Taisyklių paketai"
  s="Teisinės ribos ir atviri klausimai. Kiekvienas išsaugojimas sukuria naują versiją, senoji paliekama."
/>
<Tools kind="p" />
<div class="mt-8 border-t {line}">
  {#each ui.packs as p (p.id)}
    <div class="flex items-center gap-4 py-4 border-b {line}">
      <span class="font-medium">{p.label}</span><span class="font-mono text-xs {mut}">v{p.version}</span>
      <span class="ml-auto flex items-center gap-2">
        {#if p.id === ui.session!.activePack}
          <span class="text-sm {acc}">aktyvus</span>
        {:else}
          <button class={btn} onclick={() => ui.setActivePack(p.id)}>Padaryti aktyvų</button>
        {/if}
        <button class={btn} onclick={() => ui.editPack(p.id)}>Redaguoti</button>
      </span>
    </div>
  {/each}
</div>
{#if ed}
  <div class="{card} mt-8">
    <h3 class="text-xl font-semibold tracking-tight">Redaguojama: {ed.o.n}</h3>
    {#if ed.err}<Msg kind="error" text={ed.err} />{/if}
    <label class="block mt-6"><span class={lab}>Pavadinimas</span><input class={inp} bind:value={ed.o.n} /></label>
    <div class="mt-6 space-y-5">
      {#each SWITCH_KEYS as k, i (k)}
        <label class="block">
          <span class="block text-sm leading-6 mb-1.5">
            {i + 1}. {SW[k]}
            <span class="group relative ml-1 inline-block align-middle">
              <button
                type="button"
                aria-label="Paaiškinimas"
                aria-describedby="hint-{k}"
                class="inline-flex h-[18px] w-[18px] items-center justify-center rounded-full border border-current text-[11px] font-semibold leading-none opacity-60 hover:opacity-100 focus-visible:opacity-100"
                >i</button
              >
              <span
                id="hint-{k}"
                role="tooltip"
                class="pointer-events-none invisible absolute left-0 top-full z-20 mt-1.5 w-80 max-w-[80vw] rounded-md border p-3 text-xs font-normal leading-5 opacity-0 shadow-lg transition-opacity group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100 bg-white text-slate-700 border-slate-200"
                >{HINT[k]}</span
              >
            </span>
          </span>
          <select class="{inp} !w-48" aria-label="Klausimas {i + 1}" bind:value={ed.o.sw[i]}>
            <option value={0}>nepasirinkta</option><option value={1}>taip</option><option value={2}>ne</option>
          </select>
        </label>
      {/each}
    </div>
    <details class="mt-8">
      <summary class="text-sm cursor-pointer {acc}">Išplėstinis režimas: teisinės ribos</summary>
      <div class="grid sm:grid-cols-2 gap-6 mt-5">
        {#each adv as [k, l] (k)}
          <label><span class={lab}>{l}</span><input type="number" class={inp} bind:value={ed.o.adv[k]} /></label>
        {/each}
      </div>
    </details>
    <div class="mt-8 flex gap-3">
      <button class={pri} onclick={() => ui.commitEdit()}>Tikrinti ir išsaugoti</button>
      <button class={btn} onclick={() => (ui.ed = null)}>Atšaukti</button>
    </div>
  </div>
{/if}
