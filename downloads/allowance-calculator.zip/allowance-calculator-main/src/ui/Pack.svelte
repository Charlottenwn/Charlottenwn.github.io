<script lang="ts">
  import { PRESETS } from '../rules/defaults';
  import { inp, lab, pri } from './cls';
  import Head from './Head.svelte';
  import { ui } from './state.svelte';
</script>

<Head
  t="Paketas ir politika"
  s="Politika tampa numatytuoju mažinimu naujoms komandiruotėms. Paketus keisite skiltyje „Taisyklių paketai“."
/>
<div class="grid sm:grid-cols-2 gap-6 mt-10">
  <label>
    <span class={lab}>Taisyklių paketas</span>
    <select class={inp} value={ui.session!.activePack} onchange={(e) => ui.setActivePack(e.currentTarget.value)}>
      {#each ui.packs as p (p.id)}<option value={p.id}>{p.label} v{p.version}</option>{/each}
    </select>
  </label>
  <label>
    <span class={lab}>Darbdavio politika</span>
    <select class={inp} value={ui.session!.preset} onchange={(e) => ui.setPreset(Number(e.currentTarget.value))}>
      {#each PRESETS as p, i (i)}<option value={i}>{p.n}</option>{/each}
    </select>
  </label>
</div>
<div class="mt-10"><button class={pri} onclick={() => ui.go(1)}>Toliau</button></div>
