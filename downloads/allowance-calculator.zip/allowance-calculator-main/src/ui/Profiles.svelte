<script lang="ts">
  import { btn, card, inp, lab, line, mut, pri } from './cls';
  import Head from './Head.svelte';
  import Msg from './Msg.svelte';
  import type { ProfDraft } from './state.svelte';
  import { ui } from './state.svelte';
  import Tools from './Tools.svelte';

  const fields: [keyof ProfDraft, string][] = [
    ['sheet', 'Lapas (numeris arba pavadinimas)'],
    ['hdr', 'Dienų antraštės eilutė'],
    ['nameCol', 'Vardo stulpelis'],
    ['idxCol', 'Eil. Nr. stulpelis (nebūtina)'],
    ['dayCol', 'Pirmos dienos stulpelis'],
    ['step', 'Žingsnis tarp dienų stulpelių'],
    ['row1', 'Pirmo darbuotojo valandų eilutė'],
    ['per', 'Eilučių vienam darbuotojui'],
    ['placeOff', 'Valstybių eilutė, poslinkis (nebūtina)'],
    ['kOff', 'K eilutė, poslinkis'],
    ['yearCell', 'Metų langelis (pvz. T11)'],
    ['monthCell', 'Mėnesio langelis (pvz. AI11)'],
  ];
  const ed = $derived(ui.ed?.k === 'f' ? ui.ed : null);
</script>

<Head
  t="Profiliai"
  s="Žiniaraščio kodai ir stulpelių susiejimas. Žiniaraštis standartinis, todėl dažniausiai pakanka vieno profilio."
/>
<Tools kind="f" />
<div class="mt-8 border-t {line}">
  {#each ui.profs as p (p.id)}
    <div class="flex items-center gap-4 py-4 border-b {line}">
      <span class="font-medium">{p.label}</span><span class="font-mono text-xs {mut}">v{p.version}</span>
      <span class="ml-auto flex gap-2">
        <button class={btn} onclick={() => ui.editProf(p.id)}>Redaguoti kodus</button>
        <button class={btn} onclick={() => ui.editProf(p.id)}>Susieti stulpelius</button>
      </span>
    </div>
  {:else}
    <p class="py-6 text-sm {mut}">Profilių nėra. Sukurkite naują arba importuokite failą.</p>
  {/each}
</div>
{#if ed}
  <div class="{card} mt-8">
    <h3 class="text-xl font-semibold tracking-tight">Redaguojama: {ed.o.n}</h3>
    {#if ed.err}<Msg kind="error" text={ed.err} />{/if}
    <label class="block mt-6"><span class={lab}>Pavadinimas</span><input class={inp} bind:value={ed.o.n} /></label>
    <label class="block mt-5">
      <span class={lab}>Kodai, kurie praleidžiami valandų eilutėje</span>
      <textarea rows="2" class={inp} bind:value={ed.o.codes}></textarea>
    </label>
    <label class="block mt-5 max-w-xs">
      <span class={lab}>Komandiruotės žymė</span><input class={inp} bind:value={ed.o.kmark} />
    </label>
    <h4 class="text-sm font-semibold mt-8">Stulpelių susiejimas</h4>
    <div class="grid sm:grid-cols-2 gap-x-6 gap-y-4 mt-4">
      {#each fields as [k, l] (k)}
        <label><span class={lab}>{l}</span><input class={inp} bind:value={ed.o[k]} /></label>
      {/each}
    </div>
    <div class="mt-8 flex gap-3">
      <button class={pri} onclick={() => ui.commitEdit()}>Tikrinti ir išsaugoti</button>
      <button class={btn} onclick={() => (ui.ed = null)}>Atšaukti</button>
    </div>
  </div>
{/if}
