import type {
  Issue,
  ParsedSheet,
  Policy,
  RateList,
  RulePack,
  SheetDay,
  SheetEmployee,
  Switches,
  TripInput,
} from './schema';
import { addDays, daysIn, mulDiv } from './util';

export type Trip = { id: string; employee: string; days: { d: string; min: number | null; place?: string }[] };
export type DayLine = {
  d: string;
  min: number | null; // hours that day, minutes
  places: string[];
  rate: number;
  redBp: number;
  shortBp: number;
  domBp: number;
  cents: number;
  pack: string;
  notes: string[];
};
export type TripResult = {
  id: string;
  employee: string;
  start: string;
  end: string;
  lines: DayLine[];
  cents: number;
  status: 'ok' | 'blocked' | 'excluded'; // excluded = marked incomplete by the user
  issues: Issue[];
  /** month slices of a trip that crosses a month boundary */
  fromPrev?: boolean;
  intoNext?: boolean;
};
export type Ctx = { rates: RateList; packs: RulePack[]; policies: Policy[] };
export type MonthResult = {
  period: string;
  employees: { employee: string; cents: number; trips: TripResult[] }[];
  cents: number;
  blocked: number;
  excluded: number;
  issues: Issue[];
};

type Eff = { effectiveFrom: string; effectiveTo: string | null; version: number };
export const active = <T extends Eff>(l: T[], d: string): T | undefined =>
  l
    .filter((x) => x.effectiveFrom <= d && (x.effectiveTo === null || d <= x.effectiveTo))
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom) || b.version - a.version)[0];

export function rateFor(r: RateList, place: string, d: string): number | undefined {
  for (const k of [place, place.split('/')[0]!]) {
    const row = r.rows
      .filter((x) => x.place === k && x.validFrom <= d)
      .sort((a, b) => b.validFrom.localeCompare(a.validFrom))[0];
    if (row) return row.cents;
  }
  return undefined;
}

/** legs sorted by `from`. A leg is active from its `from` through the next leg's `from` (inclusive) -> averaging on change day. */
export function dayPlaces(legs: TripInput['legs'], d: string): string[] {
  const act = legs.filter((l, i) => l.from <= d && (i === legs.length - 1 || d <= legs[i + 1]!.from));
  const main = act.filter((l) => !l.transit);
  return [...new Set((main.length ? main : act).map((l) => l.place))];
}

export function calcTrip(t: Trip, input: TripInput | undefined, c: Ctx): TripResult {
  const start = t.days[0]!.d,
    end = t.days[t.days.length - 1]!.d,
    n = t.days.length;
  const inp: TripInput = input ?? {
    employee: t.employee,
    start,
    legs: [],
    reduction: null,
    notified: false,
    dailyReturn: false,
  };
  const issues: Issue[] = [],
    lines: DayLine[] = [];
  let blocked = false;
  const err = (code: string, params: Issue['params'] = {}) => {
    if (!issues.some((i) => i.code === code && JSON.stringify(i.params) === JSON.stringify(params)))
      issues.push({ level: 'error', code, params });
    blocked = true;
  };
  const warn = (code: string, params: Issue['params'] = {}) => {
    issues.push({ level: 'warn', code, params });
  };
  const done = (): TripResult => ({
    id: t.id,
    employee: t.employee,
    start,
    end,
    lines,
    issues,
    status: blocked ? 'blocked' : 'ok',
    cents: blocked ? 0 : lines.reduce((s, l) => s + l.cents, 0),
  });

  if (inp.incomplete) {
    issues.push({ level: 'warn', code: 'MARKED_INCOMPLETE', params: {} });
    return { id: t.id, employee: t.employee, start, end, lines, issues, status: 'excluded', cents: 0 };
  }
  const pol = active(c.policies, start);
  if (!pol) {
    err('NO_POLICY', { date: start });
    return done();
  }
  const sw = (k: keyof Switches, pk: RulePack): boolean => {
    const v = pk.switches[k];
    if (v === null) {
      err('SWITCH_UNRESOLVED', { key: k });
      return false;
    }
    return v;
  };

  const legs = [...inp.legs].sort((a, b) => a.from.localeCompare(b.from));
  // explicit trip-input legs win; otherwise the timesheet's per-day country
  // priority: hand-edited day > trip-input legs > the timesheet's own country
  const fix = (d: string) => inp.days?.[d];
  const placesOf = (x: Trip['days'][number]) =>
    fix(x.d)?.place ? [fix(x.d)!.place!] : legs.length ? dayPlaces(legs, x.d) : x.place ? [x.place] : [];
  const domestic = t.days.every((x) => {
    const p = placesOf(x);
    return p.length > 0 && p.every((q) => q.split('/')[0] === 'LT');
  });
  const probe = active(c.packs, start);
  const split =
    domestic &&
    inp.dailyReturn &&
    n > 1 &&
    probe !== undefined &&
    probe.params.domesticOneDayBp === 0 &&
    !sw('dailyReturnIsOneTrip', probe);

  const redCache = new Map<string, number>();
  const redFor = (pk: RulePack): number => {
    const key = `${pk.id}@${pk.version}`,
      hit = redCache.get(key);
    if (hit !== undefined) return hit;
    const r = inp.reduction ?? pol.defaultReduction;
    let bp = 10000;
    if (r.source !== 'none' && r.bp < 10000) {
      const min = r.source === 'ca' ? pk.params.caMinBp : pk.params.localMinBp;
      if (r.bp < min) err('REDUCTION_BELOW_MIN', { source: r.source, bp: r.bp, min, pack: key });
      else {
        // every reason that forces 100 % is reported, not just the first
        let forced = false;
        if (r.source === 'local' && n < pk.params.localMinTripDays) {
          warn('LOCAL_ACT_TRIP_TOO_SHORT', { days: n, min: pk.params.localMinTripDays });
          forced = true;
        }
        if (pk.params.noticeRequired && !inp.notified) {
          warn('NOT_NOTIFIED');
          forced = true;
        }
        if (!forced) bp = r.bp;
      }
    }
    redCache.set(key, bp);
    return bp;
  };

  t.days.forEach((day, i) => {
    const d = day.d,
      min = fix(d)?.min ?? day.min;
    const pk = active(c.packs, d);
    if (!pk) return err('NO_PACK', { date: d });
    const places = placesOf(day);
    if (!places.length) return err('NO_PLACE', { date: d });
    const rs = places.map((p) => rateFor(c.rates, p, d));
    const miss = places.find((_, k) => rs[k] === undefined);
    if (miss) return err('NO_RATE', { place: miss, date: d });
    const sum = (rs as number[]).reduce((a, b) => a + b, 0);
    const first = split || i === 0,
      last = split || i === n - 1,
      one = split || n === 1;
    const notes: string[] = [];

    let dom = 10000; // domestic one-day
    if (domestic && one) {
      dom = pk.params.domesticOneDayBp;
      if (dom === 0 && min !== null && min > pol.workdayMin && sw('ltLongerThanWorkdayIsMultiDay', pk)) dom = 10000;
      if (dom === 0) notes.push('DOMESTIC_ONE_DAY_UNPAID');
    }

    let sb = 10000;
    const sd = pk.params.shortDayMin; // first/last day < 4h
    if (sd !== null && (first || last) && !(domestic && one)) {
      if (min === null) err('NO_HOURS', { date: d });
      else if (min < sd && (!one || sw('shortRuleOnOneDayAbroad', pk))) {
        sb = pk.params.shortDayBp;
        notes.push('SHORT_DAY');
      }
    }

    const red = redFor(pk);
    if (red < 10000) notes.push('REDUCED');
    const num = red < 10000 && sb < 10000 && !sw('shortRuleOnReducedRate', pk) ? Math.min(red, sb) * 10000 : red * sb;
    let cents = mulDiv(sum * num, places.length * 1e8);
    if (dom !== 10000) cents = mulDiv(cents * dom, 10000);
    lines.push({
      d,
      min,
      places,
      rate: mulDiv(sum, places.length),
      redBp: red,
      shortBp: sb,
      domBp: dom,
      cents,
      pack: `${pk.id}@${pk.version}`,
      notes,
    });
  });
  return done();
}

const prevYm = (ym: string) => addDays(`${ym}-01`, -1).slice(0, 7);
const nextYm = (ym: string) => addDays(`${ym}-01`, daysIn(ym)).slice(0, 7);

/** Consecutive calendar days with K = one trip. `e.days` may span several months; a trip that touches
 *  the edge of a month whose neighbour month is not loaded gets a MONTH_EDGE_TRIP warning. */
export function detectTrips(e: SheetEmployee, loaded: ReadonlySet<string> = new Set()) {
  const trips: Trip[] = [],
    issues: Issue[] = [];
  let cur: Trip | null = null;
  for (const x of e.days) {
    if (cur && x.d !== addDays(cur.days[cur.days.length - 1]!.d, 1)) {
      trips.push(cur); // gap: a month in between is not loaded
      cur = null;
    }
    if (x.k)
      (cur ??= { id: `${e.name}|${x.d}`, employee: e.name, days: [] }).days.push({
        d: x.d,
        min: x.min,
        ...(x.place ? { place: x.place } : {}),
      });
    else if (cur) {
      trips.push(cur);
      cur = null;
    }
  }
  if (cur) trips.push(cur);
  for (const t of trips) {
    const a = t.days[0]!.d,
      b = t.days[t.days.length - 1]!.d;
    if (a.endsWith('-01') && !loaded.has(prevYm(a.slice(0, 7))))
      issues.push({ level: 'warn', code: 'MONTH_EDGE_TRIP', params: { employee: e.name, edge: 'start', date: a } });
    if (b === `${b.slice(0, 7)}-${daysIn(b.slice(0, 7))}` && !loaded.has(nextYm(b.slice(0, 7))))
      issues.push({ level: 'warn', code: 'MONTH_EDGE_TRIP', params: { employee: e.name, edge: 'end', date: b } });
  }
  return { trips, issues };
}

/** input saved under any day of the trip applies to the whole trip; an exact id match wins */
export function inputFor(inputs: Record<string, TripInput>, t: Trip): TripInput | undefined {
  return (
    inputs[t.id] ??
    Object.entries(inputs).find(
      ([k]) => k.startsWith(`${t.employee}|`) && t.days.some((x) => x.d === k.slice(t.employee.length + 1)),
    )?.[1]
  );
}

/** Trips are calculated once over all loaded months (a trip may cross a month boundary: 7-day rule, first/last-day
 *  rule and averaging see the whole trip); every day's amount is attributed to the month it falls in. */
export function calcAll(sheets: ParsedSheet[], inputs: Record<string, TripInput>, c: Ctx): MonthResult[] {
  const ss = [...sheets].sort((a, b) => a.period.localeCompare(b.period)),
    loaded = new Set(ss.map((s) => s.period)),
    merged = new Map<string, SheetDay[]>(),
    trips = new Map<string, TripResult[]>(),
    edge: Issue[] = [];
  for (const s of ss) for (const e of s.employees) merged.set(e.name, [...(merged.get(e.name) ?? []), ...e.days]);
  for (const [name, days] of merged) {
    const d = detectTrips({ name, days }, loaded);
    edge.push(...d.issues);
    trips.set(
      name,
      d.trips.map((t) => calcTrip(t, inputFor(inputs, t), c)),
    );
  }
  return ss.map((s) => {
    const employees = s.employees.map((e) => {
      const ts = (trips.get(e.name) ?? [])
        .filter((t) => t.start.slice(0, 7) <= s.period && s.period <= t.end.slice(0, 7))
        .map((t): TripResult => {
          const lines = t.lines.filter((l) => l.d.startsWith(s.period));
          return {
            ...t,
            lines,
            cents: t.status === 'blocked' ? 0 : lines.reduce((a, l) => a + l.cents, 0),
            fromPrev: t.start.slice(0, 7) < s.period,
            intoNext: t.end.slice(0, 7) > s.period,
          };
        });
      return { employee: e.name, trips: ts, cents: ts.reduce((a, t) => a + t.cents, 0) };
    });
    return {
      period: s.period,
      employees,
      issues: [...s.issues, ...edge.filter((i) => String(i.params.date).startsWith(s.period))],
      cents: employees.reduce((a, e) => a + e.cents, 0),
      blocked: employees.reduce((a, e) => a + e.trips.filter((t) => t.status === 'blocked').length, 0),
      excluded: employees.reduce((a, e) => a + e.trips.filter((t) => t.status === 'excluded').length, 0),
    };
  });
}

export const calcMonth = (s: ParsedSheet, inputs: Record<string, TripInput>, c: Ctx): MonthResult =>
  calcAll([s], inputs, c)[0]!;
