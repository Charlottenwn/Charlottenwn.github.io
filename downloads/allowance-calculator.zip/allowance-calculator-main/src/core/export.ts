import * as XLSX from 'xlsx';
import type { CalcResult } from './api';

const eur = (c: number) => c / 100;
export function toRows(r: CalcResult): (string | number)[][] {
  const rows: (string | number)[][] = [
    [
      'period',
      'employee',
      'trip',
      'status',
      'date',
      'places',
      'rate_eur',
      'reduction_pct',
      'short_pct',
      'domestic_pct',
      'eur',
      'pack',
      'notes',
    ],
  ];
  for (const m of r.months)
    for (const e of m.employees)
      for (const t of e.trips)
        for (const l of t.lines)
          rows.push([
            m.period,
            e.employee,
            t.id,
            t.status,
            l.d,
            l.places.join('+'),
            eur(l.rate),
            l.redBp / 100,
            l.shortBp / 100,
            l.domBp / 100,
            eur(l.cents),
            l.pack,
            l.notes.join(','),
          ]);
  rows.push([], ['stamp', r.stamp.app, r.stamp.ratesSha, r.stamp.rulesSha], ['total_eur', eur(r.cents)]);
  return rows;
}
export const toSummary = (r: CalcResult): (string | number)[][] => [
  ['period', 'employee', 'eur'],
  ...r.months.flatMap((m) => m.employees.map((e) => [m.period, e.employee, eur(e.cents)])),
];

export function toCsv(rows: (string | number)[][]) {
  const cell = (c: string | number) =>
    typeof c === 'number' ? String(c).replace('.', ',') : /[;"\n]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c;
  return '\uFEFF' + rows.map((r) => r.map(cell).join(';')).join('\r\n');
}
export function toXlsx(r: CalcResult): Uint8Array {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(toSummary(r)), 'Summary');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(toRows(r)), 'Days');
  return new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}

/** rates as an Excel table: place | EUR per day | valid from (the same shape the importer reads) */
export function ratesToXlsx(l: { rows: { place: string; cents: number; validFrom: string }[] }): Uint8Array {
  const wb = XLSX.utils.book_new();
  const rows = [['place', 'eur', 'from'], ...l.rows.map((r) => [r.place, r.cents / 100, r.validFrom])];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), 'Tarifai');
  return new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
}
