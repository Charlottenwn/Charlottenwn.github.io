import {
  calcAll,
  calcTrip,
  detectTrips,
  inputFor,
  type Ctx,
  type MonthResult,
  type Trip,
  type TripResult,
} from './engine';
import { TripInput } from './schema';
import type { HistEntry, ParsedSheet, RateList, RulePack, Session, SheetDay, Undo } from './schema';
import type { Repo } from './repo';
import { mergeRates, parseRates } from './rates';
import { parseTripInputs } from './tripinput';
import { PRESETS } from '../rules/defaults';
import { sha, stable } from './util';
import { version } from '../../package.json';

export const APP = version;

export const log = (s: Session, op: string, data: unknown) => {
  s.audit.push({ t: new Date().toISOString(), op, data });
};

export async function newSession(r: Repo, name: string): Promise<Session> {
  return {
    schema: 1,
    id: crypto.randomUUID(),
    name,
    savedAt: '',
    app: APP,
    sheets: {},
    inputs: {},
    rates: await r.rates(),
    packs: await r.packs(),
    policies: await r.policies(),
    activePack: 'LT-526',
    preset: 0,
    profileId: 'default',
    history: [],
    audit: [],
  };
}
export function setSheet(s: Session, sh: ParsedSheet) {
  log(s, 'sheet.set', { period: sh.period, employees: sh.employees.length, issues: sh.issues.length });
  s.sheets[sh.period] = sh;
}
export function setInput(s: Session, i: TripInput) {
  const id = `${i.employee}|${i.start}`,
    after = TripInput.parse(i);
  log(s, 'input.set', { id, before: s.inputs[id] ?? null, after });
  s.inputs[id] = after;
}
export function setRates(s: Session, r: RateList) {
  log(s, 'rates.set', { before: s.rates, after: r });
  s.rates = r;
}
export async function syncSnapshot(s: Session, r: Repo) {
  s.rates = await r.rates();
  s.packs = await r.packs();
  s.policies = await r.policies();
  log(s, 'snapshot.sync', {});
}

/** the rule-pack family the user picked; its versions are effective-dated, so old months keep the old regime */
export const packsOf = (s: Session): RulePack[] => {
  const fam = s.packs.filter((p) => p.id === s.activePack);
  return fam.length ? fam : s.packs;
};
export const ctxOf = (s: Session): Ctx => ({ rates: s.rates, packs: packsOf(s), policies: s.policies });
export const calcSync = (s: Session): MonthResult[] => calcAll(Object.values(s.sheets), s.inputs, ctxOf(s));
export const totalOf = (s: Session) => calcSync(s).reduce((a, m) => a + m.cents, 0);

/** every trip over all loaded months, whole (not cut at month ends), with its result */
export function allTrips(s: Session): { trip: Trip; result: TripResult; input: TripInput | undefined }[] {
  const merged = new Map<string, SheetDay[]>();
  const sheets = Object.values(s.sheets).sort((a, b) => a.period.localeCompare(b.period));
  for (const sh of sheets) for (const e of sh.employees) merged.set(e.name, [...(merged.get(e.name) ?? []), ...e.days]);
  const loaded = new Set(sheets.map((x) => x.period)),
    ctx = ctxOf(s),
    out: ReturnType<typeof allTrips> = [];
  for (const [name, days] of merged)
    for (const trip of detectTrips({ name, days }, loaded).trips) {
      const input = inputFor(s.inputs, trip);
      out.push({ trip, input, result: calcTrip(trip, input, ctx) });
    }
  return out.sort(
    (a, b) => a.trip.days[0]!.d.localeCompare(b.trip.days[0]!.d) || a.trip.employee.localeCompare(b.trip.employee),
  );
}
/** calculate a trip with a not yet saved input (live messages while editing) */
export function previewTrip(s: Session, trip: Trip, draft: TripInput): TripResult {
  return calcTrip(trip, draft, ctxOf(s));
}
/** new trips get the employer preset as their default reduction; existing inputs are left alone */
export function ensureInputs(s: Session): number {
  const p = PRESETS[s.preset]!;
  let n = 0;
  for (const { trip, input } of allTrips(s)) {
    if (input) continue;
    s.inputs[trip.id] = {
      employee: trip.employee,
      start: trip.days[0]!.d,
      legs: [],
      reduction: p.src === 'none' ? { source: 'none', bp: 10000 } : { source: p.src, bp: p.pct * 100 },
      notified: true,
      dailyReturn: false,
    };
    n++;
  }
  if (n) log(s, 'inputs.auto', { n, preset: p.n });
  return n;
}

export type CalcResult = {
  months: MonthResult[];
  cents: number;
  stamp: { app: string; ratesSha: string; rulesSha: string };
};
export async function calculate(s: Session): Promise<CalcResult> {
  const months = calcSync(s);
  const used = new Set(
    months.flatMap((m) => m.employees.flatMap((e) => e.trips.flatMap((t) => t.lines.map((l) => l.pack)))),
  );
  return {
    months,
    cents: months.reduce((a, m) => a + m.cents, 0),
    stamp: {
      app: APP,
      ratesSha: await sha(stable(s.rates)),
      rulesSha: await sha(
        stable({ packs: s.packs.filter((p) => used.has(`${p.id}@${p.version}`)), policies: s.policies }),
      ),
    },
  };
}

/** applies nothing if the sheet has any error */
export function importTripInputs(s: Session, aoa: unknown[][]) {
  const { inputs, issues } = parseTripInputs(aoa);
  if (issues.some((i) => i.level === 'error')) return { applied: 0, issues };
  inputs.forEach((i) => setInput(s, i));
  return { applied: inputs.length, issues };
}
export function importRates(s: Session, aoa: unknown[][], mode: 'add' | 'replace') {
  const { rows, issues } = parseRates(aoa);
  if (issues.some((i) => i.level === 'error')) return { added: 0, changed: 0, same: 0, issues };
  const m = mergeRates(s.rates, rows, mode);
  setRates(s, m.list);
  return { added: m.added, changed: m.changed, same: m.same, issues };
}

/** the user-facing history ("Istorija"): every import, change and calculation, with the sum before/after */
export function addHist(s: Session, k: string, x: string, a?: number, b?: number, undo?: Undo): HistEntry {
  const e: HistEntry = {
    id: Math.max(0, ...s.history.map((h) => h.id)) + 1,
    t: new Date().toISOString(),
    k,
    x,
    undone: false,
    ...(a !== undefined ? { a } : {}),
    ...(b !== undefined ? { b } : {}),
    ...(undo ? { undo } : {}),
  };
  s.history.unshift(e);
  return e;
}
/** restores what an entry changed; the undo itself becomes a new entry */
export async function undoHist(s: Session, r: Repo, id: number) {
  const e = s.history.find((h) => h.id === id);
  if (!e?.undo || e.undone) return;
  const a = totalOf(s),
    u = e.undo;
  if (u.type === 'trip') {
    if (u.before) s.inputs[u.id] = u.before;
    else delete s.inputs[u.id];
  } else if (u.type === 'activePack') s.activePack = u.before;
  else if (u.type === 'preset') s.preset = u.before;
  else if (u.type === 'pack') {
    await r.savePack({ ...u.before, version: await r.nextVersion('packs', u.before.id) });
    s.packs = await r.packs();
  } else if (u.type === 'profile') {
    await r.saveProfile({ ...u.before, version: await r.nextVersion('profiles', u.before.id) });
  } else {
    await r.saveRates(u.before);
    s.rates = u.before;
  }
  e.undone = true;
  addHist(s, e.k, `Atšaukta: ${e.x}`, a, totalOf(s));
}
