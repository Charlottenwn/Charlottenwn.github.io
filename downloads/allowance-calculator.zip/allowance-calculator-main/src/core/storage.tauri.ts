import { BaseDirectory, exists, mkdir, readDir, readTextFile, remove, writeTextFile } from '@tauri-apps/plugin-fs';
import type { Store } from './storage';
const B = { baseDir: BaseDirectory.AppData };
export class TauriStore implements Store {
  async read(p: string) {
    return (await exists(p, B)) ? readTextFile(p, B) : null;
  }
  async write(p: string, d: string) {
    const dir = p.split('/').slice(0, -1).join('/');
    if (dir) await mkdir(dir, { ...B, recursive: true });
    await writeTextFile(p, d, B);
  }
  async list(dir: string) {
    return (await exists(dir, B)) ? (await readDir(dir, B)).filter((e) => e.isFile).map((e) => e.name) : [];
  }
  async remove(p: string) {
    if (await exists(p, B)) await remove(p, B);
  }
}
