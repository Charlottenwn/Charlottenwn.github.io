import { z } from 'zod';

export const SCHEMA = 1;
export const Iso = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const Ym = z.string().regex(/^\d{4}-\d{2}$/);
const Bp = z.number().int().min(0).max(10000);
const Sw = z.boolean().nullable(); // null = unresolved, calc blocks when it matters

export const Issue = z.object({
  level: z.enum(['error', 'warn']),
  code: z.string(),
  params: z.record(z.string(), z.union([z.string(), z.number()])),
});
export type Issue = z.infer<typeof Issue>;

export const RateRow = z.object({ place: z.string().min(2), cents: z.number().int().min(0), validFrom: Iso });
export type RateRow = z.infer<typeof RateRow>;
export const RateList = z.object({ schema: z.literal(1), sourceUrl: z.string(), rows: z.array(RateRow) });
export type RateList = z.infer<typeof RateList>;

export const Switches = z.object({
  dailyReturnIsOneTrip: Sw,
  shortRuleOnOneDayAbroad: Sw,
  ltLongerThanWorkdayIsMultiDay: Sw,
  shortRuleOnReducedRate: Sw,
});
export type Switches = z.infer<typeof Switches>;

export const RulePack = z.object({
  schema: z.literal(1),
  id: z.string(),
  version: z.number().int().min(1),
  label: z.string(),
  effectiveFrom: Iso,
  effectiveTo: Iso.nullable(),
  params: z.object({
    shortDayMin: z.number().int().nullable(),
    shortDayBp: Bp,
    caMinBp: Bp,
    localMinBp: Bp,
    localMinTripDays: z.number().int().min(0),
    noticeRequired: z.boolean(),
    domesticOneDayBp: Bp,
  }),
  switches: Switches, // the employer's answers to what the regulation leaves open
});
export type RulePack = z.infer<typeof RulePack>;

export const Reduction = z.object({ source: z.enum(['none', 'ca', 'local']), bp: Bp });
export const Policy = z.object({
  schema: z.literal(1),
  id: z.string(),
  version: z.number().int().min(1),
  label: z.string(),
  effectiveFrom: Iso,
  effectiveTo: Iso.nullable(),
  workdayMin: z.number().int().min(1),
  defaultReduction: Reduction,
});
export type Policy = z.infer<typeof Policy>;

export const ImportProfile = z.object({
  schema: z.literal(1),
  id: z.string(),
  version: z.number().int().min(1),
  label: z.string(),
  sheet: z.union([z.number().int(), z.string()]),
  dayHeaderRow: z.number().int(),
  firstDayCol: z.number().int(),
  dayColStep: z.number().int().min(1), // 2 when each day is a merged pair of columns
  nameCol: z.number().int(),
  indexCol: z.number().int().nullable(), // "Eil. Nr." column; rows without a number are skipped
  firstEmployeeRow: z.number().int(), // the employee's hours row
  rowsPerEmployee: z.number().int().min(1),
  placeRowOffset: z.number().int().nullable(), // row with the per-day country code, null = none
  kRowOffset: z.number().int(),
  yearCell: z.tuple([z.number().int(), z.number().int()]).nullable(), // [row, col], 0-based
  monthCell: z.tuple([z.number().int(), z.number().int()]).nullable(),
  kMark: z.string().min(1),
  ignore: z.array(z.string()),
});
export type ImportProfile = z.infer<typeof ImportProfile>;

export const Leg = z.object({ place: z.string(), from: Iso, transit: z.boolean().optional() });
export const TripInput = z.object({
  employee: z.string(),
  start: Iso,
  legs: z.array(Leg),
  reduction: Reduction.nullable(),
  notified: z.boolean(),
  dailyReturn: z.boolean(),
  // per-day corrections made by hand (win over legs and over the timesheet)
  days: z
    .record(z.string(), z.object({ place: z.string().optional(), min: z.number().int().min(0).max(1440).optional() }))
    .optional(),
  incomplete: z.boolean().optional(), // marked unfinished: left out of the sum
  manual: z.boolean().optional(), // edited by hand (false/absent = created automatically)
});
export type TripInput = z.infer<typeof TripInput>;

export const SheetDay = z.object({
  d: Iso,
  min: z.number().int().nullable(),
  k: z.boolean(),
  place: z.string().optional(), // per-day country (or DE/Berlin) when the sheet has it
});
export type SheetDay = z.infer<typeof SheetDay>;
export const SheetEmployee = z.object({ name: z.string(), days: z.array(SheetDay) });
export type SheetEmployee = z.infer<typeof SheetEmployee>;
export const ParsedSheet = z.object({
  period: Ym,
  employees: z.array(SheetEmployee),
  issues: z.array(Issue),
  file: z.string().optional(), // source file name, for display
});
export type ParsedSheet = z.infer<typeof ParsedSheet>;

export const Undo = z.discriminatedUnion('type', [
  z.object({ type: z.literal('trip'), id: z.string(), before: TripInput.nullable() }),
  z.object({ type: z.literal('activePack'), before: z.string() }),
  z.object({ type: z.literal('preset'), before: z.number().int() }),
  z.object({ type: z.literal('pack'), before: RulePack }),
  z.object({ type: z.literal('profile'), before: ImportProfile }),
  z.object({ type: z.literal('rates'), before: RateList }),
]);
export type Undo = z.infer<typeof Undo>;
export const HistEntry = z.object({
  id: z.number().int(),
  t: z.string(), // ISO timestamp
  k: z.string(), // calc | trip | rules | rates | import | export | session
  x: z.string(),
  a: z.number().optional(), // total before / after, cents
  b: z.number().optional(),
  undo: Undo.optional(),
  undone: z.boolean(),
});
export type HistEntry = z.infer<typeof HistEntry>;

export const Session = z.object({
  schema: z.literal(1),
  id: z.string(),
  name: z.string(),
  savedAt: z.string(),
  app: z.string(),
  sheets: z.record(z.string(), ParsedSheet),
  inputs: z.record(z.string(), TripInput),
  rates: RateList,
  packs: z.array(RulePack),
  policies: z.array(Policy),
  activePack: z.string(), // rule-pack family the calculation uses
  preset: z.number().int().min(0).max(2), // employer policy preset applied to new trips
  profileId: z.string(),
  history: z.array(HistEntry),
  audit: z.array(z.object({ t: z.string(), op: z.string(), data: z.unknown() })),
});
export type Session = z.infer<typeof Session>;

const MIG: Record<number, (d: any) => any> = {}; // MIG[n]: schema n -> n+1
export function migrate(d: any) {
  while (d && typeof d.schema === 'number' && d.schema < SCHEMA) d = MIG[d.schema]!(d);
  return d;
}
