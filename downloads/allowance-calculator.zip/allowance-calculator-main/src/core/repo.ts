import type { z } from 'zod';
import { ImportProfile, Policy, RateList, RulePack, Session, migrate } from './schema';
import { checkRates } from './rates';
import type { Store } from './storage';
import { DEFAULT_POLICY, DEFAULT_PROFILE, STATUTORY } from '../rules/defaults';

export class DataError extends Error {}
export class Repo {
  s: Store;
  constructor(s: Store) {
    this.s = s;
  }

  private async load<T>(p: string, sch: z.ZodType<T>): Promise<T | null> {
    const t = await this.s.read(p);
    if (t === null) return null;
    const r = sch.safeParse(migrate(JSON.parse(t)));
    if (!r.success) throw new DataError(`${p}: ${r.error.message}`);
    return r.data;
  }
  private save(p: string, v: unknown) {
    return this.s.write(p, JSON.stringify(v, null, 2));
  }
  private async all<T>(dir: string, sch: z.ZodType<T>) {
    const out: T[] = [];
    for (const f of await this.s.list(dir)) {
      const v = await this.load(`${dir}/${f}`, sch);
      if (v) out.push(v);
    }
    return out;
  }
  private async once(p: string, v: unknown) {
    // versions are immutable
    if ((await this.s.read(p)) !== null) throw new DataError(`IMMUTABLE ${p}`);
    await this.save(p, v);
  }

  async rates(): Promise<RateList> {
    return (await this.load('rates.json', RateList)) ?? { schema: 1, sourceUrl: '', rows: [] };
  }
  async saveRates(r: RateList) {
    const v = RateList.parse(r);
    const dup = checkRates(v);
    if (dup.length) throw new DataError(`DUP_RATE ${dup[0]!.params.place} ${dup[0]!.params.from}`);
    const old = await this.s.read('rates.json'); // the previous list stays available
    if (old !== null) await this.s.write(`rates-history/${new Date().toISOString().replace(/[:.]/g, '-')}.json`, old);
    return this.save('rates.json', v);
  }

  async packs() {
    return [...STATUTORY, ...(await this.all('packs', RulePack))];
  }
  async savePack(p: RulePack) {
    const v = RulePack.parse(p);
    if (STATUTORY.some((x) => x.id === v.id && x.version === v.version)) throw new DataError('IMMUTABLE builtin');
    return this.once(`packs/${v.id}@${v.version}.json`, v);
  }

  async policies() {
    return [DEFAULT_POLICY, ...(await this.all('policies', Policy))];
  }
  async savePolicy(p: Policy) {
    const v = Policy.parse(p);
    return this.once(`policies/${v.id}@${v.version}.json`, v);
  }

  /** every version of every profile; the screens show the newest per id */
  async profiles() {
    return [DEFAULT_PROFILE, ...(await this.all('profiles', ImportProfile))];
  }
  async saveProfile(p: ImportProfile) {
    const v = ImportProfile.parse(p);
    return this.once(`profiles/${v.id}@${v.version}.json`, v);
  }
  /** all-or-nothing: validate every item and every path first; roll back if a write fails */
  async saveMany(kind: 'packs' | 'profiles', items: (RulePack | ImportProfile)[]) {
    const vs = items.map((x) => (kind === 'packs' ? RulePack.parse(x) : ImportProfile.parse(x)));
    const paths = vs.map((v) => `${kind}/${v.id}@${v.version}.json`);
    if (new Set(paths).size !== paths.length) throw new DataError('DUP_VERSION');
    if (kind === 'packs' && vs.some((v) => STATUTORY.some((x) => x.id === v.id && x.version === v.version)))
      throw new DataError('IMMUTABLE builtin');
    for (const p of paths) if ((await this.s.read(p)) !== null) throw new DataError(`IMMUTABLE ${p}`);
    const done: string[] = [];
    try {
      for (const [i, p] of paths.entries()) {
        done.push(p);
        await this.save(p, vs[i]);
      }
    } catch (e) {
      await Promise.allSettled(done.map((p) => this.s.remove(p)));
      throw e;
    }
  }
  async nextVersion(kind: 'packs' | 'profiles', id: string) {
    const all: { id: string; version: number }[] = kind === 'packs' ? await this.packs() : await this.profiles();
    return Math.max(0, ...all.filter((x) => x.id === id).map((x) => x.version)) + 1;
  }

  sessions() {
    return this.s.list('sessions');
  }
  loadSession(id: string) {
    return this.load(`sessions/${id}.json`, Session);
  }
  async saveSession(x: Session) {
    x.savedAt = new Date().toISOString();
    return this.save(`sessions/${x.id}.json`, Session.parse(x));
  }
}
