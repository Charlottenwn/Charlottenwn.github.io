import * as XLSX from 'xlsx';
import type { ImportProfile, Issue, ParsedSheet, SheetDay } from './schema';
import { PLACE, normPlace } from './rates';
import { daysIn } from './util';

const isBook = (b: Uint8Array) =>
  (b[0] === 0x50 && b[1] === 0x4b) || // xlsx (zip)
  (b[0] === 0xd0 && b[1] === 0xcf && b[2] === 0x11 && b[3] === 0xe0); // xls (OLE2)

export function readSheet(bytes: Uint8Array, sheet: number | string): unknown[][] {
  if (!isBook(bytes)) throw new Error('FILE_UNREADABLE');
  let wb: XLSX.WorkBook;
  try {
    wb = XLSX.read(bytes, { type: 'array' });
  } catch {
    throw new Error('FILE_UNREADABLE');
  }
  if (!wb.SheetNames.length) throw new Error('FILE_UNREADABLE');
  const ws = wb.Sheets[typeof sheet === 'number' ? (wb.SheetNames[sheet] ?? '') : sheet];
  if (!ws) throw new Error('SHEET_NOT_FOUND');
  return XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, raw: true, defval: null });
}
export const readAoa = (bytes: Uint8Array, pf: ImportProfile) => readSheet(bytes, pf.sheet);

const dayOf = (c: unknown): number | null => {
  if (typeof c === 'number')
    return c >= 1 && c <= 31 ? c : c >= 25569 ? new Date((c - 25569) * 864e5).getUTCDate() : null;
  const s = String(c ?? '').trim();
  const m = s.match(/^(\d{1,2})$/) ?? s.match(/^\d{4}-\d{2}-(\d{2})/) ?? s.match(/^(\d{1,2})[./]\d{1,2}[./]\d{2,4}$/);
  return m ? Number(m[1]) : null;
};
/** "8,57" or "5,49/0,57" (hours / of which night) -> minutes of the first number; decimal hours */
const hrs = (s: string) => {
  const a = s.split('/')[0]!.trim();
  const h = Number(a.replace(',', '.'));
  return a !== '' && Number.isFinite(h) && h >= 0 && h <= 24 ? Math.round(h * 60) : null;
};

const MONTH_STEMS = [
  'saus',
  'vasar',
  'kov',
  'baland',
  'gegu',
  'birž',
  'liep',
  'rugp',
  'rugs',
  'spal',
  'lapkr',
  'gruod',
];
/** year + Lithuanian month name (genitive "RUGSĖJO" or nominative) from the profile's title cells -> "2026-09" */
export function periodOf(aoa: unknown[][], pf: ImportProfile): string | null {
  if (!pf.yearCell || !pf.monthCell) return null;
  const y = String(aoa[pf.yearCell[0]]?.[pf.yearCell[1]] ?? '').trim();
  const mn = String(aoa[pf.monthCell[0]]?.[pf.monthCell[1]] ?? '')
    .trim()
    .toLowerCase();
  const m = MONTH_STEMS.findIndex((st) => mn.startsWith(st)) + 1;
  return /^\d{4}$/.test(y) && m ? `${y}-${String(m).padStart(2, '0')}` : null;
}

export function parseSheet(aoa: unknown[][], pf: ImportProfile, period: string): ParsedSheet {
  const issues: Issue[] = [],
    N = daysIn(period),
    hdr = aoa[pf.dayHeaderRow] ?? [],
    col = (i: number) => pf.firstDayCol + i * pf.dayColStep;
  for (let i = 0; i < N; i++) {
    const got = dayOf(hdr[col(i)]);
    if (got !== i + 1) {
      issues.push({
        level: 'error',
        code: 'HEADER_DAY_MISMATCH',
        params: { col: col(i), expected: i + 1, got: got ?? '' },
      });
      break; // first mismatch is enough: the profile or the month is wrong
    }
  }
  if (issues.length) return { period, employees: [], issues };

  const employees: ParsedSheet['employees'] = [],
    seen = new Set<string>(),
    K = pf.kMark.toUpperCase();
  for (let r = pf.firstEmployeeRow; r < aoa.length; r += pf.rowsPerEmployee) {
    const row = aoa[r] ?? [],
      kRow = aoa[r + pf.kRowOffset] ?? [],
      pRow = pf.placeRowOffset === null ? [] : (aoa[r + pf.placeRowOffset] ?? []),
      name = String(row[pf.nameCol] ?? '').trim();
    if (!name || (pf.indexCol !== null && !/^\d+$/.test(String(row[pf.indexCol] ?? '').trim()))) continue;
    if (seen.has(name)) {
      issues.push({ level: 'error', code: 'DUP_EMPLOYEE', params: { name } });
      continue;
    }
    seen.add(name);
    const days: SheetDay[] = [];
    for (let i = 0; i < N; i++) {
      const c = col(i),
        d = `${period}-${String(i + 1).padStart(2, '0')}`;
      const raw = String(row[c] ?? '')
          .trim()
          .toUpperCase(),
        kc = String(kRow[c] ?? '')
          .trim()
          .toUpperCase(),
        pl = normPlace(String(pRow[c] ?? '').trim());
      let min: number | null = null;
      if (raw && !pf.ignore.includes(raw)) {
        min = hrs(raw);
        if (min === null) issues.push({ level: 'error', code: 'BAD_CELL', params: { name, date: d, value: raw } });
      }
      const k = kc.startsWith(K);
      if (k) {
        // "K" or "K3,5" (hours override)
        const rest = kc.slice(K.length).trim();
        if (rest) {
          const m = hrs(rest);
          if (m === null) issues.push({ level: 'error', code: 'BAD_K_CELL', params: { name, date: d, value: kc } });
          else min = m;
        }
      } else if (kc) issues.push({ level: 'error', code: 'BAD_K_CELL', params: { name, date: d, value: kc } });
      const okPlace = PLACE.test(pl);
      if (pl && !okPlace) issues.push({ level: 'error', code: 'BAD_PLACE', params: { name, date: d, value: pl } });
      days.push({ d, min, k, ...(okPlace ? { place: pl } : {}) });
    }
    employees.push({ name, days });
  }
  return { period, employees, issues };
}
