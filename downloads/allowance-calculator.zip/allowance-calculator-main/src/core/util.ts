export const toDays = (iso: string) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10)) / 864e5;
export const fromDays = (n: number) => new Date(n * 864e5).toISOString().slice(0, 10);
export const addDays = (iso: string, n: number) => fromDays(toDays(iso) + n);
export const daysIn = (ym: string) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 0)).getUTCDate();
/** round-half-up n/d, integers only */
export const mulDiv = (n: number, d: number) => Math.floor((2 * n + d) / (2 * d));
export const stable = (v: unknown): string =>
  JSON.stringify(v, (_, x) =>
    x && typeof x === 'object' && !Array.isArray(x)
      ? Object.fromEntries(Object.entries(x).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
      : x,
  );
export async function sha(s: string) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
}

export const blank = (c: unknown) => c === null || c === undefined || String(c).trim() === '';

/** ISO, dd.mm.yyyy, dd/mm/yyyy or Excel serial (integer) -> ISO date, else null */
export function parseDate(c: unknown): string | null {
  let y: number, m: number, d: number;
  if (typeof c === 'number') {
    if (!Number.isInteger(c) || c < 25569) return null;
    const s = fromDays(c - 25569);
    [y, m, d] = [+s.slice(0, 4), +s.slice(5, 7), +s.slice(8, 10)];
  } else {
    const s = String(c ?? '').trim();
    const a = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const b = s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);
    if (a) [y, m, d] = [+a[1]!, +a[2]!, +a[3]!];
    else if (b) [y, m, d] = [+b[3]!, +b[2]!, +b[1]!];
    else return null;
  }
  const iso = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  return fromDays(toDays(iso)) === iso ? iso : null;
}
