export interface Store {
  read(p: string): Promise<string | null>;
  write(p: string, d: string): Promise<void>;
  list(dir: string): Promise<string[]>;
  remove(p: string): Promise<void>;
}
export class MemoryStore implements Store {
  m = new Map<string, string>();
  async read(p: string) {
    return this.m.get(p) ?? null;
  }
  async write(p: string, d: string) {
    this.m.set(p, d);
  }
  async list(dir: string) {
    return [...this.m.keys()]
      .filter((k) => k.startsWith(dir + '/') && !k.slice(dir.length + 1).includes('/'))
      .map((k) => k.slice(dir.length + 1));
  }
  async remove(p: string) {
    this.m.delete(p);
  }
}
export const isTauri = () => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
export async function makeStore(): Promise<Store> {
  return isTauri() ? new (await import('./storage.tauri')).TauriStore() : new MemoryStore();
}
