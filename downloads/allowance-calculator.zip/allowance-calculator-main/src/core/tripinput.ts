import type { Issue, TripInput } from './schema';
import { PLACE, normPlace } from './rates';
import { blank, parseDate } from './util';

export const TRIPS_SHEET = 'Trips';
export const TRIP_HEADERS = [
  'employee',
  'start',
  'place',
  'from',
  'transit',
  'reduction',
  'pct',
  'notified',
  'daily_return',
];
const ALIAS = new Map([
  ['darbuotojas', 'employee'],
  ['pradžia', 'start'],
  ['pradzia', 'start'],
  ['vieta', 'place'],
  ['šalis', 'place'],
  ['salis', 'place'],
  ['nuo', 'from'],
  ['tranzitas', 'transit'],
  ['mažinimas', 'reduction'],
  ['mazinimas', 'reduction'],
  ['proc', 'pct'],
  ['informuotas', 'notified'],
  ['kasdien grįžta', 'daily_return'],
  ['kasdien grizta', 'daily_return'],
]);
const YES = new Set(['taip', 'yes', 'true', '1', 'x', 'y', 't']);
const NO = new Set(['', 'ne', 'no', 'false', '0', 'n', 'f']);
const bool = (c: unknown): boolean | null => {
  const s = String(c ?? '')
    .trim()
    .toLowerCase();
  return YES.has(s) ? true : NO.has(s) ? false : null;
};
/** "50", "50%", "50,5" -> bp. Bare 0<n<=1 is ambiguous (fraction or percent) -> null. */
const toBp = (c: unknown): number | null => {
  const s = String(c ?? '')
      .trim()
      .replace(',', '.'),
    pc = s.endsWith('%');
  const n = Number(pc ? s.slice(0, -1).trim() : s);
  if (s === '' || !Number.isFinite(n) || n < 0 || n > 100) return null;
  if (!pc && n > 0 && n <= 1) return null;
  return Math.round(n * 100);
};

/** One row per leg; trip-level fields (reduction, pct, notified, daily_return) on the trip's first row. */
export function parseTripInputs(aoa: unknown[][]): { inputs: TripInput[]; issues: Issue[] } {
  const issues: Issue[] = [];
  const err = (code: string, params: Issue['params']) => {
    issues.push({ level: 'error', code, params });
  };
  const hdr = (aoa[0] ?? []).map((c) => {
    const h = String(c ?? '')
      .trim()
      .toLowerCase();
    return ALIAS.get(h) ?? h;
  });
  const miss = ['employee', 'start', 'place', 'from'].filter((h) => !hdr.includes(h));
  if (miss.length) {
    err('MISSING_COLUMNS', { columns: miss.join(',') });
    return { inputs: [], issues };
  }
  const trips = new Map<string, TripInput>(),
    legKeys = new Set<string>(),
    bad = new Set<string>();

  aoa.slice(1).forEach((r, i) => {
    if (r.every(blank)) return;
    const row = i + 2,
      before = issues.length;
    const cell = (h: string) => {
      const k = hdr.indexOf(h);
      return k < 0 ? undefined : r[k];
    };
    const fail = (code: string, params: Issue['params']) => err(code, { row, ...params });
    const employee = String(cell('employee') ?? '').trim(),
      start = parseDate(cell('start'));
    const place = normPlace(String(cell('place') ?? '').trim()),
      from = parseDate(cell('from'));
    if (!employee) fail('BAD_EMPLOYEE', {});
    if (!start) fail('BAD_DATE', { field: 'start', value: String(cell('start') ?? '') });
    if (!from) fail('BAD_DATE', { field: 'from', value: String(cell('from') ?? '') });
    if (!PLACE.test(place)) fail('BAD_PLACE', { value: place });
    const transit = bool(cell('transit'));
    if (transit === null) fail('BAD_FLAG', { field: 'transit' });
    const notified = blank(cell('notified')) ? undefined : bool(cell('notified'));
    if (notified === null) fail('BAD_FLAG', { field: 'notified' });
    const daily = blank(cell('daily_return')) ? undefined : bool(cell('daily_return'));
    if (daily === null) fail('BAD_FLAG', { field: 'daily_return' });
    const src = String(cell('reduction') ?? '')
      .trim()
      .toLowerCase();
    let reduction: { source: 'none' | 'ca' | 'local'; bp: number } | undefined;
    if (src && !['none', 'ca', 'local'].includes(src)) fail('BAD_REDUCTION', { value: src });
    else if (src === 'none') reduction = { source: 'none', bp: 10000 };
    else if (src) {
      const bp = toBp(cell('pct'));
      if (bp === null) fail('BAD_PCT', { value: String(cell('pct') ?? '') });
      else reduction = { source: src as 'ca' | 'local', bp };
    }
    if (issues.length > before || !start || !from) return;

    const key = `${employee}|${start}`,
      legKey = `${key}|${place}|${from}`;
    if (legKeys.has(legKey)) {
      err('DUP_LEG', { row, employee, start, place, from });
      bad.add(key);
      return;
    }
    legKeys.add(legKey);
    const leg = { place, from, ...(transit ? { transit: true } : {}) };
    const t = trips.get(key);
    if (!t) {
      trips.set(key, {
        employee,
        start,
        legs: [leg],
        reduction: reduction ?? null,
        notified: notified ?? false,
        dailyReturn: daily ?? false,
      });
      return;
    }
    t.legs.push(leg);
    const clash = (field: string) => {
      err('INCONSISTENT_TRIP', { row, employee, start, field });
      bad.add(key);
    };
    if (reduction !== undefined && JSON.stringify(reduction) !== JSON.stringify(t.reduction)) clash('reduction');
    if (notified !== undefined && notified !== t.notified) clash('notified');
    if (daily !== undefined && daily !== t.dailyReturn) clash('daily_return');
  });

  const inputs: TripInput[] = [];
  for (const [key, t] of trips) {
    if (bad.has(key)) continue;
    t.legs.sort((a, b) => a.from.localeCompare(b.from));
    if (t.legs[0]!.from > t.start)
      issues.push({
        level: 'warn',
        code: 'FIRST_LEG_AFTER_START',
        params: { employee: t.employee, start: t.start },
      });
    if (t.legs.some((l) => l.from < t.start))
      issues.push({ level: 'warn', code: 'LEG_BEFORE_START', params: { employee: t.employee, start: t.start } });
    inputs.push(t);
  }
  return { inputs, issues };
}
