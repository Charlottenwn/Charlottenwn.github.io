import { isTauri } from './storage';

export async function saveBytes(name: string, data: Uint8Array | string): Promise<boolean> {
  const b = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  if (isTauri()) {
    const { save } = await import('@tauri-apps/plugin-dialog');
    const { writeFile } = await import('@tauri-apps/plugin-fs');
    const p = await save({ defaultPath: name });
    if (!p) return false;
    await writeFile(p, b);
    return true;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([b as BlobPart]));
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
  return true;
}
export async function openBytes(ext: string[]): Promise<{ name: string; bytes: Uint8Array } | null> {
  if (isTauri()) {
    const { open } = await import('@tauri-apps/plugin-dialog');
    const { readFile } = await import('@tauri-apps/plugin-fs');
    const p = await open({ filters: [{ name: 'file', extensions: ext }] });
    return typeof p === 'string' ? { name: p.split(/[\\/]/).pop()!, bytes: await readFile(p) } : null;
  }
  return new Promise((res) => {
    const i = document.createElement('input');
    i.type = 'file';
    i.accept = ext.map((e) => '.' + e).join(',');
    i.onchange = async () => {
      const f = i.files?.[0];
      res(f ? { name: f.name, bytes: new Uint8Array(await f.arrayBuffer()) } : null);
    };
    i.click();
  });
}

/** open a link in the system browser (Tauri opener plugin when running as the desktop app) */
export async function openExternal(url: string) {
  if (isTauri()) {
    try {
      const { openUrl } = await import('@tauri-apps/plugin-opener');
      await openUrl(url);
      return;
    } catch {
      /* plugin not installed: fall through */
    }
  }
  window.open(url, '_blank', 'noopener');
}
