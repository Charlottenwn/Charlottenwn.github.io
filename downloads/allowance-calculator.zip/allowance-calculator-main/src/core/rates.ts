import type { Issue, RateList, RateRow } from './schema';
import { blank, parseDate } from './util';

export const PLACE = /^[A-Z]{2}(\/\S.*)?$/; // "DE" or "DE/Berlin"
export const normPlace = (s: string) => s.replace(/^[a-z]{2}(?=$|\/)/, (m) => m.toUpperCase());
const eurOf = (c: unknown) => (typeof c === 'number' ? c : blank(c) ? NaN : Number(String(c).trim().replace(',', '.')));

/** columns: place | EUR/day | valid from. A first row with a non-numeric rate is a header. */
export function parseRates(aoa: unknown[][]): { rows: RateRow[]; issues: Issue[] } {
  const rows: RateRow[] = [],
    issues: Issue[] = [],
    seen = new Set<string>();
  aoa.forEach((r, i) => {
    const row = i + 1;
    if (r.every(blank)) return;
    const eur = eurOf(r[1]);
    if (i === 0 && !Number.isFinite(eur)) return;
    const place = normPlace(String(r[0] ?? '').trim()),
      from = parseDate(r[2]);
    const bad = (code: string, value: string) => issues.push({ level: 'error', code, params: { row, value } });
    const okPlace = PLACE.test(place),
      okRate = Number.isFinite(eur) && eur >= 0;
    if (!okPlace) bad('BAD_PLACE', place);
    if (!okRate) bad('BAD_RATE', String(r[1] ?? ''));
    if (!from) bad('BAD_DATE', String(r[2] ?? ''));
    if (!okPlace || !okRate || !from) return;
    const key = `${place}|${from}`;
    if (seen.has(key)) {
      issues.push({ level: 'error', code: 'DUP_RATE', params: { row, place, from } });
      return;
    }
    seen.add(key);
    const cents = Math.round(eur * 100);
    if (Math.abs(eur * 100 - cents) > 1e-6)
      issues.push({ level: 'warn', code: 'RATE_ROUNDED', params: { row, value: String(r[1]) } });
    rows.push({ place, cents, validFrom: from });
  });
  return { rows, issues };
}

export function mergeRates(base: RateList, add: RateRow[], mode: 'add' | 'replace') {
  const old = new Map(base.rows.map((r): [string, RateRow] => [`${r.place}|${r.validFrom}`, r]));
  const map = mode === 'replace' ? new Map<string, RateRow>() : new Map(old);
  let added = 0,
    changed = 0,
    same = 0;
  for (const r of add) {
    const k = `${r.place}|${r.validFrom}`,
      o = old.get(k);
    if (!o) added++;
    else if (o.cents !== r.cents) changed++;
    else same++;
    map.set(k, r);
  }
  const rows = [...map.values()].sort(
    (a, b) => a.place.localeCompare(b.place) || a.validFrom.localeCompare(b.validFrom),
  );
  return { list: { ...base, rows }, added, changed, same };
}

export function checkRates(l: RateList): Issue[] {
  const seen = new Set<string>(),
    out: Issue[] = [];
  for (const r of l.rows) {
    const k = `${r.place}|${r.validFrom}`;
    if (seen.has(k)) out.push({ level: 'error', code: 'DUP_RATE', params: { place: r.place, from: r.validFrom } });
    seen.add(k);
  }
  return out;
}
