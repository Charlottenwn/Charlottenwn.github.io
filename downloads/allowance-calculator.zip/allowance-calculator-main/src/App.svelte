<script lang="ts">
  import { onMount } from 'svelte';
  import { allTrips, APP } from './core/api';
  import Check from './ui/Check.svelte';
  import { acc, btn, card, ink, line, mut, pri } from './ui/cls';
  import History from './ui/History.svelte';
  import Import from './ui/Import.svelte';
  import Pack from './ui/Pack.svelte';
  import Packs from './ui/Packs.svelte';
  import { placeName } from './ui/places';
  import Profiles from './ui/Profiles.svelte';
  import RatesTab from './ui/RatesTab.svelte';
  import Result from './ui/Result.svelte';
  import { ui } from './ui/state.svelte';
  import { eur, NAV, plural, STEPS } from './ui/strings';
  import Trips from './ui/Trips.svelte';
  import Msg from './ui/Msg.svelte';

  onMount(() => {
    if (!ui.ready && !ui.fatal) void ui.init();
  });
  const acc2 = $derived([true, true, ui.mOk, ui.mOk && ui.tOk, ui.mOk && ui.tOk && ui.checks.length === 0]);
  const url = $derived.by(() => {
    void ui.rev;
    return ui.session?.rates.sourceUrl ?? '';
  });
  function nav(i: number) {
    ui.tab = i;
    ui.ed = null;
    if (i === 3) ui.openRates();
    else ui.rd = null;
  }
</script>

{#if ui.fatal}
  <div class="p-12 {ink}">
    <h2 class="text-2xl font-semibold">Nepavyko paleisti programos</h2>
    <p class="mt-3 text-sm">{ui.fatal}</p>
  </div>
{:else if !ui.ready}
  <p class="p-12 text-sm {mut}">Kraunama…</p>
{:else}
  <div class="min-h-screen grid lg:grid-cols-[280px_1fr] font-sans {ink}">
    <aside class="border-b lg:border-b-0 lg:border-r {line} p-8 lg:p-10 lg:sticky lg:top-0 lg:h-screen overflow-y-auto">
      <div class="text-lg font-semibold tracking-tight">Dienpinigiai</div>
      <div class="text-xs mt-1 {mut}">Skaičiuoklė pagal Nr. 526 projektą</div>
      <nav class="mt-10 space-y-1" aria-label="Sritys">
        {#each NAV as n, i (i)}
          <button
            class="w-full text-left px-3 py-2 text-sm border-l-2 {ui.tab === i
              ? 'border-emerald-700 font-semibold ' + ink
              : 'border-transparent ' + mut + ' hover:text-slate-900 dark:hover:text-white'}"
            aria-current={ui.tab === i ? 'page' : undefined}
            onclick={() => nav(i)}>{n}</button
          >
          {#if i === 0 && ui.tab === 0}
            <ol class="ml-3 my-2 space-y-1 border-l {line}">
              {#each STEPS as s, j (j)}
                <li>
                  <button
                    class="w-full text-left pl-4 py-1.5 text-[13px] disabled:opacity-35 disabled:cursor-not-allowed {ui.step ===
                    j
                      ? acc + ' font-medium'
                      : mut}"
                    disabled={!acc2[j]}
                    onclick={() => ui.go(j)}><span class="font-mono mr-2">{j + 1}</span>{s}</button
                  >
                </li>
              {/each}
            </ol>
          {/if}
        {/each}
      </nav>
    </aside>

    <main class="flex flex-col min-w-0">
      <div class="flex flex-wrap items-center justify-between gap-4 px-8 lg:px-12 py-5 border-b {line}">
        <span class="text-xs {mut}">{ui.sess}</span>
        <div class="flex gap-2">
          <button class={btn} onclick={() => ui.pickSession()}>Atidaryti sesiją</button>
          <button class={btn} onclick={() => ui.saveSession()}>Išsaugoti sesiją</button>
          <button class={btn} onclick={() => ui.setTheme(!ui.dark)} aria-pressed={ui.dark}>
            {ui.dark ? 'Šviesi tema' : 'Tamsi tema'}
          </button>
        </div>
      </div>
      <div class="flex-1 p-8 lg:p-12 max-w-4xl w-full fade">
        {#if ui.busy}<p aria-live="polite" class="text-sm {mut} mb-4">{ui.busy}…</p>{/if}
        {#if ui.err}
          <div role="alert" class="flex items-start justify-between gap-4">
            <Msg kind="error" text={ui.err} />
            <button class={btn} onclick={() => (ui.err = '')}>Uždaryti</button>
          </div>
        {/if}
        {#if ui.tab === 0}
          {#if ui.step === 0}<Pack />
          {:else if ui.step === 1}<Import />
          {:else if ui.step === 2}<Trips />
          {:else if ui.step === 3}<Check />
          {:else}<Result />{/if}
        {:else if ui.tab === 1}<Packs />
        {:else if ui.tab === 2}<Profiles />
        {:else if ui.tab === 4}<History />
        {:else}<RatesTab />{/if}
      </div>

      <footer class="px-8 lg:px-12 py-6 border-t {line} text-xs leading-6 flex flex-wrap justify-between gap-x-8 {mut}">
        {#if /^https?:\/\//.test(url)}
          <button class="underline {acc}" onclick={() => ui.link(url)}>Tarifų lentelė</button>
        {:else}
          <span>Tarifų lentelės nuoroda nenurodyta</span>
        {/if}
        <span class="font-mono">Skaičiuoklė {APP} · {ui.pack.label} v{ui.pack.version} · tarifų hash {ui.stamp}</span>
        <span class="basis-full">Ne teisinė konsultacija.</span>
      </footer>
    </main>
  </div>

  {#if ui.modal}
    <div class="fixed inset-0 z-20 grid place-items-center bg-slate-950/50 p-6" role="dialog" aria-modal="true">
      <div class="{card} !bg-white dark:!bg-slate-900 max-w-lg w-full p-10">
        {#if ui.modal === 'open' && ui.opened}
          {@const n = Object.keys(ui.opened.session.sheets).length}
          {@const k = allTrips(ui.opened.session).length}
          <h3 class="text-xl font-semibold tracking-tight">Atidaryta sesija</h3>
          <p class="text-sm leading-7 mt-3 {mut}">
            {n}
            {plural(n, 'mėnuo', 'mėnesiai', 'mėnesių')}, {k}
            {plural(k, 'komandiruotė', 'komandiruotės', 'komandiruočių')}. Ar žiniaraščiai, taisyklės ar tarifai
            pasikeitė nuo išsaugojimo?
          </p>
          <div class="flex flex-wrap gap-3 mt-8">
            <button class={pri} onclick={() => ui.loadSaved(true)}>Taip, perskaičiuoti</button>
            <button class={btn} onclick={() => ui.loadSaved(false)}>Ne, palikti išsaugotą</button>
          </div>
        {:else}
          <h3 class="text-xl font-semibold tracking-tight">Išsaugoti tarifai</h3>
          <p class="text-sm mt-2 {mut}">Tik skaitymui. Hash {ui.stamp}.</p>
          <table class="w-full text-sm mt-6">
            <tbody class="font-mono text-xs">
              {#each ui.session!.rates.rows as r, i (i)}
                <tr class="border-t {line}">
                  <td class="py-2 font-sans text-sm">{placeName(r.place)}</td>
                  <td class="text-right">{eur(r.cents)}</td>
                  <td class="text-right">{r.validFrom}</td>
                </tr>
              {/each}
            </tbody>
          </table>
          <div class="mt-8"><button class={btn} onclick={() => (ui.modal = '')}>Uždaryti</button></div>
        {/if}
      </div>
    </div>
  {/if}
  {#if ui.note}
    <div
      class="fixed left-1/2 -translate-x-1/2 bottom-6 z-30 bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-sm px-4 py-2 rounded-md"
      role="status"
    >
      {ui.note}
    </div>
  {/if}
{/if}
