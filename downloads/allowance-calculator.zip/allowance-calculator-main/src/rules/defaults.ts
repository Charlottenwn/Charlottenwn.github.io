import type { ImportProfile, Policy, RulePack, Switches } from '../core/schema';

export const NO_ANSWERS: Switches = {
  dailyReturnIsOneTrip: null,
  shortRuleOnOneDayAbroad: null,
  ltLongerThanWorkdayIsMultiDay: null,
  shortRuleOnReducedRate: null,
};

export const STATUTORY: RulePack[] = [
  {
    schema: 1,
    id: 'LT-526',
    version: 1,
    label: 'Standartinis',
    effectiveFrom: '1900-01-01',
    effectiveTo: '2026-09-30',
    switches: { ...NO_ANSWERS },
    params: {
      shortDayMin: null,
      shortDayBp: 2000,
      caMinBp: 5000,
      localMinBp: 5000,
      localMinTripDays: 0,
      noticeRequired: false,
      domesticOneDayBp: 10000,
    },
  },
  {
    schema: 1,
    id: 'LT-526',
    version: 2,
    label: 'Standartinis',
    effectiveFrom: '2026-10-01',
    effectiveTo: null,
    switches: { ...NO_ANSWERS },
    params: {
      shortDayMin: 240,
      shortDayBp: 2000,
      caMinBp: 5000,
      localMinBp: 6500,
      localMinTripDays: 7,
      noticeRequired: true,
      domesticOneDayBp: 0,
    },
  },
];

export const DEFAULT_POLICY: Policy = {
  schema: 1,
  id: 'default',
  version: 1,
  label: 'Default',
  effectiveFrom: '1900-01-01',
  effectiveTo: null,
  workdayMin: 480,
  defaultReduction: { source: 'none', bp: 10000 },
};

// codes in the hours row that carry no hours (S/P + the legend of the official form, Nutarimas Nr. 78)
const CODES = [
  'S',
  'P',
  'K',
  'V',
  'M',
  'D',
  'L',
  'N',
  'NS',
  'A',
  'MA',
  'NA',
  'KA',
  'G',
  'ID',
  'PV',
  'MD',
  'KV',
  'VV',
  'KT',
  'KM',
  'PK',
  'PN',
  'PB',
  'ND',
  'NP',
  'KR',
  'NN',
  'ST',
  'TA',
  'TN',
];

/** Darbo laiko apskaitos žiniaraštis: 6-row employee blocks (hours / country / K), days in merged column pairs from AC */
export const DEFAULT_PROFILE: ImportProfile = {
  schema: 1,
  id: 'default',
  version: 1,
  label: 'Standartinis žiniaraštis',
  sheet: 0,
  dayHeaderRow: 15,
  firstDayCol: 28,
  dayColStep: 2,
  nameCol: 5,
  indexCol: 0,
  firstEmployeeRow: 24,
  rowsPerEmployee: 6,
  placeRowOffset: 2,
  kRowOffset: 4,
  yearCell: [10, 19],
  monthCell: [10, 34],
  kMark: 'K',
  ignore: CODES,
};

/** compact layout: name + hours row, K row right below, one column per day (tests, simple exports) */
export const SIMPLE_PROFILE: ImportProfile = {
  schema: 1,
  id: 'simple',
  version: 1,
  label: 'Simple: name + hours row, K row below',
  sheet: 0,
  dayHeaderRow: 0,
  firstDayCol: 1,
  dayColStep: 1,
  nameCol: 0,
  indexCol: null,
  firstEmployeeRow: 1,
  rowsPerEmployee: 2,
  placeRowOffset: null,
  kRowOffset: 1,
  yearCell: null,
  monthCell: null,
  kMark: 'K',
  ignore: ['S', 'P'],
};

/** employer policy presets: the default reduction given to new trips */
export const PRESETS: { n: string; src: 'none' | 'ca' | 'local'; pct: number }[] = [
  { n: 'Nemažinti', src: 'none', pct: 100 },
  { n: 'Kolektyvinė sutartis, 50 %', src: 'ca', pct: 50 },
  { n: 'Vietinis aktas, 80 %', src: 'local', pct: 80 },
];
