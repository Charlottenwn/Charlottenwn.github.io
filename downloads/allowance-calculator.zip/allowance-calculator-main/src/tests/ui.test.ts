// @vitest-environment jsdom
/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/svelte';
import { tick } from 'svelte';
import * as XLSX from 'xlsx';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import App from '../App.svelte';
import { APP, setSheet } from '../core/api';
import { openBytes, openExternal, saveBytes } from '../core/io';
import type { RateList } from '../core/schema';
import { MemoryStore } from '../core/storage';
import { SIMPLE_PROFILE } from '../rules/defaults';
import { ui, type Edit } from '../ui/state.svelte';
import { eur, HINT, SWITCH_KEYS } from '../ui/strings';

vi.mock('../core/io', () => ({
  saveBytes: vi.fn(async () => {}),
  openBytes: vi.fn(async () => null),
  openExternal: vi.fn(async () => {}),
}));

const fixture = new Uint8Array(readFileSync('src/tests/fixtures/timesheet-2026-09.xlsx')); // cwd = repo root
const RATES: RateList = {
  schema: 1,
  sourceUrl: 'https://example.test/rates',
  rows: [
    ['LT', 2800],
    ['LV', 4400],
    ['EE', 4000],
    ['SE', 5000],
    ['DE', 6200],
  ].map(([place, cents]) => ({
    place: place as string,
    cents: cents as number,
    validFrom: '2000-01-01',
  })),
};
const xlsx = (rows: unknown[][]) => {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), 'S');
  return new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
};
/** compact layout (SIMPLE_PROFILE): name + hours row, K row below, one column per day */
const simple = (cell: unknown, days = 31) => {
  const d = Array.from({ length: days }, (_, i) => i + 1);
  return xlsx([
    ['Name', ...d],
    ['Jonas', ...d.map((x) => (x === 2 ? cell : null))],
    ['', ...d.map((x) => (x === 2 ? 'K' : null))],
  ]);
};

const main = () => within(screen.getByRole('main'));
const click = (name: string | RegExp, root = main()) => fireEvent.click(root.getByRole('button', { name }));
const setRates = async (r: RateList = RATES) => {
  await ui.repo.saveRates(r);
  ui.session!.rates = r;
  await ui.after();
};
const edit = <K extends 'p' | 'f'>() => ui.ed as Extract<Edit, { k: K }>;
/** fixture + rates + all four answers + every trip that lacks data marked incomplete */
async function finish() {
  await setRates();
  await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
  ui.editPack('LT-526');
  edit<'p'>().o.sw = [1, 1, 1, 1];
  await ui.commitEdit();
  for (const t of ui.trips.filter((x) => ui.needs(x))) {
    ui.openTrip(t.trip.id);
    ui.saveTrip(true);
  }
}
const octMonth = (trips: Record<number, string>) => ({
  period: '2026-10',
  issues: [],
  employees: [
    {
      name: 'Jonas',
      days: Array.from({ length: 31 }, (_, i) => ({
        d: `2026-10-${String(i + 1).padStart(2, '0')}`,
        min: 480,
        k: !!trips[i + 1],
        ...(trips[i + 1] ? { place: trips[i + 1] } : {}),
      })),
    },
  ],
});

beforeEach(async () => {
  Object.assign(ui, {
    tab: 0,
    step: 0,
    sel: null,
    draft: null,
    skip: false,
    det: false,
    load: false,
    modal: '',
    note: '',
    ed: null,
    rd: null,
    hf: 'all',
    period: '',
    pend: null,
    issues: [],
    opened: null,
    last: null,
    ready: false,
    fatal: null,
    sess: 'Nauja sesija, neišsaugota',
  });
  await ui.init(new MemoryStore());
  vi.mocked(saveBytes).mockClear();
  vi.mocked(openBytes).mockReset().mockResolvedValue(null);
  vi.mocked(openExternal).mockClear();
});
afterEach(cleanup);

describe('shell', () => {
  it('sidebar, steps are gated, footer shows pack and rates hash, theme toggles', async () => {
    render(App);
    for (const n of ['Skaičiuoti', 'Taisyklių paketai', 'Profiliai', 'Tarifai', 'Istorija'])
      expect(screen.getByRole('button', { name: n })).toBeTruthy();
    const steps = screen.getAllByRole('button', {
      name: /^\dPaketas|^\dŽiniaraštis|^\dKomandiruotės|^\dPatikra|^\dRezultatas/,
    });
    expect(steps.map((b) => (b as HTMLButtonElement).disabled)).toEqual([false, false, true, true, true]);
    expect(
      screen.getByText(
        new RegExp(`Skaičiuoklė ${APP.replaceAll('.', '\\.')} · Standartinis v2 · tarifų hash [0-9a-f]{8}`),
      ),
    ).toBeTruthy();
    expect(screen.getByText('Ne teisinė konsultacija.')).toBeTruthy();
    await fireEvent.click(screen.getByRole('button', { name: 'Tamsi tema' }));
    expect(document.documentElement.classList.contains('dark')).toBe(true);
    await fireEvent.click(screen.getByRole('button', { name: 'Šviesi tema' }));
    expect(document.documentElement.classList.contains('dark')).toBe(false);
  });
  it('rates link opens through the system browser', async () => {
    await setRates();
    render(App);
    await fireEvent.click(screen.getByRole('button', { name: 'Tarifų lentelė' }));
    expect(openExternal).toHaveBeenCalledWith('https://example.test/rates');
  });
  it('no link text when the rates have no address; startup failure is shown', async () => {
    render(App);
    expect(screen.getByText('Tarifų lentelės nuoroda nenurodyta')).toBeTruthy();
    cleanup();
    ui.ready = false;
    ui.fatal = 'boom';
    render(App);
    expect(screen.getByText('Nepavyko paleisti programos')).toBeTruthy();
    ui.fatal = null;
  });
  it('footer link appears after rates are saved', async () => {
    render(App);
    expect(screen.queryByRole('button', { name: 'Tarifų lentelė' })).toBeNull();
    ui.session!.rates = { ...ui.session!.rates, sourceUrl: 'https://example.test/rates' };
    ui.rev++;
    expect(await screen.findByRole('button', { name: 'Tarifų lentelė' })).toBeTruthy();
  });
});

describe('step 0: pack and policy', () => {
  it('policy changes are logged and become the default for new trips', async () => {
    render(App);
    expect(main().getByRole('option', { name: 'Standartinis v2' })).toBeTruthy();
    await fireEvent.change(main().getByLabelText(/Darbdavio politika/), { target: { value: '1' } });
    expect(ui.session!.preset).toBe(1);
    expect(ui.session!.history[0]!.x).toBe('Politika: Kolektyvinė sutartis, 50 % (taikoma naujoms komandiruotėms)');
    await click('Toliau');
    expect(main().getByText('Žiniaraštis dar neįkeltas')).toBeTruthy();
  });
});

describe('step 1: timesheet', () => {
  it('real timesheet: month card with file name and counts, next step opens', async () => {
    await setRates();
    ui.step = 1;
    render(App);
    expect(main().getByText('Žiniaraštis dar neįkeltas')).toBeTruthy();
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    await tick();
    expect(main().getByText('2026 rugsėjis')).toBeTruthy();
    expect(main().getByText('timesheet-2026-09.xlsx')).toBeTruthy();
    expect(
      main().getByText(
        new RegExp(
          `Visos eilutės tinkamos. Rasta komandiruočių: ${ui.trips.length}, apskaičiuota automatiškai .*: \\d+\\.`,
        ),
      ),
    ).toBeTruthy();
    expect(ui.session!.history[0]!.x).toMatch(
      /^Įkeltas timesheet-2026-09\.xlsx: \d+ komandiruotė\(s\) apskaičiuota automatiškai$/,
    );
    await click('Toliau');
    expect(main().getByRole('heading', { name: 'Komandiruotės' })).toBeTruthy();
  });
  it('wrong layout: one clear error, nothing imported, retry picks again', async () => {
    ui.step = 1;
    ui.period = '2026-03'; // the compact sheet has 28 day columns, March needs 31
    await ui.loadFile(simple(8, 28), 'x.xlsx');
    render(App);
    expect(main().getAllByText(/Netinka dienų antraštė/)).toHaveLength(1);
    expect(ui.months.length).toBe(0);
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'again.xlsx', bytes: fixture });
    await click('Pasirinkti kitą failą');
    await waitFor(() => expect(ui.months.length).toBe(1));
  });
  it('bad cell: offered to skip, then imported; "taisyti" re-reads the file', async () => {
    ui.profiles = [...ui.profiles, SIMPLE_PROFILE];
    ui.session!.profileId = 'simple';
    ui.step = 1;
    ui.period = '2026-10';
    await ui.loadFile(simple('abc'), 'bad.xlsx');
    render(App);
    expect(main().getByText(/Jonas, 2026-10-02: kodas „ABC“ neatpažintas/)).toBeTruthy();
    expect((main().getByRole('button', { name: 'Toliau' }) as HTMLButtonElement).disabled).toBe(true);
    await click('Praleisti blogas eilutes');
    expect(main().getByText(/Blogos eilutės praleistos\./)).toBeTruthy();
    expect((main().getByRole('button', { name: 'Toliau' }) as HTMLButtonElement).disabled).toBe(false);
    await waitFor(() => expect(ui.session!.history.map((h) => h.x)).toContain('Blogos eilutės praleistos'));
  });
  it('unreadable file -> FILE_UNREADABLE, not SHEET_NOT_FOUND', async () => {
    await ui.loadFile(new Uint8Array(0), 'x.xlsx');
    expect(ui.issues[0]?.code).toBe('FILE_UNREADABLE');
  });
  it('month missing from the sheet: type it and retry', async () => {
    ui.profiles = [...ui.profiles, SIMPLE_PROFILE];
    ui.session!.profileId = 'simple';
    ui.step = 1;
    await ui.loadFile(simple(8), 'm.xlsx');
    render(App);
    expect(main().getByText(/Nepavyko nustatyti mėnesio/)).toBeTruthy();
    await fireEvent.input(main().getByLabelText('Mėnuo'), { target: { value: '2026-10' } });
    await click('Bandyti iš naujo');
    await waitFor(() => expect(main().getByText('2026 spalis')).toBeTruthy());
  });
});

describe('step 2: trips', () => {
  it('list: automatic and missing-data trips, next is locked until all are handled', async () => {
    await setRates();
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    ui.step = 2;
    render(App);
    expect(main().getAllByText('automatiškai iš žiniaraščio').length).toBe(4); // employee 1: four trips with a country on every day
    expect(main().getAllByText('trūksta duomenų').length).toBeGreaterThan(1);
    expect((main().getByRole('button', { name: 'Toliau' }) as HTMLButtonElement).disabled).toBe(true);
    expect(main().getAllByText(/^\d\d\d\d-09-\d\d – 2026-09-\d\d$/).length).toBe(ui.trips.length);
  });
  it('edit a trip: set the country per day, live sum, save, history keeps before/after', async () => {
    await setRates();
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    const t = ui.trips.find((x) => x.trip.employee.endsWith('2'))!;
    ui.step = 2;
    ui.openTrip(t.trip.id);
    render(App);
    expect((main().getByRole('button', { name: 'Išsaugoti' }) as HTMLButtonElement).disabled).toBe(true);
    for (const d of t.trip.days)
      await fireEvent.change(main().getByLabelText(`Valstybė ${d.d}`), { target: { value: 'DE' } });
    expect((main().getByRole('button', { name: 'Išsaugoti' }) as HTMLButtonElement).disabled).toBe(false);
    expect(main().getByText(eur(6200 * t.trip.days.length))).toBeTruthy();
    const before = ui.total;
    await click('Išsaugoti');
    expect(screen.getByRole('status').textContent).toBe('Komandiruotė išsaugota');
    expect(ui.total).toBe(before + 6200 * t.trip.days.length);
    expect(main().getAllByText('patikrinta ranka').length).toBe(1);
    const h = ui.session!.history[0]!;
    expect([h.k, h.a, h.b]).toEqual(['trip', before, ui.total]);
    expect(h.x).toMatch(/valstybė – → Vokietija/);
  });
  it('hours edited by hand are used; back discards; incomplete leaves the sum', async () => {
    await setRates();
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    const t = ui.trips[0]!;
    ui.step = 2;
    ui.openTrip(t.trip.id);
    render(App);
    const day = t.trip.days[0]!.d;
    await fireEvent.input(main().getByLabelText(`Valandos ${day}`), { target: { value: '3' } });
    expect(ui.draft!.h[0]).toBe(3);
    await click('Atgal');
    expect(ui.session!.inputs[t.trip.id]!.days).toBeUndefined();
    expect(ui.session!.history.filter((h) => h.k === 'trip')).toHaveLength(0);
    ui.openTrip(t.trip.id);
    await tick();
    const before = ui.total;
    await click('Pažymėti nebaigta');
    expect(ui.total).toBeLessThan(before);
    expect(main().getAllByText('pažymėta nebaigta')).toHaveLength(1);
    expect(ui.session!.history[0]!.x).toMatch(/pažymėta nebaigta$/);
  });
  it('reduction messages: below the minimum blocks saving; October rules warn and keep 100 %', async () => {
    await setRates();
    setSheet(ui.session!, octMonth({ 5: 'LV', 6: 'LV', 7: 'LV' }));
    ui.session!.preset = 0;
    const { ensureInputs } = await import('../core/api');
    ensureInputs(ui.session!);
    await ui.after();
    ui.step = 2;
    ui.openTrip('Jonas|2026-10-05');
    render(App);
    await fireEvent.change(main().getByLabelText('Šaltinis'), { target: { value: 'ca' } });
    await fireEvent.input(main().getByLabelText('Sutarta dalis, proc.'), { target: { value: '40' } });
    expect(main().getByText(/Kolektyvinėje sutartyje negalima mažinti žemiau 50 %\. Atmesta\./)).toBeTruthy();
    expect((main().getByRole('button', { name: 'Išsaugoti' }) as HTMLButtonElement).disabled).toBe(true);
    await fireEvent.change(main().getByLabelText('Šaltinis'), { target: { value: 'local' } });
    await fireEvent.input(main().getByLabelText('Sutarta dalis, proc.'), { target: { value: '80' } });
    expect(main().getByText('Vietiniu aktu mažinti galima nuo 7 dienų komandiruotės. Taikoma 100 %.')).toBeTruthy();
    await fireEvent.click(main().getByLabelText('Raštu supažindintas iki išvykimo'));
    expect(main().getByText('Nėra rašytinio supažindinimo iki išvykimo. Taikoma 100 %.')).toBeTruthy();
    expect((main().getByRole('button', { name: 'Išsaugoti' }) as HTMLButtonElement).disabled).toBe(false);
  });
  it('a second month fills the allowed two; the add button locks', async () => {
    await setRates();
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    setSheet(ui.session!, octMonth({ 5: 'LV' }));
    await ui.after();
    ui.step = 2;
    render(App);
    expect(main().getByText('2026 spalis')).toBeTruthy();
    expect((main().getByRole('button', { name: 'Pridėti mėnesį' }) as HTMLButtonElement).disabled).toBe(true);
  });
});

describe('step 3 and 4: checks and result', () => {
  it('checks list the open questions and missing rates, each with a way to fix it', async () => {
    await setRates({ ...RATES, rows: RATES.rows.filter((r) => r.place !== 'SE') });
    await ui.loadFile(fixture, 'timesheet-2026-09.xlsx');
    for (const t of ui.trips.filter((x) => ui.needs(x))) {
      ui.openTrip(t.trip.id);
      ui.saveTrip(true);
    }
    ui.step = 3;
    render(App);
    expect(main().getAllByText(/^Neišspręstas klausimas \d: nepasirinkta$/)).toHaveLength(4);
    expect(main().getAllByText(/^Nėra tarifo: Švedija, /).length).toBeGreaterThan(0);
    expect((main().getByRole('button', { name: 'Skaičiuoti' }) as HTMLButtonElement).disabled).toBe(true);
    await click(/Taisyti nustatymus/, within(main().getAllByText(/^Neišspręstas klausimas 1/)[0]!.parentElement!));
    expect(main().getByRole('heading', { name: 'Taisyklių paketai' })).toBeTruthy();
  });
  it('result: total, details, reasons, exports, history, print, modal with saved rates', async () => {
    await finish();
    const excluded = ui.trips.filter((x) => x.result.status === 'excluded').length;
    await ui.go(3);
    ui.step = 3;
    render(App);
    expect(main().getByText('Viskas nustatyta.')).toBeTruthy();
    await click('Skaičiuoti');
    expect(screen.getByLabelText('Bendra suma').textContent).toBe(eur(80800));
    expect(main().getByText(`${excluded} komandiruotė(s) pažymėta nebaigta ir į sumą neįtraukta.`)).toBeTruthy();
    expect(main().getByText(/Po paskutinio pakeitimo perskaičiuota:/)).toBeTruthy();
    expect(main().getByText('(4)')).toBeTruthy();
    expect(main().queryByText('visa diena')).toBeNull();
    await click('Išplėsti');
    expect(main().getByText('Suskleisti')).toBeTruthy();
    expect(main().getAllByText('visa diena').length).toBeGreaterThan(0);
    const d = main().getAllByText('Dienų skaičiavimas')[0]!.closest('details')!;
    expect(d.open).toBe(false);
    await click('Dienų detalės');
    expect(d.open).toBe(true);
    await click('CSV');
    expect(vi.mocked(saveBytes).mock.calls[0]![0]).toBe('dienpinigiai-2026-09.csv');
    expect(String(vi.mocked(saveBytes).mock.calls[0]![1])).toContain('total_eur;808');
    await click('XLSX');
    expect(vi.mocked(saveBytes).mock.calls[1]![0]).toBe('dienpinigiai-2026-09.xlsx');
    window.print = vi.fn();
    await click('Spausdinti');
    expect(window.print).toHaveBeenCalled();
    const log = ui.session!.history.map((h) => h.x);
    expect(
      log.some((x) => /^Skaičiavimas: Standartinis v3, tarifų hash [0-9a-f]{8}, komandiruočių: \d+$/.test(x)),
    ).toBe(true);
    expect(log.some((x) => x.startsWith('CSV eksportuotas'))).toBe(true);
    await click('Išsaugoti tarifai');
    expect(screen.getByRole('dialog').textContent).toContain('Vokietija');
    await fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Uždaryti' }));
    expect(screen.queryByRole('dialog')).toBeNull();
  });
  it('result day table: share and reason, October short day and reduction', async () => {
    await setRates();
    const days = octMonth({ 5: 'LV', 6: 'LV', 7: 'LV' });
    days.employees[0]!.days[4]!.min = 180;
    setSheet(ui.session!, days);
    ui.editPack('LT-526');
    edit<'p'>().o.sw = [1, 1, 1, 1];
    await ui.commitEdit();
    ui.session!.preset = 1;
    const { ensureInputs } = await import('../core/api');
    ensureInputs(ui.session!);
    await ui.after();
    ui.step = 4;
    ui.det = true;
    render(App);
    expect(main().getByText('pirma diena trumpesnė nei 4 val. (20 %), sumažinta 50 %')).toBeTruthy();
    expect(main().getAllByText('visa diena, sumažinta 50 %')).toHaveLength(2);
    expect(main().getByText('10 %')).toBeTruthy();
    expect(screen.getByLabelText('Bendra suma').textContent).toBe(eur(440 + 2200 + 2200));
  });
  it('result: no payable trips shows a warning; with payable trips it is absent', async () => {
    await finish();
    ui.step = 4;
    const { unmount } = render(App);
    expect(ui.total).toBeGreaterThan(0);
    expect(screen.queryByText(/Nėra apskaičiuotų komandiruočių/)).toBeNull();
    unmount();
    for (const t of [...ui.trips]) {
      ui.openTrip(t.trip.id);
      ui.saveTrip(true);
    }
    render(App);
    expect(await screen.findByText(/Nėra apskaičiuotų komandiruočių/)).toBeTruthy();
    expect(ui.total).toBe(0);
  });
});

describe('rule packs', () => {
  it('answers and legal limits are saved as a new version; the old one stays; undo restores it', async () => {
    await finish().catch(() => {});
    ui.tab = 1;
    render(App);
    expect(main().getByText('aktyvus')).toBeTruthy();
    await click('Redaguoti');
    const q = (i: number) => main().getByLabelText(new RegExp(`^Klausimas ${i}$`));
    await fireEvent.change(q(1), { target: { value: '2' } });
    await fireEvent.input(main().getByLabelText('Žemiausia dalis pagal kolektyvinę sutartį, proc.'), {
      target: { value: '45' },
    });
    await fireEvent.input(main().getByLabelText('Pavadinimas'), { target: { value: 'Mano paketas' } });
    await click('Tikrinti ir išsaugoti');
    await waitFor(() =>
      expect(screen.getByRole('status').textContent).toBe('Išsaugota kaip v4, ankstesnė versija palikta'),
    );
    expect(main().getByText('v4')).toBeTruthy();
    expect(ui.pack.switches.dailyReturnIsOneTrip).toBe(false);
    expect(ui.pack.params.caMinBp).toBe(4500);
    expect(ui.session!.packs.filter((p) => p.id === 'LT-526').map((p) => p.version)).toEqual([1, 2, 3, 4]);
    expect(ui.session!.history[0]!.x).toBe('Paketas „Mano paketas“ v3 → v4');
    await ui.undo(ui.session!.history[0]!);
    expect([ui.pack.version, ui.pack.label, ui.pack.params.caMinBp]).toEqual([5, 'Standartinis', 5000]);
  });
  it('validation: empty name, limits outside 0-100', async () => {
    ui.tab = 1;
    render(App);
    await click('Redaguoti');
    await fireEvent.input(main().getByLabelText('Pavadinimas'), { target: { value: ' ' } });
    await click('Tikrinti ir išsaugoti');
    expect(await main().findByText('Įrašykite paketo pavadinimą.')).toBeTruthy();
    await fireEvent.input(main().getByLabelText('Pavadinimas'), { target: { value: 'X' } });
    await fireEvent.input(main().getByLabelText('Trumpos dienos dalis, proc.'), { target: { value: '150' } });
    await click('Tikrinti ir išsaugoti');
    expect(await main().findByText(/Teisinės ribos už leistino intervalo/)).toBeTruthy();
    expect(ui.session!.packs.filter((p) => p.id === 'LT-526')).toHaveLength(2);
  });
  it('new, duplicate, activate, export and import', async () => {
    ui.tab = 1;
    render(App);
    await click('Naujas');
    await waitFor(() => expect(main().getByText('Redaguojama: Naujas paketas')).toBeTruthy());
    expect(ui.packs.map((p) => p.label).sort()).toEqual(['Naujas paketas', 'Standartinis']);
    await click('Dubliuoti');
    await waitFor(() => expect(main().getByText('Redaguojama: Naujas paketas (kopija)')).toBeTruthy());
    const mine = ui.packs.find((p) => p.label === 'Naujas paketas')!;
    await click('Padaryti aktyvų', within(main().getByText('Naujas paketas', { selector: 'span' }).parentElement!));
    expect(ui.session!.activePack).toBe(mine.id);
    expect(ui.session!.history[0]!.x).toMatch(/^Aktyvus paketas: Standartinis v2 → Naujas paketas v2$/);
    await click('Eksportuoti failą');
    const [name, body] = vi.mocked(saveBytes).mock.calls[0]!;
    expect(String(name)).toMatch(/^paketas-pk-/);
    expect(JSON.parse(String(body))).toHaveLength(2); // the whole dated series
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'p.json', bytes: new TextEncoder().encode(String(body)) });
    await click('Importuoti failą');
    await waitFor(() => expect(ui.packs).toHaveLength(4));
    await waitFor(() => expect(ui.busy).toBe(''));
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'bad.json', bytes: new TextEncoder().encode('{"nope":1}') });
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'bad.json', bytes: new TextEncoder().encode('{"nope":1}') });
    await click('Importuoti failą');
    await waitFor(() => expect(screen.getByRole('alert').textContent).toMatch(/Nepavyko importuoti/));
    expect(ui.packs).toHaveLength(4);
    expect(ui.session!.history[0]!.x).toBe('Importuota: p.json');
  });
  it('HINT covers exactly SWITCH_KEYS', () => expect(Object.keys(HINT).sort()).toEqual([...SWITCH_KEYS].sort()));
});

describe('profiles', () => {
  it('column mapping is edited, validated and saved as a new version', async () => {
    ui.tab = 2;
    render(App);
    expect(main().getByText('v1')).toBeTruthy();
    await click('Susieti stulpelius');
    const f = (l: string) => main().getByLabelText(l);
    expect((f('Pirmos dienos stulpelis') as HTMLInputElement).value).toBe('AC');
    expect((f('Metų langelis (pvz. T11)') as HTMLInputElement).value).toBe('T11');
    await fireEvent.input(f('Pirmos dienos stulpelis'), { target: { value: 'A1' } });
    await click('Tikrinti ir išsaugoti');
    expect(await main().findByText(/Stulpelius nurodykite raidėmis/)).toBeTruthy();
    await fireEvent.input(f('Pirmos dienos stulpelis'), { target: { value: 'AE' } });
    await fireEvent.input(f('Žingsnis tarp dienų stulpelių'), { target: { value: '0' } });
    await click('Tikrinti ir išsaugoti');
    expect(await main().findByText(/Eilučių ir žingsnio laukai/)).toBeTruthy();
    await fireEvent.input(f('Žingsnis tarp dienų stulpelių'), { target: { value: '2' } });
    await fireEvent.input(f('Metų langelis (pvz. T11)'), { target: { value: 'ZZZZ' } });
    await click('Tikrinti ir išsaugoti');
    expect(await main().findByText(/Metų ir mėnesio langelius nurodykite/)).toBeTruthy();
    await fireEvent.input(f('Metų langelis (pvz. T11)'), { target: { value: 't11' } });
    await fireEvent.input(f('Kodai, kurie praleidžiami valandų eilutėje'), { target: { value: 's; p, l' } });
    await click('Tikrinti ir išsaugoti');
    await waitFor(() =>
      expect(screen.getByRole('status').textContent).toBe('Išsaugota kaip v2, ankstesnė versija palikta'),
    );
    expect([ui.profile.version, ui.profile.firstDayCol, ui.profile.ignore, ui.profile.yearCell]).toEqual([
      2,
      30,
      ['S', 'P', 'L'],
      [10, 19],
    ]);
    expect(await ui.repo.profiles()).toHaveLength(2);
    expect(ui.session!.history[0]!.x).toBe('Profilis „Standartinis žiniaraštis“ v1 → v2');
  });
  it('new, duplicate, export, import (a profile is a plain JSON file)', async () => {
    ui.tab = 2;
    render(App);
    await click('Naujas');
    await waitFor(() => expect(main().getByText('Redaguojama: Naujas profilis')).toBeTruthy());
    await click('Dubliuoti');
    await waitFor(() => expect(main().getByText('Redaguojama: Naujas profilis (kopija)')).toBeTruthy());
    expect(ui.profs).toHaveLength(3);
    await waitFor(() => expect(ui.busy).toBe(''));
    await click('Eksportuoti failą');
    const body = String(vi.mocked(saveBytes).mock.calls[0]![1]);
    expect(JSON.parse(body)[0].label).toBe('Naujas profilis (kopija)');
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'f.json', bytes: new TextEncoder().encode(body) });
    await click('Importuoti failą');
    await waitFor(() => expect(ui.profs).toHaveLength(4));
  });
  it('a custom profile drives the import', async () => {
    ui.profiles = [...ui.profiles, SIMPLE_PROFILE];
    ui.step = 1;
    render(App);
    await fireEvent.change(main().getByLabelText('Importo profilis'), { target: { value: 'simple' } });
    expect(ui.session!.profileId).toBe('simple');
  });
  it('profiles: empty list shows a hint', async () => {
    ui.profiles = [];
    ui.tab = 2;
    render(App);
    expect(await screen.findByText(/Profilių nėra/)).toBeTruthy();
  });
});

describe('rates', () => {
  it('add a row by country name, save: rates, hash and history change, previous list kept', async () => {
    ui.tab = 3;
    ui.openRates();
    render(App);
    const h0 = ui.stamp;
    await click('Pridėti eilutę');
    await fireEvent.input(main().getByLabelText('Valstybė'), { target: { value: 'vokietija / Berlin' } });
    await fireEvent.input(main().getByLabelText('EUR per dieną'), { target: { value: '70' } });
    await fireEvent.input(main().getByLabelText('Galioja nuo'), { target: { value: '2026-01-01' } });
    await fireEvent.input(main().getByLabelText('Tarifų lentelės nuoroda'), {
      target: { value: 'https://example.test/t' },
    });
    await click('Tikrinti ir išsaugoti');
    await waitFor(() =>
      expect(ui.session!.rates.rows).toEqual([{ place: 'DE/Berlin', cents: 7000, validFrom: '2026-01-01' }]),
    );
    await waitFor(() => expect(ui.session!.history[0]!.x).toMatch(/^Tarifai atnaujinti/));
    expect(ui.stamp).not.toBe(h0);
    expect((main().getByLabelText('Valstybė') as HTMLInputElement).value).toBe('Vokietija / Berlin');
    expect(ui.session!.history[0]!.x).toBe(`Tarifai atnaujinti: hash ${h0} → ${ui.stamp}`);
    await ui.repo.saveRates({ ...ui.session!.rates, rows: [] });
    expect(await (ui.repo.s as MemoryStore).list('rates-history')).toHaveLength(1);
    await click('Atidaryti nuorodą');
    expect(openExternal).toHaveBeenCalledWith('https://example.test/t');
  });
  it('validation: unknown country, zero rate, no date, bad address, duplicate', async () => {
    await setRates();
    ui.tab = 3;
    ui.openRates();
    render(App);
    const row = (c: string, e: number, f: string) => Object.assign(ui.rd!.r[0]!, { c, e, f });
    const save = async () => {
      await click('Tikrinti ir išsaugoti');
      await tick();
      return ui.rd!.err;
    };
    row('Atlantida', 10, '2026-01-01');
    expect(await save()).toBe('1 eilutė: nežinoma valstybė „Atlantida“.');
    row('Latvija', 0, '2026-01-01');
    expect(await save()).toBe('1 eilutė: tarifas turi būti didesnis už 0.');
    row('Latvija', 44, '');
    expect(await save()).toBe('1 eilutė: nurodykite galiojimo datą.');
    row('Latvija', 44, '2000-01-01');
    ui.rd!.u = 'ftp://x';
    expect(await save()).toBe('Tarifų lentelės nuoroda turi prasidėti http:// arba https://');
    ui.rd!.u = 'https://ok.test';
    ui.addRateRow();
    Object.assign(ui.rd!.r[ui.rd!.r.length - 1]!, { c: 'LV', e: 50, f: '2000-01-01' });
    expect(await save()).toBe('Pasikartojanti norma: LV 2000-01-01.');
    expect(ui.session!.rates.rows).toHaveLength(5);
  });
  it('import merges rows into the draft (not saved yet); export writes an xlsx', async () => {
    await setRates();
    ui.tab = 3;
    ui.openRates();
    render(App);
    vi.mocked(openBytes).mockResolvedValueOnce({
      name: 'r.xlsx',
      bytes: xlsx([
        ['place', 'eur', 'from'],
        ['LV', 46, '2000-01-01'],
        ['PL', 50, '2026-01-01'],
      ]),
    });
    await click('Importuoti');
    await waitFor(() => expect(ui.rd!.r.length).toBe(6));
    expect(ui.rd!.r.find((r) => r.c === 'Latvija')!.e).toBe(46); // same country + date: replaced
    expect(ui.session!.rates.rows).toHaveLength(5); // the saved list is untouched until "save"
    vi.mocked(openBytes).mockResolvedValueOnce({ name: 'bad.xlsx', bytes: xlsx([['Germany', 1, '2026-01-01']]) });
    await click('Importuoti');
    await waitFor(() => expect(ui.rd!.err).toMatch(/šalies kodas/));
    await click('Eksportuoti');
    expect(vi.mocked(saveBytes).mock.calls[0]![0]).toBe('tarifai.xlsx');
  });
  it('rates: empty list shows a hint', async () => {
    ui.tab = 3;
    ui.openRates();
    ui.rd!.r.splice(0);
    render(App);
    expect(await screen.findByText(/Tarifų nėra/)).toBeTruthy();
  });
});

describe('history', () => {
  it('newest first, filters, undo restores the sum and is itself an entry', async () => {
    await finish();
    const x = ui.trips.find((y) => y.result.status === 'excluded' && y.trip.employee.endsWith('2'))!;
    ui.openTrip(x.trip.id);
    ui.draft!.c = ui.draft!.c.map(() => 'DE');
    const before = ui.total;
    ui.saveTrip(false);
    expect(ui.total).toBeGreaterThan(before);
    ui.tab = 4;
    render(App);
    const all = main().getAllByRole('listitem').length;
    expect(all).toBe(ui.session!.history.length);
    await fireEvent.change(main().getByLabelText('Filtras'), { target: { value: 'calc' } });
    expect(main().queryAllByRole('listitem')).toHaveLength(0);
    expect(main().getByText(/Veiksmų dar nėra/)).toBeTruthy();
    await fireEvent.change(main().getByLabelText('Filtras'), { target: { value: 'chg' } });
    expect(main().getAllByRole('listitem').length).toBeGreaterThan(1);
    await fireEvent.change(main().getByLabelText('Filtras'), { target: { value: 'all' } });
    const trip = ui.session!.history.find((h) => h.k === 'trip' && h.undo && h.a === before)!;
    const li = main().getByText(trip.x).closest('li')!;
    await click('Atšaukti pakeitimą', within(li));
    await waitFor(() => expect(main().getByText('atšaukta')).toBeTruthy());
    expect(ui.total).toBe(before);
    expect(main().getByText(`Atšaukta: ${trip.x}`)).toBeTruthy();
    await waitFor(() => expect(screen.getByRole('status').textContent).toBe('Pakeitimas atšauktas'));
    expect(main().getAllByText(/\(\+|\(−/).length).toBeGreaterThan(0); // amount deltas are shown
  });
});

describe('sessions', () => {
  it('save writes a .dpsesija with history, packs and rates; the label changes', async () => {
    await finish();
    ui.step = 4;
    render(App);
    await fireEvent.click(screen.getAllByRole('button', { name: 'Išsaugoti sesiją' })[0]!);
    const [name, body] = vi.mocked(saveBytes).mock.calls[0]!;
    expect(name).toMatch(/^\d{4}-\d{2}-\d{2} \d{2}-\d{2} \(2026-09 xlsx\)\.dpsesija$/);
    const saved = JSON.parse(String(body));
    expect([saved.activePack, saved.history.length > 3, saved.rates.rows.length]).toEqual(['LT-526', true, 5]);
    await waitFor(() =>
      expect(
        screen.getByText(/^Sesija „\d{4}-\d{2}-\d{2} \d{2}-\d{2} \(2026-09 xlsx\)\.dpsesija“ · išsaugota, tarifų hash/),
      ).toBeTruthy(),
    );
  });
  it('save with nothing loaded says so', async () => {
    render(App);
    await fireEvent.click(screen.getByRole('button', { name: 'Išsaugoti sesiją' }));
    expect(screen.getByRole('status').textContent).toBe('Nėra ką saugoti');
  });
  it('open: keep the saved results or recalculate with the current rates', async () => {
    await finish();
    await ui.saveSession();
    const body = String(vi.mocked(saveBytes).mock.calls[0]![1]);
    const saved = ui.total;
    const raised = { ...RATES, rows: RATES.rows.map((r) => (r.place === 'SE' ? { ...r, cents: 6000 } : r)) };
    await setRates(raised); // rates changed after saving
    vi.mocked(openBytes).mockResolvedValue({ name: '2026-09.dpsesija', bytes: new TextEncoder().encode(body) });
    render(App);
    await fireEvent.click(screen.getByRole('button', { name: 'Atidaryti sesiją' }));
    await waitFor(() => expect(screen.getByRole('dialog')).toBeTruthy());
    expect(screen.getByRole('dialog').textContent).toMatch(/1\s+mėnuo,\s+\d+\s+komandiruot/);
    await fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Ne, palikti išsaugotą' }));
    await waitFor(() => expect(ui.step).toBe(4));
    expect(ui.total).toBe(saved);
    expect(screen.getByText(/atidaryta, palikta išsaugota/)).toBeTruthy();
    await fireEvent.click(screen.getByRole('button', { name: 'Atidaryti sesiją' }));
    await waitFor(() => expect(screen.getByRole('dialog')).toBeTruthy());
    await fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Taip, perskaičiuoti' }));
    await waitFor(() => expect(ui.total).toBe(saved + 8 * 1000)); // 8 priced Swedish days, +10 EUR each
    await waitFor(() => expect(screen.getByText(/atidaryta, perskaičiuota/)).toBeTruthy());
  });
  it('a broken file is refused with a message', async () => {
    vi.mocked(openBytes).mockResolvedValue({ name: 'x.dpsesija', bytes: new TextEncoder().encode('{"schema":1}') });
    render(App);
    await fireEvent.click(screen.getByRole('button', { name: 'Atidaryti sesiją' }));
    await waitFor(() => expect(ui.err).toMatch(/^Sesijos atidarymas: netinkamas sesijos failas/));
    expect(ui.modal).toBe('');
    expect(ui.opened).toBeFalsy();
  });
  it('run: error goes to ui.err, busy resets, re-entry is blocked', async () => {
    expect(
      await ui.run('X', async () => {
        throw new Error('boom');
      }),
    ).toBeUndefined();
    expect(ui.err).toBe('X: boom');
    expect(ui.busy).toBe('');
    let n = 0;
    const first = ui.run('A', async () => {
      await Promise.resolve();
      n++;
    });
    await ui.run('B', async () => {
      n += 10;
    });
    await first;
    expect(n).toBe(1);
  });
  it('saveSession: write failure goes to ui.err, session is not marked saved', async () => {
    await finish();
    vi.mocked(saveBytes).mockRejectedValueOnce(new Error('disk full'));
    await ui.saveSession();
    expect(ui.err).toBe('Sesijos išsaugojimas: disk full');
    expect(ui.session!.name).not.toMatch(/dpsesija/);
    expect(ui.busy).toBe('');
  });
});
