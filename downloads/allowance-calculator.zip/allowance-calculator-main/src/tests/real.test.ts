/// <reference types="node" />
import { readFileSync } from 'node:fs';
import { describe, it, expect } from 'vitest';
import { calcAll, detectTrips, type Ctx } from '../core/engine';
import { periodOf, parseSheet, readAoa } from '../core/import';
import type { ParsedSheet, SheetDay, TripInput } from '../core/schema';
import { addDays, daysIn } from '../core/util';
import { DEFAULT_POLICY, DEFAULT_PROFILE, STATUTORY } from '../rules/defaults';

const rates = (rows: [string, number][]) => ({
  schema: 1 as const,
  sourceUrl: '',
  rows: rows.map(([place, cents]) => ({ place, cents, validFrom: '2000-01-01' })),
});
const answered = STATUTORY.map((p) => ({
  ...p,
  switches: {
    dailyReturnIsOneTrip: true,
    shortRuleOnOneDayAbroad: true,
    ltLongerThanWorkdayIsMultiDay: true,
    shortRuleOnReducedRate: true,
  },
}));
const ctx = (r: ReturnType<typeof rates>): Ctx => ({ rates: r, packs: answered, policies: [DEFAULT_POLICY] });

describe('real timesheet (Nutarimas Nr. 78 form, 2026-09, anonymized)', () => {
  const aoa = readAoa(
    new Uint8Array(readFileSync(new URL('./fixtures/timesheet-2026-09.xlsx', import.meta.url))),
    DEFAULT_PROFILE,
  );
  const sheet = parseSheet(aoa, DEFAULT_PROFILE, '2026-09');

  it('period comes from the title cells', () => expect(periodOf(aoa, DEFAULT_PROFILE)).toBe('2026-09'));
  it('7 employees, no footer rows, no issues', () => {
    expect(sheet.issues).toEqual([]);
    expect(sheet.employees.map((e) => e.name)).toEqual(
      ['', '2', '3', '4', '5', '6', '7'].map((n) => `Vardas Pavardenis${n}`),
    );
    expect(sheet.employees.every((e) => e.days.length === 30)).toBe(true);
  });
  it('K days, hours ("8,57", "5,49/0,57", codes), per-day country', () => {
    expect(sheet.employees.map((e) => e.days.filter((d) => d.k).length)).toEqual([26, 26, 25, 26, 24, 23, 0]);
    const d = sheet.employees[0]!.days;
    expect([d[0]!.min, d[1]!.min, d[5]!.min]).toEqual([514, 329, null]); // 8.57h, 5.49h (night part ignored), "P"
    expect(d.slice(0, 5).map((x) => x.place)).toEqual(['LT', 'LT', 'EE', 'EE', 'EE']);
    expect(d[25]).toEqual({ d: '2026-09-26', min: 191, k: true }); // K without a country
    expect(sheet.employees[1]!.days.every((x) => x.place === undefined)).toBe(true); // other employees: no country row
  });
  it('trips; employee 1 priced from the sheet, the rest blocked for lack of a country', () => {
    expect(
      detectTrips(sheet.employees[0]!).trips.map((t) => `${t.days[0]!.d.slice(8)}-${t.days.at(-1)!.d.slice(8)}`),
    ).toEqual(['01-05', '07-11', '13-18', '20-26', '28-30']);
    const [m] = calcAll(
      [sheet],
      {},
      ctx(
        rates([
          ['LT', 2800],
          ['LV', 4400],
          ['EE', 4000],
          ['SE', 5000],
        ]),
      ),
    );
    const e1 = m!.employees[0]!;
    expect(e1.trips.map((t) => [t.status, t.cents])).toEqual([
      ['ok', 17600],
      ['ok', 25000],
      ['ok', 23200],
      ['blocked', 0], // 26 Sep: K but no country
      ['ok', 15000],
    ]);
    expect(e1.trips[3]!.issues.map((i) => [i.code, i.params.date])).toEqual([['NO_PLACE', '2026-09-26']]);
    expect(m!.employees.slice(1).every((e) => e.trips.every((t) => t.status === 'blocked'))).toBe(true);
    expect(m!.cents).toBe(80800);
  });
  it('trip-input legs fill in for employees without a country row', () => {
    const t = detectTrips(sheet.employees[1]!).trips[0]!;
    const inp: TripInput = {
      employee: t.employee,
      start: t.days[0]!.d,
      legs: [{ place: 'DE', from: t.days[0]!.d }],
      reduction: null,
      notified: false,
      dailyReturn: false,
    };
    const [m] = calcAll([sheet], { [t.id]: inp }, ctx(rates([['DE', 6200]])));
    expect(m!.employees[1]!.trips[0]!.cents).toBe(6200 * t.days.length);
  });
});

describe('trips across a month boundary', () => {
  const month = (period: string, ks: number[], min: Record<number, number> = {}, place = 'LV'): ParsedSheet => ({
    period,
    issues: [],
    employees: [
      {
        name: 'A',
        days: Array.from({ length: daysIn(period) }, (_, i): SheetDay => {
          const k = ks.includes(i + 1);
          return {
            d: `${period}-${String(i + 1).padStart(2, '0')}`,
            min: min[i + 1] ?? 480,
            k,
            ...(k ? { place } : {}),
          };
        }),
      },
    ],
  });
  const c = ctx(rates([['LV', 4400]]));
  const sep = month('2026-09', [29, 30]);
  const oct = month('2026-10', [1, 2], { 2: 180 });

  it('one trip, amounts attributed per month, rules per day (old pack in Sep, new in Oct)', () => {
    const [a, b] = calcAll([oct, sep], {}, c); // order of input does not matter
    expect([a!.period, b!.period]).toEqual(['2026-09', '2026-10']);
    expect([a!.cents, b!.cents]).toEqual([8800, 4400 + 880]); // Oct 2: 3h last day = 20%
    const [ta] = a!.employees[0]!.trips,
      [tb] = b!.employees[0]!.trips;
    expect([ta!.id, tb!.id]).toEqual(['A|2026-09-29', 'A|2026-09-29']);
    expect([ta!.fromPrev, ta!.intoNext, tb!.fromPrev, tb!.intoNext]).toEqual([false, true, true, false]);
    expect(a!.issues.concat(b!.issues)).toEqual([]);
  });
  it('the whole trip length counts for the 7-day rule (local act 65%)', () => {
    const s2 = month('2026-09', [27, 28, 29, 30]),
      o2 = month('2026-10', [1, 2, 3, 4]);
    const inp: TripInput = {
      employee: 'A',
      start: '2026-09-27',
      legs: [],
      reduction: { source: 'local', bp: 6500 },
      notified: true,
      dailyReturn: false,
    };
    const [a, b] = calcAll([s2, o2], { 'A|2026-09-27': inp }, c);
    expect([a!.cents, b!.cents]).toEqual([4 * 2860, 4 * 2860]); // 8 days >= 7: reduction applies in both months
    const [only] = calcAll([o2], { 'A|2026-10-01': { ...inp, start: '2026-10-01' } }, c);
    expect(only!.cents).toBe(4 * 4400); // 4 days alone: forced to 100%
  });
  it('edge warning only when the neighbouring month is not loaded', () => {
    const [only] = calcAll([sep], {}, c);
    expect(only!.issues.map((i) => [i.code, i.params.edge, i.params.date])).toEqual([
      ['MONTH_EDGE_TRIP', 'end', '2026-09-30'],
    ]);
    const [, b] = calcAll([sep, oct], {}, c);
    expect(b!.issues).toEqual([]);
  });
  it('a missing month in between breaks the trip', () => {
    const nov = month('2026-11', [1]);
    const res = calcAll([sep, nov], {}, c);
    expect(res.map((m) => m.employees[0]!.trips.length)).toEqual([1, 1]);
    expect(res[0]!.employees[0]!.trips[0]!.end).toBe('2026-09-30');
    expect(addDays('2026-09-30', 1)).toBe('2026-10-01');
  });
});
