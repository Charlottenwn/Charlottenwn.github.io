import { fileURLToPath } from 'node:url';
import { describe, it, expect } from 'vitest';
import { calcAll, type MonthResult } from '../core/engine';
import type { ParsedSheet, TripInput } from '../core/schema';
import { gate, load, type Base } from './golden-gate';

type Fx = Base & { sheets: ParsedSheet[]; inputs: Record<string, TripInput>; expected: unknown };
const dir = fileURLToPath(new URL('./golden/all/', import.meta.url));

const proj = (m: MonthResult) => ({
  period: m.period,
  cents: m.cents,
  blocked: m.blocked,
  excluded: m.excluded,
  issues: m.issues,
  employees: m.employees.map((e) => ({
    employee: e.employee,
    cents: e.cents,
    trips: e.trips.map((t) => ({
      id: t.id,
      status: t.status,
      cents: t.cents,
      fromPrev: t.fromPrev,
      intoNext: t.intoNext,
      issues: t.issues,
      lines: t.lines.map((l) => ({ d: l.d, cents: l.cents, pack: l.pack })),
    })),
  })),
});

describe('golden calcAll', () => {
  for (const { p, fx } of load<Fx>(dir)) {
    it(fx.id, async () => {
      const { packs, policy } = await gate(fx, p);
      const r = calcAll(fx.sheets, fx.inputs, { rates: fx.rates, packs, policies: [policy] });
      expect(r.map(proj)).toEqual(fx.expected);
    });
  }
});
