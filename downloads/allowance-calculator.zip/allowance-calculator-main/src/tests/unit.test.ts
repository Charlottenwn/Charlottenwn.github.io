import { describe, it, expect } from 'vitest';
import { addDays, daysIn, mulDiv, stable } from '../core/util';
import { dayPlaces, detectTrips, rateFor } from '../core/engine';
import { parseSheet } from '../core/import';
import { SIMPLE_PROFILE } from '../rules/defaults';
import pkg from '../../package.json';
import tauri from '../../src-tauri/tauri.conf.json';
import { APP } from '../core/api';
import { readFileSync } from 'fs';

describe('util', () => {
  it('mulDiv rounds half up', () => {
    expect([mulDiv(1, 2), mulDiv(5, 10), mulDiv(4, 10), mulDiv(15, 10), mulDiv(14, 10)]).toEqual([1, 1, 0, 2, 1]);
  });
  it('addDays crosses month, year, leap day', () => {
    expect(addDays('2026-10-31', 1)).toBe('2026-11-01');
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01');
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29');
  });
  it('daysIn', () => {
    expect([daysIn('2026-02'), daysIn('2028-02'), daysIn('2026-10')]).toEqual([28, 29, 31]);
  });
  it('stable is key-order independent', () => {
    expect(stable({ b: 1, a: { d: 1, c: 2 } })).toBe(stable({ a: { c: 2, d: 1 }, b: 1 }));
  });
});

describe('rateFor', () => {
  const r = {
    schema: 1 as const,
    sourceUrl: '',
    rows: [
      { place: 'DE', cents: 6000, validFrom: '2020-01-01' },
      { place: 'DE', cents: 6200, validFrom: '2026-01-01' },
      { place: 'DE/Berlin', cents: 7000, validFrom: '2026-01-01' },
    ],
  };
  it('picks validFrom, city, country fallback, misses', () => {
    expect(rateFor(r, 'DE', '2025-12-31')).toBe(6000);
    expect(rateFor(r, 'DE', '2026-01-01')).toBe(6200);
    expect(rateFor(r, 'DE/Berlin', '2026-05-01')).toBe(7000);
    expect(rateFor(r, 'DE/Munich', '2026-05-01')).toBe(6200);
    expect(rateFor(r, 'DE', '2019-01-01')).toBeUndefined();
    expect(rateFor(r, 'FR', '2026-01-01')).toBeUndefined();
  });
});

describe('dayPlaces', () => {
  const legs = [
    { place: 'PL', from: '2026-10-12' },
    { place: 'DE', from: '2026-10-15' },
  ];
  it('averages only on the change day', () => {
    expect(dayPlaces(legs, '2026-10-14')).toEqual(['PL']);
    expect(dayPlaces(legs, '2026-10-15')).toEqual(['PL', 'DE']);
    expect(dayPlaces(legs, '2026-10-16')).toEqual(['DE']);
  });
  it('transit leg is excluded unless it is all there is', () => {
    const t = [
      { place: 'PL', from: '2026-10-12' },
      { place: 'CZ', from: '2026-10-15', transit: true },
    ];
    expect(dayPlaces(t, '2026-10-15')).toEqual(['PL']);
    expect(dayPlaces(t, '2026-10-16')).toEqual(['CZ']);
  });
  it('dedupes same place', () => {
    expect(
      dayPlaces(
        [
          { place: 'DE', from: '2026-10-12' },
          { place: 'DE', from: '2026-10-15' },
        ],
        '2026-10-15',
      ),
    ).toEqual(['DE']);
  });
});

describe('parseSheet (period 2026-02, SIMPLE_PROFILE)', () => {
  const N = 28,
    P = '2026-02';
  const hdr = ['Name', ...Array.from({ length: N }, (_, i) => i + 1)];
  const xl = (name: string, main: Record<number, string | number>, k: Record<number, string>): unknown[][] => [
    [name, ...Array.from({ length: N }, (_, i) => main[i + 1] ?? null)],
    ['', ...Array.from({ length: N }, (_, i) => k[i + 1] ?? null)],
  ];
  const sheet = (...rows: unknown[][][]): unknown[][] => [hdr, ...rows.flat()];
  const codes = (r: ReturnType<typeof parseSheet>) => r.issues.map((i) => i.code);

  it('hours, comma decimals, ignored codes', () => {
    const r = parseSheet(sheet(xl('Jonas', { 3: 8, 4: '3,5', 5: 'S' }, { 3: 'K', 4: 'K', 5: 'K' })), SIMPLE_PROFILE, P);
    const d = r.employees[0]!.days;
    expect(r.issues).toEqual([]);
    expect(d[2]).toEqual({ d: '2026-02-03', min: 480, k: true });
    expect(d[3]!.min).toBe(210);
    expect(d[4]).toEqual({ d: '2026-02-05', min: null, k: true });
    expect(d[5]!.k).toBe(false);
  });
  it('K4 in the K cell overrides hours', () => {
    const r = parseSheet(sheet(xl('Jonas', { 3: 8 }, { 3: 'K4' })), SIMPLE_PROFILE, P);
    expect(r.employees[0]!.days[2]!.min).toBe(240);
  });
  it('bad cell, bad K cell, duplicate employee', () => {
    expect(codes(parseSheet(sheet(xl('J', { 3: 'abc' }, {})), SIMPLE_PROFILE, P))).toContain('BAD_CELL');
    expect(codes(parseSheet(sheet(xl('J', {}, { 3: 'X' })), SIMPLE_PROFILE, P))).toContain('BAD_K_CELL');
    expect(codes(parseSheet(sheet(xl('J', {}, {}), xl('J', {}, {})), SIMPLE_PROFILE, P))).toContain('DUP_EMPLOYEE');
  });
  it('header mismatch aborts with no employees', () => {
    const r = parseSheet(sheet(xl('J', {}, {})), SIMPLE_PROFILE, '2026-03'); // header has 28 days, March needs 31
    expect(r.employees).toEqual([]);
    expect(codes(r)[0]).toBe('HEADER_DAY_MISMATCH');
  });
  it('Excel date serials in the header', () => {
    const h = ['Name', ...Array.from({ length: N }, (_, i) => Date.UTC(2026, 1, i + 1) / 864e5 + 25569)];
    expect(parseSheet([h, ...xl('J', {}, {})], SIMPLE_PROFILE, P).issues).toEqual([]);
  });
});

describe('detectTrips', () => {
  const emp = (p: string) => ({
    name: 'a',
    days: [...p].map((c, i) => ({ d: addDays('2026-10-01', i), min: 480, k: c === 'K' })),
  });
  it('splits on gaps, ids by start date', () => {
    const r = detectTrips(emp('..KKK..K.'));
    expect(r.trips.map((t) => [t.id, t.days.length])).toEqual([
      ['a|2026-10-03', 3],
      ['a|2026-10-08', 1],
    ]);
    expect(r.issues).toEqual([]);
  });
  it('warns on month-edge trips', () => {
    expect(detectTrips(emp('KK...')).issues[0]?.code).toBe('MONTH_EDGE_TRIP');
    expect(detectTrips(emp('.'.repeat(29) + 'KK')).issues[0]?.code).toBe('MONTH_EDGE_TRIP'); // ends on Oct 31
  });
});

describe('footerMatch', () => {
  it('app version matches manifests', () => {
    expect(pkg.version).toBe(APP);
    expect(tauri.version).toBe(APP);
    expect(readFileSync('src-tauri/Cargo.toml', 'utf8')).toMatch(`version = "${APP}"`);
    expect(readFileSync('src-tauri/Cargo.toml', 'utf8')).toMatch(
      new RegExp('^version = "' + APP.replaceAll('.', '\\.') + '"', 'm'),
    );
  });
});
