import { describe, expect, it } from 'vitest';
import {
  addHist,
  allTrips,
  calcSync,
  ensureInputs,
  newSession,
  packsOf,
  previewTrip,
  setInput,
  setSheet,
  totalOf,
  undoHist,
} from '../core/api';
import type { Session, SheetDay } from '../core/schema';
import { Repo } from '../core/repo';
import { MemoryStore } from '../core/storage';
import { DEFAULT_PROFILE, PRESETS, SIMPLE_PROFILE, STATUTORY } from '../rules/defaults';

const RATES = {
  schema: 1 as const,
  sourceUrl: 'https://example.test/r',
  rows: [
    ['DE', 6200],
    ['LV', 4400],
    ['LT', 2800],
  ].map(([place, cents]) => ({ place: place as string, cents: cents as number, validFrom: '2000-01-01' })),
};
const month = (period: string, trips: Record<number, string>, min: Record<number, number> = {}) => ({
  period,
  issues: [],
  employees: [
    {
      name: 'A',
      days: Array.from({ length: 30 }, (_, i): SheetDay => {
        const place = trips[i + 1];
        return {
          d: `${period}-${String(i + 1).padStart(2, '0')}`,
          min: min[i + 1] ?? 480,
          k: !!place,
          ...(place ? { place } : {}),
        };
      }),
    },
  ],
});
async function setup() {
  const repo = new Repo(new MemoryStore());
  await repo.saveRates(RATES);
  const s = await newSession(repo, 't');
  return { repo, s };
}

describe('session defaults and active pack', () => {
  it('new session: LT-526 active, no history, preset none', async () => {
    const { s } = await setup();
    expect([s.activePack, s.preset, s.history, s.profileId]).toEqual(['LT-526', 0, [], 'default']);
    expect(packsOf(s).map((p) => p.version)).toEqual([1, 2]);
  });
  it('another family is used as a whole series, the others are ignored', async () => {
    const { repo, s } = await setup();
    for (const p of STATUTORY)
      await repo.savePack({ ...p, id: 'mine', label: 'Mano', params: { ...p.params, caMinBp: 4000 } });
    s.packs = await repo.packs();
    s.activePack = 'mine';
    expect(packsOf(s).every((p) => p.id === 'mine')).toBe(true);
    s.activePack = 'does-not-exist';
    expect(packsOf(s).length).toBe(s.packs.length); // unknown id: fall back to all
  });
});

describe('saveMany', () => {
  const p = STATUTORY[0]!;
  it('invalid later version writes nothing', async () => {
    const s = new MemoryStore();
    const r = new Repo(s);
    await expect(
      r.saveMany('packs', [{ ...p, id: 'b' }, { ...p, id: 'b', version: 2, params: null } as never]),
    ).rejects.toThrow();
    expect(await s.list('packs')).toEqual([]);
  });
  it('duplicate version in one file and existing path are rejected', async () => {
    const s = new MemoryStore();
    const r = new Repo(s);
    await expect(
      r.saveMany('packs', [
        { ...p, id: 'b' },
        { ...p, id: 'b' },
      ]),
    ).rejects.toThrow('DUP_VERSION');
    await r.savePack({ ...p, id: 'b' });
    await expect(
      r.saveMany('packs', [
        { ...p, id: 'b', version: 2 },
        { ...p, id: 'b' },
      ]),
    ).rejects.toThrow(/IMMUTABLE/);
    expect(await s.read('packs/b@2.json')).toBeNull();
    await expect(r.saveMany('packs', [p])).rejects.toThrow('IMMUTABLE builtin');
  });
  it('write failure midway rolls back', async () => {
    const s = new MemoryStore();
    const w = s.write.bind(s);
    let n = 0;
    s.write = async (path, d) => {
      if (++n === 2) throw new Error('disk');
      return w(path, d);
    };
    const r = new Repo(s);
    await expect(
      r.saveMany('packs', [
        { ...p, id: 'b' },
        { ...p, id: 'b', version: 2 },
      ]),
    ).rejects.toThrow('disk');
    expect(await s.list('packs')).toEqual([]);
  });
  it('profiles: all versions written together', async () => {
    const r = new Repo(new MemoryStore());
    await r.saveMany('profiles', [
      { ...SIMPLE_PROFILE, id: 'x' },
      { ...SIMPLE_PROFILE, id: 'x', version: 2 },
    ]);
    expect((await r.profiles()).filter((q) => q.id === 'x')).toHaveLength(2);
  });
});

describe('trips and automatic inputs', () => {
  it('allTrips are whole trips over months, sorted; ensureInputs applies the preset to new trips only', async () => {
    const { s } = await setup();
    setSheet(s, month('2026-10', { 1: 'LV', 2: 'LV', 10: 'DE' }));
    setSheet(s, month('2026-09', { 29: 'LV', 30: 'LV' }));
    expect(allTrips(s).map((t) => t.trip.id)).toEqual(['A|2026-09-29', 'A|2026-10-10']);
    expect(allTrips(s)[0]!.trip.days.length).toBe(4); // Sep 29 - Oct 2, one trip
    s.preset = 1;
    expect(ensureInputs(s)).toBe(2);
    expect(s.inputs['A|2026-10-10']).toMatchObject({ reduction: { source: 'ca', bp: 5000 }, notified: true });
    s.preset = 2;
    expect(ensureInputs(s)).toBe(0); // existing inputs are not touched
    expect(s.inputs['A|2026-10-10']!.reduction!.bp).toBe(5000);
    expect(PRESETS[2]).toMatchObject({ src: 'local', pct: 80 });
  });
  it('preview prices a not yet saved input, hand edits win over the sheet, hours reach the lines', async () => {
    const { s } = await setup();
    setSheet(s, month('2026-10', { 5: 'LV', 6: 'LV', 7: 'LV' }, { 5: 180 }));
    const t = allTrips(s)[0]!.trip;
    const base = { employee: 'A', start: '2026-10-05', legs: [], reduction: null, notified: true, dailyReturn: false };
    const a = previewTrip(s, t, base);
    expect(a.lines.map((l) => [l.min, l.cents])).toEqual([
      [180, 880],
      [480, 4400],
      [480, 4400],
    ]); // first day < 4 h: 20 %
    const b = previewTrip(s, t, {
      ...base,
      days: { '2026-10-05': { min: 300, place: 'DE' }, '2026-10-06': { place: 'DE' } },
    });
    expect(b.lines.map((l) => [l.places[0], l.cents])).toEqual([
      ['DE', 6200],
      ['DE', 6200],
      ['LV', 4400],
    ]);
  });
  it('incomplete trips are excluded from the sum and counted', async () => {
    const { s } = await setup();
    setSheet(s, month('2026-10', { 5: 'LV', 6: 'LV', 10: 'DE', 11: 'DE' }));
    ensureInputs(s);
    const before = totalOf(s);
    setInput(s, { ...s.inputs['A|2026-10-10']!, incomplete: true });
    const [m] = calcSync(s);
    expect([m!.excluded, m!.blocked, totalOf(s)]).toEqual([1, 0, before - 12400]);
    expect(allTrips(s).find((t) => t.trip.id === 'A|2026-10-10')!.result.issues[0]!.code).toBe('MARKED_INCOMPLETE');
  });
  it('the answers live in the pack: an unresolved one blocks only the trips that need it', async () => {
    const { s } = await setup();
    setSheet(s, month('2026-10', { 5: 'LV', 6: 'LV' }, { 5: 180, 6: 180 }));
    s.preset = 1; // 50 % reduction + short days: the 4th question matters
    ensureInputs(s);
    expect(calcSync(s)[0]!.blocked).toBe(1); // reduced short day needs the 4th answer
    const answered = s.packs.map((p) => ({ ...p, switches: { ...p.switches, shortRuleOnReducedRate: true } }));
    s.packs = answered;
    expect(calcSync(s)[0]!.blocked).toBe(0);
  });
});

describe('history and undo', () => {
  it('addHist numbers entries, newest first', async () => {
    const { s } = await setup();
    addHist(s, 'import', 'a');
    addHist(s, 'calc', 'b', 100, 200);
    expect(s.history.map((h) => [h.id, h.x])).toEqual([
      [2, 'b'],
      [1, 'a'],
    ]);
    expect(s.history[0]).toMatchObject({ a: 100, b: 200, undone: false });
  });
  it('undo a trip edit, the active pack and the preset', async () => {
    const { repo, s } = await setup();
    setSheet(s, month('2026-10', { 5: 'LV', 6: 'LV' }));
    ensureInputs(s);
    const id = 'A|2026-10-05',
      before = structuredClone(s.inputs[id]!);
    const a = totalOf(s);
    setInput(s, { ...before, reduction: { source: 'ca', bp: 5000 } });
    const e = addHist(s, 'trip', 'x', a, totalOf(s), { type: 'trip', id, before });
    expect(totalOf(s)).toBe(4400);
    await undoHist(s, repo, e.id);
    expect([totalOf(s), e.undone, s.history[0]!.x]).toEqual([a, true, 'Atšaukta: x']);
    await undoHist(s, repo, e.id); // second undo of the same entry does nothing
    expect(s.history.length).toBe(2);
    s.activePack = 'x';
    s.preset = 2;
    await undoHist(
      s,
      repo,
      addHist(s, 'rules', 'p', undefined, undefined, { type: 'activePack', before: 'LT-526' }).id,
    );
    await undoHist(s, repo, addHist(s, 'rules', 'q', undefined, undefined, { type: 'preset', before: 0 }).id);
    expect([s.activePack, s.preset]).toEqual(['LT-526', 0]);
    const gone = addHist(s, 'trip', 'new trip', undefined, undefined, { type: 'trip', id, before: null });
    await undoHist(s, repo, gone.id);
    expect(s.inputs[id]).toBeUndefined();
  });
  it('undo a rule-pack save, a profile save and a rates save: stored as new versions / lists', async () => {
    const { repo, s } = await setup();
    const v1 = STATUTORY[1]!;
    await repo.savePack({ ...v1, version: 3, label: 'Nauja' });
    s.packs = await repo.packs();
    await undoHist(s, repo, addHist(s, 'rules', 'pack', undefined, undefined, { type: 'pack', before: v1 }).id);
    expect(s.packs.filter((p) => p.id === 'LT-526').map((p) => [p.version, p.label])).toEqual([
      [1, 'Standartinis'],
      [2, 'Standartinis'],
      [3, 'Nauja'],
      [4, 'Standartinis'],
    ]);
    await repo.saveProfile({ ...DEFAULT_PROFILE, version: 2, label: 'Kitas' });
    await undoHist(
      s,
      repo,
      addHist(s, 'rules', 'prof', undefined, undefined, { type: 'profile', before: DEFAULT_PROFILE }).id,
    );
    expect((await repo.profiles()).filter((p) => p.id === 'default').map((p) => [p.version, p.label])).toEqual([
      [1, 'Standartinis žiniaraštis'],
      [2, 'Kitas'],
      [3, 'Standartinis žiniaraštis'],
    ]);
    const old = s.rates;
    await repo.saveRates({ ...RATES, rows: [] });
    s.rates = { ...RATES, rows: [] };
    await undoHist(s, repo, addHist(s, 'rates', 'r', undefined, undefined, { type: 'rates', before: old }).id);
    expect([(await repo.rates()).rows.length, s.rates.rows.length]).toEqual([3, 3]);
  });
});

describe('repository: versions and history', () => {
  it('profiles are write-once per version; nextVersion counts per id', async () => {
    const { repo } = await setup();
    expect(await repo.nextVersion('profiles', 'default')).toBe(2);
    await repo.saveProfile({ ...DEFAULT_PROFILE, version: 2 });
    await expect(repo.saveProfile({ ...DEFAULT_PROFILE, version: 2 })).rejects.toThrow(/IMMUTABLE/);
    expect(await repo.nextVersion('profiles', 'default')).toBe(3);
    expect(await repo.nextVersion('packs', 'LT-526')).toBe(3);
    expect(await repo.nextVersion('packs', 'other')).toBe(1);
  });
  it('saving rates keeps the previous list in rates-history', async () => {
    const { repo } = await setup(); // first save: nothing to keep
    const store = repo.s as MemoryStore;
    expect(await store.list('rates-history')).toEqual([]);
    await repo.saveRates({ ...RATES, rows: RATES.rows.slice(0, 1) });
    const kept = await store.list('rates-history');
    expect(kept.length).toBe(1);
    expect(JSON.parse((await store.read(`rates-history/${kept[0]}`))!).rows).toHaveLength(3);
  });
  it('a saved session keeps history, active pack and preset', async () => {
    const { repo, s } = await setup();
    s.preset = 1;
    addHist(s, 'rules', 'x', 1, 2);
    await repo.saveSession(s);
    const back = (await repo.loadSession(s.id)) as Session;
    expect([back.preset, back.history.length, back.activePack]).toEqual([1, 1, 'LT-526']);
  });
});
