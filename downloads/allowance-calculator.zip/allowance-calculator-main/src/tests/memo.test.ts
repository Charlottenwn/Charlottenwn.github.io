import { describe, it, expect } from 'vitest';
import { calcTrip, type Ctx, type Trip } from '../core/engine';
import type { TripInput } from '../core/schema';
import { addDays } from '../core/util';
import { DEFAULT_POLICY, STATUTORY } from '../rules/defaults';

const row = (place: string, cents: number) => ({ place, cents, validFrom: '2000-01-01' });
const rates = {
  schema: 1 as const,
  sourceUrl: '',
  rows: [row('LT', 2800), row('DE', 6200), row('LV', 4400), row('PL', 5000)],
}; // fixtures
const answered = STATUTORY.map((p) => ({
  ...p,
  switches: {
    dailyReturnIsOneTrip: true,
    shortRuleOnOneDayAbroad: true,
    ltLongerThanWorkdayIsMultiDay: true,
    shortRuleOnReducedRate: true,
  },
}));
const ctx: Ctx = { rates, packs: answered, policies: [DEFAULT_POLICY] };
const H = 480;
const trip = (e: string, s: string, m: (number | null)[]): Trip => ({
  id: `${e}|${s}`,
  employee: e,
  days: m.map((x, i) => ({ d: addDays(s, i), min: x })),
});
const run = (t: Trip, legs: TripInput['legs'], o: Partial<TripInput> = {}, c = ctx) =>
  calcTrip(
    t,
    { employee: t.employee, start: t.days[0]!.d, legs, reduction: null, notified: false, dailyReturn: false, ...o },
    c,
  );

describe('memo', () => {
  it('DE 05-07 Oct, no CA = 100%', () =>
    expect(run(trip('a', '2026-10-05', [H, H, H]), [{ place: 'DE', from: '2026-10-05' }]).cents).toBe(18600));
  it('PL->DE, CA 50%: notified vs not', () => {
    const t = trip('a', '2026-10-12', Array(10).fill(H));
    const legs = [
      { place: 'PL', from: '2026-10-12' },
      { place: 'DE', from: '2026-10-15' },
    ];
    const reduction = { source: 'ca' as const, bp: 5000 };
    expect(run(t, legs, { reduction, notified: true }).cents).toBe(28900);
    expect(run(t, legs, { reduction, notified: false }).cents).toBe(57800);
  });
  it('Riga 7-9 Oct = 20/100/100', () =>
    expect(run(trip('a', '2026-10-07', [210, H, 270]), [{ place: 'LV', from: '2026-10-07' }]).cents).toBe(9680));
  it('LT one day = 0, Riga one day = 44', () => {
    expect(run(trip('a', '2026-10-01', [H]), [{ place: 'LT', from: '2026-10-01' }]).cents).toBe(0);
    expect(run(trip('a', '2026-10-02', [H]), [{ place: 'LV', from: '2026-10-02' }]).cents).toBe(4400);
  });
});
describe('edges', () => {
  it('old regime LT one day = 28', () =>
    expect(run(trip('a', '2026-09-29', [H]), [{ place: 'LT', from: '2026-09-29' }]).cents).toBe(2800));
  it('local act on <7 day trip forces 100% + warn', () => {
    const r = run(trip('a', '2026-10-05', [H, H, H]), [{ place: 'DE', from: '2026-10-05' }], {
      reduction: { source: 'local', bp: 6500 },
      notified: true,
    });
    expect(r.cents).toBe(18600);
    expect(r.issues.some((i) => i.code === 'LOCAL_ACT_TRIP_TOO_SHORT')).toBe(true);
  });
  it('CA below 50% blocks', () =>
    expect(
      run(trip('a', '2026-10-05', [H, H, H]), [{ place: 'DE', from: '2026-10-05' }], {
        reduction: { source: 'ca', bp: 4000 },
      }).status,
    ).toBe('blocked'));
  it('unresolved switch blocks', () =>
    expect(
      run(trip('a', '2026-10-02', [180]), [{ place: 'LV', from: '2026-10-02' }], {}, { ...ctx, packs: STATUTORY })
        .status,
    ).toBe('blocked'));
});
