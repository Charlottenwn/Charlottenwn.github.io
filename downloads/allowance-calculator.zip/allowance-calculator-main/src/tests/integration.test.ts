import { describe, it, expect } from 'vitest';
import * as XLSX from 'xlsx';
import { active } from '../core/engine';
import { calculate, newSession, setInput, setRates, setSheet, syncSnapshot } from '../core/api';
import { toCsv, toRows, toXlsx } from '../core/export';
import { parseSheet, readAoa, readSheet } from '../core/import';
import { DataError, Repo } from '../core/repo';
import type { RulePack, TripInput } from '../core/schema';
import { MemoryStore, isTauri, makeStore } from '../core/storage';
import { DEFAULT_POLICY, SIMPLE_PROFILE, STATUTORY } from '../rules/defaults';

const N = 31;
const inRange = (d: number) => d >= 5 && d <= 7;
const aoa = (): unknown[][] => [
  ['Name', ...Array.from({ length: N }, (_, i) => i + 1)],
  ['Jonas', ...Array.from({ length: N }, (_, i) => (inRange(i + 1) ? 8 : null))],
  ['', ...Array.from({ length: N }, (_, i) => (inRange(i + 1) ? 'K' : null))],
];
const rates = { schema: 1 as const, sourceUrl: '', rows: [{ place: 'DE', cents: 6200, validFrom: '2000-01-01' }] };
const input: TripInput = {
  employee: 'Jonas',
  start: '2026-10-05',
  legs: [{ place: 'DE', from: '2026-10-05' }],
  reduction: null,
  notified: false,
  dailyReturn: false,
};

async function setup() {
  const store = new MemoryStore(),
    repo = new Repo(store);
  await repo.saveRates(rates);
  const s = await newSession(repo, 'test');
  setSheet(s, parseSheet(aoa(), SIMPLE_PROFILE, '2026-10'));
  setInput(s, input);
  return { store, repo, s };
}

describe('repo', () => {
  it('rates: empty default, then round-trip', async () => {
    const repo = new Repo(new MemoryStore());
    expect((await repo.rates()).rows).toEqual([]);
    await repo.saveRates(rates);
    expect(await repo.rates()).toEqual(rates);
  });
  it('schema-invalid file -> DataError', async () => {
    const store = new MemoryStore();
    await store.write('rates.json', '{"schema":1,"sourceUrl":"","rows":[{"place":"DE","cents":-5,"validFrom":"x"}]}');
    await expect(new Repo(store).rates()).rejects.toBeInstanceOf(DataError);
  });
  it('non-JSON file rejects', async () => {
    const store = new MemoryStore();
    await store.write('rates.json', '{oops');
    await expect(new Repo(store).rates()).rejects.toThrow();
  });
  it('packs are write-once, builtin protected, newest effective version wins', async () => {
    const repo = new Repo(new MemoryStore());
    const next: RulePack = { ...STATUTORY[1]!, version: 3, effectiveFrom: '2027-01-01', label: 'test' };
    await repo.savePack(next);
    await expect(repo.savePack(next)).rejects.toThrow(/IMMUTABLE/);
    await expect(repo.savePack(STATUTORY[1]!)).rejects.toThrow(/IMMUTABLE/);
    const all = await repo.packs();
    expect(all).toHaveLength(3);
    expect(active(all, '2026-12-31')?.version).toBe(2);
    expect(active(all, '2027-02-01')?.version).toBe(3);
  });
  it('policies are write-once; default always present', async () => {
    const repo = new Repo(new MemoryStore());
    const p = { ...DEFAULT_POLICY, id: 'ag', label: 'AG' };
    await repo.savePolicy(p);
    await expect(repo.savePolicy(p)).rejects.toThrow(/IMMUTABLE/);
    expect((await repo.policies()).map((x) => x.id)).toEqual(['default', 'ag']);
  });
  it('profiles: default present, saved one added', async () => {
    const repo = new Repo(new MemoryStore());
    await repo.saveProfile({ ...SIMPLE_PROFILE, id: 'x', label: 'X' });
    expect((await repo.profiles()).map((p) => p.id)).toEqual(['default', 'x']);
  });
});

describe('session', () => {
  it('sessions() lists saved ids', async () => {
    const { repo, s } = await setup();
    await repo.saveSession(s);
    expect(await repo.sessions()).toEqual([`${s.id}.json`]);
  });
  it('save -> reopen in a fresh Repo -> identical calculation', async () => {
    const { store, repo, s } = await setup();
    const before = await calculate(s);
    expect(before.cents).toBe(18600);
    await repo.saveSession(s);
    const back = await new Repo(store).loadSession(s.id);
    expect(await calculate(back!)).toEqual(before);
  });
  it('rates are a snapshot until syncSnapshot', async () => {
    const { repo, s } = await setup();
    const before = await calculate(s);
    await repo.saveRates({ ...rates, rows: [{ ...rates.rows[0]!, cents: 6800 }] });
    expect((await calculate(s)).cents).toBe(18600);
    await syncSnapshot(s, repo);
    const after = await calculate(s);
    expect(after.cents).toBe(20400);
    expect(after.stamp.ratesSha).not.toBe(before.stamp.ratesSha);
    expect(s.audit.map((a) => a.op)).toEqual(['sheet.set', 'input.set', 'snapshot.sync']);
  });
  it('changing an input recalculates and audits before/after', async () => {
    const { s } = await setup();
    setInput(s, { ...input, reduction: { source: 'ca', bp: 5000 }, notified: true });
    expect((await calculate(s)).cents).toBe(9300);
    expect((s.audit.at(-1)!.data as { before: unknown }).before).toEqual(input);
  });
  it('missing rate blocks the trip and zeroes it', async () => {
    const { s } = await setup();
    setRates(s, { ...rates, rows: [] });
    const r = await calculate(s);
    expect(r.months[0]!.blocked).toBe(1);
    expect(r.cents).toBe(0);
    expect(r.months[0]!.employees[0]!.trips[0]!.issues.some((i) => i.code === 'NO_RATE')).toBe(true);
  });
});

describe('import/export', () => {
  it('xlsx bytes -> readAoa -> parseSheet equals direct parse', () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa()), 'Sheet1');
    const bytes = new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer);
    expect(parseSheet(readAoa(bytes, SIMPLE_PROFILE), SIMPLE_PROFILE, '2026-10')).toEqual(
      parseSheet(aoa(), SIMPLE_PROFILE, '2026-10'),
    );
  });
  it('readSheet: truncated zip -> FILE_UNREADABLE', () => {
    expect(() => readSheet(new Uint8Array([0x50, 0x4b, 3, 4, 0, 0, 0, 0]), 0)).toThrow('FILE_UNREADABLE');
  });
  it('xlsx export re-reads: summary and per-day sheets agree', async () => {
    const { s } = await setup();
    const wb = XLSX.read(toXlsx(await calculate(s)), { type: 'array' });
    expect(wb.SheetNames).toEqual(['Summary', 'Days']);
    expect(XLSX.utils.sheet_to_json(wb.Sheets['Summary']!, { header: 1 })).toEqual([
      ['period', 'employee', 'eur'],
      ['2026-10', 'Jonas', 186],
    ]);
    const days = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets['Days']!, { header: 1 });
    expect(days.slice(1, 4).map((r) => r[10])).toEqual([62, 62, 62]);
    expect(days.at(-1)).toEqual(['total_eur', 186]);
  });
  it('csv: BOM, semicolons, decimal comma', async () => {
    const { s } = await setup();
    const csv = toCsv(toRows(await calculate(s)));
    expect(csv.startsWith('\uFEFF')).toBe(true);
    expect(csv).toContain('total_eur;186');
    expect(toCsv([['a', 1.5]])).toBe('\uFEFFa;1,5');
  });
});

describe('store', () => {
  it('node env falls back to MemoryStore', async () => {
    expect(isTauri()).toBe(false);
    expect(await makeStore()).toBeInstanceOf(MemoryStore);
  });
  it('MemoryStore.list is shallow; remove deletes', async () => {
    const s = new MemoryStore();
    await s.write('packs/a.json', '1');
    await s.write('packs/sub/b.json', '2');
    await s.write('packs2/c.json', '3');
    expect(await s.list('packs')).toEqual(['a.json']);
    await s.remove('packs/a.json');
    expect(await s.read('packs/a.json')).toBeNull();
  });
});
