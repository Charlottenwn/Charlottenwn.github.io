import { describe, it, expect } from 'vitest';
import { calcTrip, type Ctx, type Trip } from '../core/engine';
import type { Policy, Switches, TripInput } from '../core/schema';
import { addDays } from '../core/util';
import { DEFAULT_POLICY, STATUTORY } from '../rules/defaults';

const rates = {
  schema: 1 as const,
  sourceUrl: '',
  rows: [
    { place: 'LT', cents: 2800, validFrom: '2000-01-01' },
    { place: 'DE', cents: 6200, validFrom: '2000-01-01' },
    { place: 'LV', cents: 4400, validFrom: '2000-01-01' },
  ],
};
const allTrue: Switches = {
  dailyReturnIsOneTrip: true,
  shortRuleOnOneDayAbroad: true,
  ltLongerThanWorkdayIsMultiDay: true,
  shortRuleOnReducedRate: true,
};
const ctxWith = (sw: Partial<Switches> = {}, over: Partial<Policy> = {}): Ctx => ({
  rates,
  packs: STATUTORY.map((p) => ({ ...p, switches: { ...allTrue, ...sw } })),
  policies: [{ ...DEFAULT_POLICY, ...over }],
});
const nullCtx: Ctx = { rates, packs: STATUTORY, policies: [DEFAULT_POLICY] };
const H = 480;
const trip = (start: string, mins: (number | null)[]): Trip => ({
  id: `a|${start}`,
  employee: 'a',
  days: mins.map((m, i) => ({ d: addDays(start, i), min: m })),
});
const at = (place: string, from: string): TripInput['legs'] => [{ place, from }];
const run = (t: Trip, legs: TripInput['legs'], o: Partial<TripInput> = {}, c: Ctx = ctxWith()) =>
  calcTrip(
    t,
    { employee: 'a', start: t.days[0]!.d, legs, reduction: null, notified: true, dailyReturn: false, ...o },
    c,
  );
const codes = (r: ReturnType<typeof run>) => r.issues.map((i) => i.code);

describe('dailyReturn (LT, 3 days from 2026-10-05)', () => {
  const t = trip('2026-10-05', [H, H, H]),
    l = at('LT', '2026-10-05'),
    o = { dailyReturn: true };
  it('one trip: all days paid', () => expect(run(t, l, o, ctxWith({ dailyReturnIsOneTrip: true })).cents).toBe(8400));
  it('separate one-day trips: unpaid', () =>
    expect(run(t, l, o, ctxWith({ dailyReturnIsOneTrip: false })).cents).toBe(0));
  it('separate + longer than workday: follows its own switch', () => {
    const long = trip('2026-10-05', [540, 540, 540]);
    expect(run(long, l, o, ctxWith({ dailyReturnIsOneTrip: false, ltLongerThanWorkdayIsMultiDay: true })).cents).toBe(
      8400,
    );
    expect(run(long, l, o, ctxWith({ dailyReturnIsOneTrip: false, ltLongerThanWorkdayIsMultiDay: false })).cents).toBe(
      0,
    );
  });
  it('unresolved switch blocks', () => {
    const r = run(t, l, o, nullCtx);
    expect(r.status).toBe('blocked');
    expect(r.issues[0]!.params.key).toBe('dailyReturnIsOneTrip');
  });
  it('old regime never needs the switch', () => {
    const r = run(trip('2026-09-28', [H, H, H]), at('LT', '2026-09-28'), o, nullCtx);
    expect([r.status, r.cents]).toEqual(['ok', 8400]);
  });
});

describe('LT one-day, longer than workday', () => {
  const t = trip('2026-10-01', [540]),
    l = at('LT', '2026-10-01');
  it('switch true: paid', () =>
    expect(run(t, l, {}, ctxWith({ ltLongerThanWorkdayIsMultiDay: true })).cents).toBe(2800));
  it('switch false: unpaid', () =>
    expect(run(t, l, {}, ctxWith({ ltLongerThanWorkdayIsMultiDay: false })).cents).toBe(0));
  it('switch null: blocked', () => expect(run(t, l, {}, nullCtx).status).toBe('blocked'));
});

describe('one-day abroad under 4h', () => {
  const t = trip('2026-10-02', [180]),
    l = at('LV', '2026-10-02');
  it('switch true: 20%', () => expect(run(t, l, {}, ctxWith({ shortRuleOnOneDayAbroad: true })).cents).toBe(880));
  it('switch false: 100%', () => expect(run(t, l, {}, ctxWith({ shortRuleOnOneDayAbroad: false })).cents).toBe(4400));
});

describe('short day + reduction', () => {
  const t = trip('2026-10-05', [180, H, H]),
    l = at('DE', '2026-10-05'),
    o = { reduction: { source: 'ca' as const, bp: 5000 } };
  it('compounded: 20% of 50%', () => expect(run(t, l, o, ctxWith({ shortRuleOnReducedRate: true })).cents).toBe(6820));
  it('not compounded: min(20%, 50%) of max', () =>
    expect(run(t, l, o, ctxWith({ shortRuleOnReducedRate: false })).cents).toBe(7440));
});

describe('hours', () => {
  it('missing hours on first day blocks (new regime)', () => {
    const r = run(trip('2026-10-05', [null, H]), at('DE', '2026-10-05'));
    expect([r.status, codes(r)]).toEqual(['blocked', ['NO_HOURS']]);
  });
  it('missing hours is fine under the old regime', () =>
    expect(run(trip('2026-09-29', [null, null]), at('DE', '2026-09-29')).cents).toBe(12400));
  it('missing hours on a middle day is fine', () =>
    expect(run(trip('2026-10-05', [H, null, H]), at('DE', '2026-10-05')).cents).toBe(18600));
});

describe('data errors block the trip', () => {
  const t = trip('2026-10-05', [H, H, H]);
  it('no legs -> NO_PLACE', () => expect(codes(run(t, []))).toContain('NO_PLACE'));
  it('legs start after trip start -> NO_PLACE on day 1', () => {
    const r = run(t, at('DE', '2026-10-06'));
    expect([r.status, r.issues.find((i) => i.code === 'NO_PLACE')?.params.date]).toEqual(['blocked', '2026-10-05']);
  });
  it('no policy -> NO_POLICY', () => {
    const r = run(t, at('DE', '2026-10-05'), {}, { ...ctxWith(), policies: [] });
    expect([r.status, codes(r), r.lines.length]).toEqual(['blocked', ['NO_POLICY'], 0]);
  });
  it('no pack -> NO_PACK', () =>
    expect(codes(run(t, at('DE', '2026-10-05'), {}, { ...ctxWith(), packs: [] }))).toContain('NO_PACK'));
});

describe('reductions', () => {
  const de = at('DE', '2026-10-05');
  it('local act, exactly 7 days: applies', () => {
    const r = run(trip('2026-10-05', Array(7).fill(H)), de, { reduction: { source: 'local', bp: 6500 } });
    expect([r.cents, r.issues.length]).toEqual([28210, 0]);
  });
  it('local act, 6 days: forced to 100% + warn', () => {
    const r = run(trip('2026-10-05', Array(6).fill(H)), de, { reduction: { source: 'local', bp: 6500 } });
    expect([r.cents, codes(r)]).toEqual([37200, ['LOCAL_ACT_TRIP_TOO_SHORT']]);
  });
  it('local act on a short trip without notice reports both reasons', () => {
    const r = run(trip('2026-10-05', [H, H, H]), de, { reduction: { source: 'local', bp: 6500 }, notified: false });
    expect([r.cents, codes(r).sort()]).toEqual([18600, ['LOCAL_ACT_TRIP_TOO_SHORT', 'NOT_NOTIFIED']]);
  });
  it('local act below 65% blocks', () =>
    expect(
      codes(run(trip('2026-10-05', Array(7).fill(H)), de, { reduction: { source: 'local', bp: 6000 } })),
    ).toContain('REDUCTION_BELOW_MIN'));
  it('old regime: local act at 50%, short trip, no notice', () =>
    expect(
      run(trip('2026-09-14', [H, H, H]), at('DE', '2026-09-14'), {
        reduction: { source: 'local', bp: 5000 },
        notified: false,
      }).cents,
    ).toBe(9300));
  it('policy default reduction applies; explicit input overrides it', () => {
    const c = ctxWith({}, { defaultReduction: { source: 'ca', bp: 6000 } }),
      t = trip('2026-10-05', [H, H, H]);
    expect(run(t, de, {}, c).cents).toBe(11160);
    expect(run(t, de, { reduction: { source: 'none', bp: 10000 } }, c).cents).toBe(18600);
  });
});

describe('rates', () => {
  it('rate change mid-trip applies per day', () => {
    const c = {
      ...ctxWith(),
      rates: {
        ...rates,
        rows: [
          { place: 'DE', cents: 6000, validFrom: '2000-01-01' },
          { place: 'DE', cents: 6200, validFrom: '2026-10-06' },
        ],
      },
    };
    expect(run(trip('2026-10-05', [H, H, H]), at('DE', '2026-10-05'), {}, c).cents).toBe(18400);
  });
});
