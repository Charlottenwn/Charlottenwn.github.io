import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { expect } from 'vitest';
import type { RateList, RulePack, Switches } from '../core/schema';
import { sha, stable } from '../core/util';
import { STATUTORY, DEFAULT_POLICY } from '../rules/defaults';

export type Ref = { id: string; version: number; sha: string };
export type Base = {
  id: string;
  packs: Ref[];
  policy: { ref: string; sha: string };
  switches: Switches;
  rates: RateList;
  ratesSha: string;
};

const h = (v: unknown) => sha(stable(v));
const upd = process.env.GOLDEN_UPDATE === '1';

export const load = <T extends Base>(dir: string) =>
  readdirSync(dir)
    .filter((n) => n.endsWith('.json'))
    .map((f) => ({ p: join(dir, f), fx: JSON.parse(readFileSync(join(dir, f), 'utf8')) as T }));

export async function gate(fx: Base, p: string) {
  const base = fx.packs.map((r) => {
    const x = STATUTORY.find((y) => y.id === r.id && y.version === r.version);
    if (!x) throw new Error(`pack ${r.id}@${r.version} missing from repo`);
    return x;
  });
  expect(`${DEFAULT_POLICY.id}@${DEFAULT_POLICY.version}`, 'policy version').toBe(fx.policy.ref);
  const cur = { packs: await Promise.all(base.map(h)), policy: await h(DEFAULT_POLICY), rates: await h(fx.rates) };
  if (upd) {
    fx.packs.forEach((r, i) => (r.sha = cur.packs[i]!));
    fx.policy.sha = cur.policy;
    fx.ratesSha = cur.rates;
    writeFileSync(p, JSON.stringify(fx, null, 2) + '\n');
  }
  expect(cur.packs, 'rule pack changed: review expected by hand, then npm run golden:update').toEqual(
    fx.packs.map((r) => r.sha),
  );
  expect(cur.policy, 'default policy changed: review expected, then npm run golden:update').toBe(fx.policy.sha);
  expect(cur.rates, 'fixture rates changed').toBe(fx.ratesSha);
  const packs: RulePack[] = base.map((x) => ({ ...x, switches: fx.switches }));
  return { packs, policy: DEFAULT_POLICY };
}
