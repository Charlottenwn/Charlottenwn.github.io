import { describe, expect, it } from 'vitest';
import { calcAll, inputFor } from '../core/engine';
import { DEFAULT_POLICY, STATUTORY } from '../rules/defaults';

type Args = Parameters<typeof calcAll>;
type Sheet = Args[0][number];
type Inputs = Args[1];
type Ctx = Args[2];
type Res = ReturnType<typeof calcAll>;

const row = (place: string, cents: number) => ({ place, cents, validFrom: '2000-01-01' });
const rates = {
  schema: 1 as const,
  sourceUrl: '',
  rows: [row('LT', 2800), row('DE', 6200), row('LV', 4400), row('PL', 5000)],
}; // fixtures
const answered = STATUTORY.map((p) => ({
  ...p,
  switches: {
    dailyReturnIsOneTrip: true,
    shortRuleOnOneDayAbroad: true,
    ltLongerThanWorkdayIsMultiDay: true,
    shortRuleOnReducedRate: true,
  },
}));

const ctx: Ctx = { rates, packs: answered, policies: [DEFAULT_POLICY] };

const pad = (n: number) => String(n).padStart(2, '0');
const dim = (ym: string) => new Date(Date.UTC(+ym.slice(0, 4), +ym.slice(5), 0)).getUTCDate();

/** one month; K days = trip [from, to] in DE, 8 h unless `mins[date]` says otherwise */
function sheet(ym: string, trip?: [number, number], mins: Record<string, number> = {}): Sheet {
  const days = Array.from({ length: dim(ym) }, (_, i) => {
    const d = `${ym}-${pad(i + 1)}`;
    const k = !!trip && i + 1 >= trip[0] && i + 1 <= trip[1];
    return { d, k, min: k ? (mins[d] ?? 480) : null, ...(k ? { place: 'DE' } : {}) };
  });
  return { period: ym, employees: [{ name: 'Jonas', days }], issues: [] } as unknown as Sheet;
}

const local = (bp: number) =>
  ({ legs: [], reduction: { source: 'local', bp }, notified: true }) as unknown as Inputs[string];
const id = (d: string) => `Jonas|${d}`;
const lines = (r: Res) => r.flatMap((m) => m.employees.flatMap((e) => e.trips.flatMap((t) => t.lines)));
const issues = (r: Res) => r.flatMap((m) => m.issues);

describe('trip across the month boundary (Oct 26 to Nov 5 = 11 days)', () => {
  const sheets = () => [
    sheet('2026-10', [26, 31], { '2026-10-26': 180 }),
    sheet('2026-11', [1, 5], { '2026-11-05': 200 }),
  ];
  const inputs = { [id('2026-10-26')]: local(6500) };

  it('both months loaded: whole trip reduced, 20 % only on the true first/last day', () => {
    const r = calcAll(sheets(), inputs, ctx);
    const ls = lines(r);
    expect(ls).toHaveLength(11);
    expect(ls.every((l) => l.redBp === 6500)).toBe(true);
    ls.forEach((l, i) => {
      if (i === 0 || i === 10) expect(l.shortBp).toBeLessThan(10000);
      else expect(l.shortBp).toBe(10000);
    });
    expect(issues(r).filter((i) => i.code === 'MONTH_EDGE_TRIP')).toHaveLength(0);
  });

  it('flags and month sums', () => {
    const r = calcAll(sheets(), inputs, ctx);
    expect(r[0]!.employees[0]!.trips[0]!.intoNext).toBe(true);
    expect(r[1]!.employees[0]!.trips[0]!.fromPrev).toBe(true);
    expect(r[0]!.cents + r[1]!.cents).toBe(lines(r).reduce((a, l) => a + l.cents, 0));
  });

  it('only Oct loaded: MONTH_EDGE_TRIP end, and the 7-day test sees 6 days (known limitation)', () => {
    const r = calcAll([sheets()[0]!], inputs, ctx);
    expect(issues(r).some((i) => i.code === 'MONTH_EDGE_TRIP' && i.params.edge === 'end')).toBe(true);
    expect(lines(r).every((l) => l.redBp === 10000)).toBe(true);
    expect(JSON.stringify(r)).toContain('LOCAL_ACT_TRIP_TOO_SHORT');
  });

  // KNOWN GAP: inputs are keyed by first day; loading the earlier month changes the id
  it('inputs saved on a later day of the trip still apply', () => {
    const r = calcAll(sheets(), { [id('2026-11-01')]: local(6500) }, ctx);
    expect(lines(r).every((l) => l.redBp === 6500)).toBe(true);
  });
});

describe('local act, 7-day boundary (Atmintinė)', () => {
  it('7 days: reduced on every day', () => {
    const r = calcAll([sheet('2026-10', [20, 26])], { [id('2026-10-20')]: local(6500) }, ctx);
    expect(lines(r).every((l) => l.redBp === 6500)).toBe(true);
  });
  it('6 days: forced to 100 % with warning', () => {
    const r = calcAll([sheet('2026-10', [20, 25])], { [id('2026-10-20')]: local(6500) }, ctx);
    expect(lines(r).every((l) => l.redBp === 10000)).toBe(true);
    expect(JSON.stringify(r)).toContain('LOCAL_ACT_TRIP_TOO_SHORT');
  });
  it('60 % is below the 65 % floor', () => {
    const r = calcAll([sheet('2026-10', [20, 26])], { [id('2026-10-20')]: local(6000) }, ctx);
    expect(JSON.stringify(r)).toContain('REDUCTION_BELOW_MIN');
  });
});

describe('inputFor', () => {
  const t = {
    id: 'Jonas|2026-10-26',
    employee: 'Jonas',
    days: [
      { d: '2026-10-26', min: null },
      { d: '2026-10-27', min: null },
    ],
  };
  const a = local(6500),
    b = local(7000);
  it('later-day key resolves', () => expect(inputFor({ 'Jonas|2026-10-27': a }, t)).toBe(a));
  it('exact id wins', () => expect(inputFor({ 'Jonas|2026-10-27': a, 'Jonas|2026-10-26': b }, t)).toBe(b));
  it('date outside the trip: none', () => expect(inputFor({ 'Jonas|2026-10-28': a }, t)).toBeUndefined());
  it('other employee with a similar name: none', () => expect(inputFor({ 'Jonasz|2026-10-27': a }, t)).toBeUndefined());
});
