import { fileURLToPath } from 'node:url';
import { describe, it, expect } from 'vitest';
import { calcTrip, type Trip } from '../core/engine';
import type { Issue, TripInput } from '../core/schema';
import { gate, load, type Base } from './golden-gate';

type Fx = Base & {
  trip: Trip;
  tripInput: TripInput | null;
  expected: { cents: number; issues: Issue[]; lines: { d: string; cents: number; pack: string }[] };
};
const dir = fileURLToPath(new URL('./golden/', import.meta.url));

describe('golden', () => {
  for (const { p, fx } of load<Fx>(dir)) {
    it(fx.id, async () => {
      const { packs, policy } = await gate(fx, p);
      const r = calcTrip(fx.trip, fx.tripInput ?? undefined, { rates: fx.rates, packs, policies: [policy] });
      expect(r.status).toBe('ok');
      expect(r.issues).toEqual(fx.expected.issues);
      expect(r.lines.map((l) => ({ d: l.d, cents: l.cents, pack: l.pack }))).toEqual(fx.expected.lines);
      expect(r.cents).toBe(fx.expected.cents);
    });
  }
});
