import { describe, it, expect } from 'vitest';
import { calculate, importRates, importTripInputs, newSession, setSheet } from '../core/api';
import { parseSheet } from '../core/import';
import { checkRates, mergeRates, parseRates } from '../core/rates';
import { DataError, Repo } from '../core/repo';
import { MemoryStore } from '../core/storage';
import { parseTripInputs } from '../core/tripinput';
import { parseDate } from '../core/util';
import { SIMPLE_PROFILE } from '../rules/defaults';

const codes = (r: { issues: { code: string }[] }) => r.issues.map((i) => i.code);
const serial = (y: number, m: number, d: number) => Date.UTC(y, m - 1, d) / 864e5 + 25569;
const H = ['employee', 'start', 'place', 'from', 'transit', 'reduction', 'pct', 'notified', 'daily_return'];

describe('parseDate', () => {
  it('ISO, dd.mm.yyyy, dd/mm/yyyy, Excel serial', () => {
    expect(['2026-10-05', '05.10.2026', '5/10/2026', serial(2026, 10, 5)].map(parseDate)).toEqual(
      Array(4).fill('2026-10-05'),
    );
  });
  it('rejects impossible dates and non-dates', () => {
    expect(['2026-02-30', '31.04.2026', 'abc', '', null, 3, 46000.5, '2026-1-5'].map(parseDate)).toEqual(
      Array(8).fill(null),
    );
  });
});

describe('parseRates', () => {
  it('header, comma decimals, city rows, lowercase country, mixed date formats, blank rows', () => {
    const r = parseRates([
      ['place', 'eur', 'from'],
      ['de', '62,10', '2026-01-01'],
      ['DE/Berlin', 70, '01.01.2026'],
      ['LV', 44, serial(2026, 1, 1)],
      [null, null, null],
    ]);
    expect(r.issues).toEqual([]);
    expect(r.rows).toEqual([
      { place: 'DE', cents: 6210, validFrom: '2026-01-01' },
      { place: 'DE/Berlin', cents: 7000, validFrom: '2026-01-01' },
      { place: 'LV', cents: 4400, validFrom: '2026-01-01' },
    ]);
  });
  it('works without a header row', () => expect(parseRates([['LV', 44, '2026-01-01']]).rows).toHaveLength(1));
  it('reports every bad row, keeps the good ones', () => {
    const r = parseRates([
      ['Germany', 62, '2026-01-01'],
      ['DE', -1, '2026-01-01'],
      ['DE', 62, 'x'],
      ['LV', 44, '2026-01-01'],
      ['LV', 45, '2026-01-01'],
    ]);
    expect(codes(r)).toEqual(['BAD_PLACE', 'BAD_RATE', 'BAD_DATE', 'DUP_RATE']);
    expect(r.issues.map((i) => i.params.row)).toEqual([1, 2, 3, 5]);
    expect(r.rows).toEqual([{ place: 'LV', cents: 4400, validFrom: '2026-01-01' }]);
  });
  it('warns when sub-cent precision is rounded', () => {
    const r = parseRates([['DE', 62.123, '2026-01-01']]);
    expect([r.rows[0]!.cents, codes(r), r.issues[0]!.level]).toEqual([6212, ['RATE_ROUNDED'], 'warn']);
  });
});

describe('mergeRates / checkRates', () => {
  const base = { schema: 1 as const, sourceUrl: 'u', rows: [{ place: 'DE', cents: 6200, validFrom: '2026-01-01' }] };
  it('add: new / changed / same counts, sorted, keeps sourceUrl', () => {
    const m = mergeRates(
      base,
      [
        { place: 'LV', cents: 4400, validFrom: '2026-01-01' },
        { place: 'DE', cents: 6200, validFrom: '2026-01-01' },
        { place: 'DE', cents: 6300, validFrom: '2026-07-01' },
      ],
      'add',
    );
    expect([m.added, m.changed, m.same]).toEqual([2, 0, 1]);
    expect(m.list.rows.map((r) => `${r.place}@${r.validFrom}`)).toEqual([
      'DE@2026-01-01',
      'DE@2026-07-01',
      'LV@2026-01-01',
    ]);
    expect(m.list.sourceUrl).toBe('u');
    const c = mergeRates(base, [{ place: 'DE', cents: 6500, validFrom: '2026-01-01' }], 'add');
    expect([c.added, c.changed, c.list.rows[0]!.cents]).toEqual([0, 1, 6500]);
  });
  it('replace: only imported rows remain', () => {
    expect(
      mergeRates(base, [{ place: 'LV', cents: 4400, validFrom: '2026-01-01' }], 'replace').list.rows.map(
        (r) => r.place,
      ),
    ).toEqual(['LV']);
  });
  it('duplicates are detected and the repo refuses to save them', async () => {
    const dup = { ...base, rows: [...base.rows, { ...base.rows[0]!, cents: 1 }] };
    expect(codes({ issues: checkRates(dup) })).toEqual(['DUP_RATE']);
    await expect(new Repo(new MemoryStore()).saveRates(dup)).rejects.toBeInstanceOf(DataError);
  });
});

describe('parseTripInputs', () => {
  it('legs, trip-level fields from the first row, flags', () => {
    const r = parseTripInputs([
      H,
      ['Jonas', '2026-10-12', 'PL', '2026-10-12', '', 'ca', '50%', 'taip', ''],
      ['Jonas', '2026-10-12', 'DE', '2026-10-15', '', '', '', '', ''],
    ]);
    expect(r.issues).toEqual([]);
    expect(r.inputs).toEqual([
      {
        employee: 'Jonas',
        start: '2026-10-12',
        legs: [
          { place: 'PL', from: '2026-10-12' },
          { place: 'DE', from: '2026-10-15' },
        ],
        reduction: { source: 'ca', bp: 5000 },
        notified: true,
        dailyReturn: false,
      },
    ]);
  });
  it('Lithuanian headers, minimal columns, defaults', () => {
    const r = parseTripInputs([
      ['Darbuotojas', 'Pradžia', 'Vieta', 'Nuo'],
      ['Jonas', '2026-10-05', 'de', '2026-10-05'],
    ]);
    expect(r.inputs).toEqual([
      {
        employee: 'Jonas',
        start: '2026-10-05',
        legs: [{ place: 'DE', from: '2026-10-05' }],
        reduction: null,
        notified: false,
        dailyReturn: false,
      },
    ]);
  });
  it('missing required columns', () => {
    const r = parseTripInputs([['employee', 'start']]);
    expect([codes(r), r.issues[0]!.params.columns, r.inputs]).toEqual([['MISSING_COLUMNS'], 'place,from', []]);
  });
  it('inconsistent trip-level fields drop the whole trip', () => {
    const r = parseTripInputs([
      H,
      ['J', '2026-10-05', 'DE', '2026-10-05', '', 'ca', '50', '', ''],
      ['J', '2026-10-05', 'LV', '2026-10-07', '', 'local', '65', '', ''],
    ]);
    expect([codes(r), r.inputs]).toEqual([['INCONSISTENT_TRIP'], []]);
  });
  it('percent: "50", "50%", "50,5" ok; 0.5, 1, blank, >100, text rejected', () => {
    const pct = (p: unknown) => parseTripInputs([H, ['J', '2026-10-05', 'DE', '2026-10-05', '', 'ca', p, '', '']]);
    expect(['50', '50%', '50,5'].map((p) => pct(p).inputs[0]!.reduction!.bp)).toEqual([5000, 5000, 5050]);
    expect([0.5, 1, '', 101, 'x'].map((p) => codes(pct(p))[0])).toEqual(Array(5).fill('BAD_PCT'));
  });
  it('bad flags, reduction, dates, places and duplicate legs', () => {
    const one = (...c: unknown[]) => codes(parseTripInputs([H, c]));
    expect(one('J', '2026-10-05', 'DE', '2026-10-05', 'maybe')).toEqual(['BAD_FLAG']);
    expect(one('J', '2026-10-05', 'DE', '2026-10-05', '', 'half', '50')).toEqual(['BAD_REDUCTION']);
    expect(one('', 'x', 'Germany', '', '')).toEqual(['BAD_EMPLOYEE', 'BAD_DATE', 'BAD_DATE', 'BAD_PLACE']);
    const r = parseTripInputs([H, ['J', '2026-10-05', 'DE', '2026-10-05'], ['J', '2026-10-05', 'DE', '2026-10-05']]);
    expect([codes(r), r.inputs]).toEqual([['DUP_LEG'], []]);
  });
  it('"none" overrides the policy default; transit flag; leg-date warnings keep the trip', () => {
    expect(parseTripInputs([H, ['J', '2026-10-05', 'DE', '2026-10-05', '', 'none']]).inputs[0]!.reduction).toEqual({
      source: 'none',
      bp: 10000,
    });
    expect(parseTripInputs([H, ['J', '2026-10-05', 'CZ', '2026-10-05', 'x']]).inputs[0]!.legs[0]).toEqual({
      place: 'CZ',
      from: '2026-10-05',
      transit: true,
    });
    const late = parseTripInputs([H, ['J', '2026-10-05', 'DE', '2026-10-06']]);
    const early = parseTripInputs([H, ['J', '2026-10-05', 'DE', '2026-10-04']]);
    expect([codes(late), late.inputs.length, codes(early), early.inputs.length]).toEqual([
      ['FIRST_LEG_AFTER_START'],
      1,
      ['LEG_BEFORE_START'],
      1,
    ]);
  });
});

describe('api imports end to end', () => {
  const N = 31,
    inTrip = (d: number) => d >= 5 && d <= 7;
  const sheet = (): unknown[][] => [
    ['Name', ...Array.from({ length: N }, (_, i) => i + 1)],
    ['Jonas', ...Array.from({ length: N }, (_, i) => (inTrip(i + 1) ? 8 : null))],
    ['', ...Array.from({ length: N }, (_, i) => (inTrip(i + 1) ? 'K' : null))],
  ];
  const make = async () => {
    const repo = new Repo(new MemoryStore());
    await repo.saveRates({
      schema: 1,
      sourceUrl: '',
      rows: [{ place: 'DE', cents: 6200, validFrom: '2000-01-01' }],
    });
    const s = await newSession(repo, 't');
    setSheet(s, parseSheet(sheet(), SIMPLE_PROFILE, '2026-10'));
    return s;
  };
  const trips = [H, ['Jonas', '2026-10-05', 'DE', '2026-10-05']];
  it('trip sheet -> calculation (blocked before, 186.00 after)', async () => {
    const s = await make();
    expect((await calculate(s)).cents).toBe(0);
    const r = importTripInputs(s, trips);
    expect([r.applied, r.issues]).toEqual([1, []]);
    expect((await calculate(s)).cents).toBe(18600);
    expect(s.audit.map((a) => a.op)).toEqual(['sheet.set', 'input.set']);
  });
  it('any error in the trip sheet applies nothing', async () => {
    const s = await make();
    const r = importTripInputs(s, [...trips, ['Jonas', 'x', 'DE', '2026-10-06']]);
    expect([r.applied, Object.keys(s.inputs)]).toEqual([0, []]);
    expect(codes(r)).toContain('BAD_DATE');
  });
  it('rates import changes the session snapshot and recalculates', async () => {
    const s = await make();
    importTripInputs(s, trips);
    const r = importRates(
      s,
      [
        ['place', 'eur', 'from'],
        ['DE', 68, '2000-01-01'],
      ],
      'add',
    );
    expect([r.added, r.changed, r.same]).toEqual([0, 1, 0]);
    expect((await calculate(s)).cents).toBe(20400);
    expect(importRates(s, [['DE', -1, '2000-01-01']], 'add').added).toBe(0);
    expect(s.rates.rows[0]!.cents).toBe(6800);
  });
});
