import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import { calcMonth, calcTrip, detectTrips, type Ctx, type Trip } from '../core/engine';
import type { ParsedSheet, TripInput } from '../core/schema';
import { addDays, mulDiv } from '../core/util';
import { DEFAULT_POLICY, STATUTORY } from '../rules/defaults';

const answered = STATUTORY.map((p) => ({
  ...p,
  switches: {
    dailyReturnIsOneTrip: true,
    shortRuleOnOneDayAbroad: true,
    ltLongerThanWorkdayIsMultiDay: true,
    shortRuleOnReducedRate: true,
  },
}));
const ctx: Ctx = {
  rates: {
    schema: 1,
    sourceUrl: '',
    rows: [
      { place: 'DE', cents: 6200, validFrom: '2000-01-01' },
      { place: 'LT', cents: 2800, validFrom: '2000-01-01' },
    ],
  },
  packs: answered,
  policies: [DEFAULT_POLICY],
};

const day = fc.record({ k: fc.boolean(), min: fc.integer({ min: 0, max: 600 }) });
const emp = (name: string) =>
  fc
    .array(day, { minLength: 31, maxLength: 31 })
    .map((ds) => ({ name, days: ds.map((x, i) => ({ d: addDays('2026-10-01', i), min: x.min, k: x.k })) }));
const sheet = fc
  .tuple(emp('A'), emp('B'), emp('C'))
  .map((employees): ParsedSheet => ({ period: '2026-10', employees, issues: [] }));

const inputsFor = (s: ParsedSheet): Record<string, TripInput> => {
  const out: Record<string, TripInput> = {};
  for (const e of s.employees)
    for (const t of detectTrips(e).trips) {
      const start = t.days[0]!.d;
      out[t.id] = {
        employee: t.employee,
        start,
        legs: [{ place: 'DE', from: start }],
        reduction: null,
        notified: false,
        dailyReturn: false,
      };
    }
  return out;
};
const byEmp = (r: ReturnType<typeof calcMonth>) => Object.fromEntries(r.employees.map((e) => [e.employee, e.cents]));

describe('properties', () => {
  it('result is independent of employee order', () => {
    fc.assert(
      fc.property(sheet, (s) => {
        const inp = inputsFor(s),
          a = calcMonth(s, inp, ctx);
        const b = calcMonth({ ...s, employees: [...s.employees].reverse() }, inp, ctx);
        expect(b.cents).toBe(a.cents);
        expect(byEmp(b)).toEqual(byEmp(a));
      }),
    );
  });
  it('integer cents, non-negative, sums consistent, nothing blocked', () => {
    fc.assert(
      fc.property(sheet, (s) => {
        const r = calcMonth(s, inputsFor(s), ctx);
        expect(r.blocked).toBe(0);
        expect(r.cents).toBe(r.employees.reduce((a, e) => a + e.cents, 0));
        for (const e of r.employees)
          for (const t of e.trips) {
            expect(Number.isInteger(t.cents) && t.cents >= 0).toBe(true);
            expect(t.cents).toBe(t.lines.reduce((a, l) => a + l.cents, 0));
            for (const l of t.lines) expect(l.cents >= 0 && l.cents <= 6200).toBe(true);
          }
      }),
    );
  });
  it('a deeper CA reduction never pays more', () => {
    const arb = fc.tuple(
      fc.integer({ min: 3, max: 12 }),
      fc.integer({ min: 5000, max: 10000 }),
      fc.integer({ min: 5000, max: 10000 }),
      fc.array(fc.integer({ min: 0, max: 600 }), { minLength: 12, maxLength: 12 }),
    );
    fc.assert(
      fc.property(arb, ([n, b1, b2, mins]) => {
        const t: Trip = {
          id: 'x|2026-10-05',
          employee: 'x',
          days: mins.slice(0, n).map((m, i) => ({ d: addDays('2026-10-05', i), min: m })),
        };
        const run = (bp: number) =>
          calcTrip(
            t,
            {
              employee: 'x',
              start: '2026-10-05',
              legs: [{ place: 'DE', from: '2026-10-05' }],
              reduction: { source: 'ca', bp },
              notified: true,
              dailyReturn: false,
            },
            ctx,
          ).cents;
        expect(run(Math.min(b1, b2))).toBeLessThanOrEqual(run(Math.max(b1, b2)));
      }),
    );
  });
  it('mulDiv is the nearest integer in the engine range', () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 1e14 }), fc.integer({ min: 2e8, max: 1e9 }), (n, d) => {
        const r = mulDiv(n, d);
        expect(Number.isInteger(r)).toBe(true);
        expect(Math.abs(r - n / d)).toBeLessThanOrEqual(0.5 + 1e-9);
      }),
    );
  });
});

describe('rule cut 2026-10-01', () => {
  it('trip spanning the cut uses each day’s own pack', () => {
    const t: Trip = {
      id: 'a|2026-09-29',
      employee: 'a',
      days: [180, 480, 480, 180].map((m, i) => ({ d: addDays('2026-09-29', i), min: m })),
    };
    const r = calcTrip(
      t,
      {
        employee: 'a',
        start: '2026-09-29',
        legs: [{ place: 'LT', from: '2026-09-29' }],
        reduction: null,
        notified: false,
        dailyReturn: false,
      },
      ctx,
    );
    expect(r.lines.map((l) => l.pack)).toEqual(['LT-526@1', 'LT-526@1', 'LT-526@2', 'LT-526@2']);
    expect(r.lines.map((l) => l.cents)).toEqual([2800, 2800, 2800, 560]); // 3h first day: no 20% under old pack; 3h last day: 20% under new
    expect(r.cents).toBe(8960);
  });
});
