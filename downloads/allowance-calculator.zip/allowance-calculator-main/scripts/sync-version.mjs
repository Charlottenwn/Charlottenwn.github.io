import { readFileSync, writeFileSync } from 'node:fs';
const v = JSON.parse(readFileSync('package.json', 'utf8')).version;
const edit = (f, fn) => writeFileSync(f, fn(readFileSync(f, 'utf8')));
edit('src-tauri/tauri.conf.json', (s) => s.replace(/("version":\s*)"[^"]*"/, `$1"${v}"`));
edit('src-tauri/Cargo.toml', (s) => s.replace(/^version = ".*"/m, `version = "${v}"`));
