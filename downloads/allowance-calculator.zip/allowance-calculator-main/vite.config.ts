import { defineConfig } from 'vitest/config';
import { svelte } from '@sveltejs/vite-plugin-svelte';
import { viteSingleFile } from 'vite-plugin-singlefile';
export default defineConfig(({ mode }) => ({
  plugins: [svelte(), ...(mode === 'single' ? [viteSingleFile()] : [])],
  clearScreen: false,
  server: { port: 5173, strictPort: true },
  resolve: mode === 'test' ? { conditions: ['browser'] } : {},
  test: {
    include: ['src/tests/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      include: ['src/core/**', 'src/rules/**'],
      exclude: ['src/core/storage.tauri.ts', 'src/core/io.ts'],
      thresholds: { statements: 98, branches: 90, functions: 100, lines: 100 },
    },
  },
}));
