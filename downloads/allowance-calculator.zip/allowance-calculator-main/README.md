# allowance-calculator

Allowance calculator application for accountants.
